"""Build traceable Phase 1 closeout / Phase 2 draft supporting files.

Run after build_examples.py and build_scorecard.py. This writes development
documentation, not PPTX files or a native AI skill.
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HISTORY = ROOT / 'history-2026-09-17'
def read(path):
    return json.loads(path.read_text())
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

MAPPINGS = [
 ('R01',['TX02','ST03'],['STR4','MSG1'], 'Semantic review: cocokkan judul dengan entitas, nilai, arah, periode dan scope exhibit; belum divalidasi pada generated deck.'),
 ('R02',['ST02'],['STR3'], 'Title-only review menggunakan storyboards; penilaian independen belum dijalankan.'),
 ('R03',['NU01'],['EVI3'], 'Unit/periode/basis eksplisit pada SYN-*; schema umum dan lint baru Phase 3/9.'),
 ('R04',['NU03'],['EVI2','EVI3'], 'SYN-C03: bridge EBIT, forecast, dan kas direkonsiliasi lewat kode.'),
 ('R05',['ST04','NU08'],['STR4','EVI3'], 'SYN-C03 memisahkan action committed/potential/cash; deteksi overlap bebas antarintervensi belum dibuat.'),
 ('R06',['NU03'],['EVI3','CHR3'], 'Hitung input penuh dan batasi display precision; generalized rounding-interval validator/render belum dibuat.'),
 ('R07',['NU02'],['EVI3','MSG3'], 'Share, relative change, pp, bp dan contribution didefinisikan; belum general-purpose semantic validator.'),
 ('R08',['NU06','NU08'],['EVI2','EVI4'], 'Empat skenario SYN-C04 berbagi baseline dan parameter eksplisit; kalkulasi diperiksa dengan metode lain.'),
 ('R09',['NU01','EV04'],['EVI3','EVI4'], 'Review kesetaraan universe/restatement; belum diuji pada model restatement baru.'),
 ('R10',['NU01','NU05'],['EVI3'], 'Basis nominal/currency/perspective dinyatakan; kasus FX/retail/GDP perlu pengujian lanjutan.'),
 ('R11',['DC03','NU04'],['EVI2','EVI3'], 'Tanggal dan day-count SYN-C04 serta due SYN-C03 diperiksa; general calendar/roadmap lint belum dibuat.'),
 ('R12',['DC03','DC04'],['STR5','EVI4'], 'SYN-C03 memisahkan owner/authority/status; mutation missing owner/invented approval ditolak.'),
 ('R13',['EV04','EV05','TX02'],['EVI4','MSG1'], 'Semua SYN-* berlabel; scope dan uncertainty wajib ikut klaim. General semantic review belum diuji.'),
 ('R14',['NU01','CH02'],['EVI3','CHR2'], 'Definisi survey/comparability tertulis; belum ada benchmark representativitas/sampling.'),
 ('R15',['TX02','CH02'],['STR4','MSG1'], 'Review kausalitas termasuk panah/diagram; kode aritmetika tidak membuktikan sebab-akibat.'),
 ('R16',['VI01','VI04','VI05','PT03'],['VIS1','VIS2','TEC1'], 'Pemeriksaan render/app diperlukan; belum dijalankan pada PPTX.'),
 ('R17',['EV01','EV02','EV03'],['EVI1','EVI2'], 'Crosswalk source/page dan storyboard JSON pointers diverifikasi; original source assets tidak dibundel.'),
 ('R18',['PT01','PT02','PT03'],['TEC1','TEC2'], 'Status PDF/pattern dipisahkan dari klaim editability; uji aplikasi dan artifact baru di fase build.'),
 ('R19',['Section 12'],['EVI4'], 'Family-level split diwajibkan; semua contoh saat ini development, blind holdout belum ditetapkan.'),
 ('R20',['Section 8 asset policy'],['VIS3'], 'Sumber/aset asli tidak masuk paket; D012 dikecualikan sebagai positive learning reference.'),
 ('R21',['VI01','VI04'],['VIS1','VIS2'], 'Live/pre-read dipisahkan; typography/density masih token awal, perlu render validation.'),
 ('R22',['DC03','EV04'],['STR1','EVI4'], 'Unknown tidak diisi sebagai fakta. Mutation missing owner/due dan invented approval diperiksa untuk SYN-C03.')
]

old_rules = read(HISTORY / 'history-2026-09-16/baseline/phase1b-rule-candidates.json')['rules']
by_id = {r['rule_id']: r for r in old_rules}
crosswalk = []
for rid, sections, criteria, check in MAPPINGS:
    prior = by_id[rid]
    refs = [x for x in prior['supporting_references'] if not x.startswith('D012:')]
    row = dict(rule_id=rid, name=prior['name'], prior_candidate=prior['candidate_rule'],
               standard_sections=sections, scorecard_criteria=criteria,
               retained_pattern_references=refs, validation_or_remaining_work=check,
               status='MAPPED_TO_DRAFT_STANDARD_NOT_PRODUCTION_CERTIFIED')
    if rid == 'R20':
        row['legacy_pointer_disposition'] = 'Legacy D012:21 retained only in immutable history. Excluded from current positive learning evidence; no source content or commercial assets used.'
    crosswalk.append(row)
write(ROOT / 'phase2/rule-crosswalk.json', {'version':'0.1','rules':crosswalk})
lines = ['# Phase 1B → Phase 2 rule crosswalk', '',
         '22 kandidat aturan dipetakan satu per satu. Tabel ini menunjukkan keterlacakan, bukan bukti bahwa seluruh validator sudah tersedia. 23 keputusan pemilihan referensi pada batch sebelumnya adalah daftar terpisah dari 22 kandidat aturan ini.', '',
         '| Rule | Aturan / standard | Rubrik | Pemeriksaan atau batas sekarang |', '|---|---|---|---|']
for r in crosswalk:
    lines.append(f"| {r['rule_id']} | {r['name']} → {', '.join(r['standard_sections'])} | {', '.join(r['scorecard_criteria'])} | {r['validation_or_remaining_work']} |")
lines += ['', 'Daftar source/page lengkap ada di `rule-crosswalk.json`. D012:21 adalah pointer historis yang dikecualikan, bukan acuan positif untuk standard saat ini. Blueprint dan keputusan lama tidak ditulis ulang.', '']
(ROOT / 'phase2/rule-crosswalk.md').write_text('\n'.join(lines))

# Every evidence pointer resolves to a bundled original input or expected result.
def ev(name, pointer):
    return {'file':'cases/'+name+'.json', 'pointer':pointer}
def slide(sid, title, intent, exhibit, refs, guardrail):
    return {'slide_id':sid,'role':'content','action_title':title,'analytical_intent':intent,
            'exhibit':exhibit,'evidence':refs,'guardrail':guardrail,
            'source_footer':'Sumber: kasus orisinal sintetis '+sid.split('-')[0]+'; bukan data perusahaan nyata.'}
boards = [
 {'id':'SB-C02','case_id':'SYN-C02','audience':'Simulated Investment Committee','purpose':'decide', 'slides':[
  slide('C02-01','Kemitraan menjadi opsi masuk Market B yang memenuhi batas dana dan waktu','Rekomendasi bersyarat','Executive decision summary',[ev('c02-expected','/selected_mode'),ev('c02-market-entry','/decision')],'Permintaan approval belum disetujui.'),
  slide('C02-02','Market B memimpin shortlist sintetis dengan skor 4,2','Prioritisasi','Weighted option table',[ev('c02-market-entry','/market_weights'),ev('c02-market-entry','/market_scores'),ev('c02-expected','/market_scores')],'Skor bukan statistik pasar atau bukti optimum semua pasangan market–mode.'),
  slide('C02-03','Build direct memberi NPV tertinggi, tetapi melampaui dua batas kelayakan','Pisahkan value dan feasibility','Four-option table',[ev('c02-expected','/modes'),ev('c02-market-entry','/decision_constraints')],'Opsi tidak layak tidak boleh menang hanya karena NPV.'),
  slide('C02-04','Partner membutuhkan Rp1,5 miliar di awal dan menghasilkan NPV dasar Rp3,095 miliar','Tunjukkan economics','Cashflow chart + NPV summary',[ev('c02-expected','/modes/1'),ev('c02-market-entry','/model_basis')],'Kas tahunan; diskonto 12%; bukan return pasti.'),
  slide('C02-05','NPV partner tetap positif saat annual contribution turun 20%','Uji downside','Scenario comparison',[ev('c02-market-entry','/downside'),ev('c02-expected','/modes/1/downside_npv')],'Sensitivity bukan probabilitas; opex dan initial cost tetap.'),
  slide('C02-06','Otorisasi dana Rp1,5 miliar diminta dengan tiga syarat pelepasan','Decision ask','Approval conditions and fallback',[ev('c02-market-entry','/decision')],'DEC-C02-01 REQUESTED_NOT_APPROVED; fallback do nothing.') ]},
 {'id':'SB-C03-MONTHLY','case_id':'SYN-C03','audience':'Simulated management team','purpose':'discuss', 'slides':[
  slide('C03M-01','EBIT Juni tertinggal Rp1,1 miliar dari anggaran','Tunjukkan exception','Actual-budget scorecard',[ev('c03-expected','/monthly_actual'),ev('c03-expected','/monthly_budget'),ev('c03-expected','/monthly_ebit_variance')],'Juni adalah bagian dari YTD, bukan periode tambahan.'),
  slide('C03M-02','Volume dan harga menjelaskan Rp0,975 miliar penurunan EBIT Juni','Jelaskan drivers','Signed variance bridge',[ev('c03-expected','/ebit_bridge')],'Driver biaya tetap ditampilkan agar total -1,1 direkonsiliasi.'),
  slide('C03M-03','Forecast EBIT FY menjadi Rp16,6 miliar setelah aksi committed Rp0,5 miliar','Perbarui outlook','Forecast bridge',[ev('c03-performance-review','/forecast'),ev('c03-expected','/final_forecast_ebit'),ev('c03-expected','/committed_ebit_actions')],'Potential savings Rp0,6 tidak termasuk.'),
  slide('C03M-04','Kas Juni berada Rp0,5 miliar di bawah batas operasi','Ungkap liquidity issue','Cash bridge + floor',[ev('c03-performance-review','/cash'),ev('c03-expected','/closing_cash'),ev('c03-expected','/cash_gap_to_floor')],'Arus kas tidak disamakan dengan EBIT.'),
  slide('C03M-05','Empat aksi memiliki owner dan tenggat, dengan status manfaat yang berbeda','Akuntabilitas','Issue-action-owner-due table',[ev('c03-performance-review','/actions'),ev('c03-performance-review','/decisions')],'Committed, conditional dan potential tidak dijumlahkan sebagai forecast.'),
  slide('C03M-06','Perubahan credit control perlu keputusan board pada 8 Juli','Tetapkan eskalasi','Decision and escalation log',[ev('c03-performance-review','/decisions/1')],'Forum management tidak mengubah board request menjadi approved.') ]},
 {'id':'SB-C03-BOARD','case_id':'SYN-C03','audience':'Simulated Board','purpose':'decide', 'slides':[
  slide('C03B-01','Forecast EBIT FY Rp16,6 miliar masih di bawah budget Rp18,0 miliar','Executive exception','Summary with gap and ask',[ev('c03-performance-review','/forecast'),ev('c03-expected','/final_forecast_ebit')],'Forecast bukan actual.'),
  slide('C03B-02','EBIT YTD Rp7,1 miliar menuntut Rp9,5 miliar pada H2 untuk mencapai forecast','Tunjukkan implied requirement','YTD + H2 bridge',[ev('c03-expected','/ytd_ebit'),ev('c03-expected','/implied_h2_ebit'),ev('c03-expected','/final_forecast_ebit')],'Kebutuhan H2 tidak dipresentasikan sebagai hasil terjamin.'),
  slide('C03B-03','Penagihan tambahan Rp0,8 miliar dapat membawa kas Juli ke floor Rp3,0 miliar','Pisahkan liquidity dan profit','Conditional cash scenario',[ev('c03-performance-review','/cash'),ev('c03-performance-review','/actions/2'),ev('c03-expected','/conditional_july_cash')],'Dampak conditional dan cash-only.'),
  slide('C03B-04','Penghematan potensial Rp0,6 miliar belum dimasukkan ke forecast','Jelaskan upside yang belum valid','Benefit status table',[ev('c03-performance-review','/actions/3'),ev('c03-performance-review','/decisions/2')],'Jangan menambahkan benefit yang belum memenuhi status.'),
  slide('C03B-05','Board diminta menyetujui credit control dan eskalasi kas mingguan','Decision ask','Decision conditions',[ev('c03-performance-review','/decisions/1')],'Status REQUESTED_NOT_APPROVED.') ]},
 {'id':'SB-C04','case_id':'SYN-C04','audience':'Simulated Investment Committee','purpose':'decide', 'slides':[
  slide('C04-01','Base investment layak menurut asumsi kasus; komitmen penuh menunggu penanganan downside','Rekomendasi bersyarat','Decision summary',[ev('c04-expected','/gates'),ev('c04-expected','/recommendation')],'Tidak menyatakan unconditional go.'),
  slide('C04-02','Dana awal Rp5,0 miliar mencakup capex, implementasi, dan working capital','Jelaskan investment scope','Initial funding bridge',[ev('c04-investment-case','/initial'),ev('c04-investment-case','/perspective')],'Pre-tax project cashflow; financing tidak dimasukkan.'),
  slide('C04-03','Base cashflow kembali positif secara kumulatif pada akhir tahun ke-4','Tunjukkan timing','Annual cashflow and cumulative table',[ev('c04-expected','/scenarios/0/cashflows'),ev('c04-expected','/scenarios/0/cumulative_cash'),ev('c04-expected','/scenarios/0/observed_period_end_payback')],'Payback undiscounted period-end, bukan interpolasi tanggal.'),
  slide('C04-04','Jadwal kas base menghasilkan XNPV Rp2,672 miliar dan XIRR 25,94%','Tunjukkan return','Return summary with basis',[ev('c04-expected','/scenarios/0'),ev('c04-investment-case','/discount_basis'),ev('c04-investment-case','/timing')],'Actual days/365; hurdle 10% sintetis; recovery/disposal adalah asumsi.'),
  slide('C04-05','Combined downside menghasilkan XNPV negatif dan kebutuhan awal Rp5,8 miliar','Uji robustness','Scenario and gate matrix',[ev('c04-expected','/scenarios'),ev('c04-expected','/gates'),ev('c04-investment-case','/decision/base_funding_ceiling')],'Ceiling Rp5,5 terlampaui; jangan sembunyikan pada appendix.'),
  slide('C04-06','Otorisasi ulang diperlukan sebelum komitmen penuh jika batas downside atau biaya terlampaui','Keputusan dan syarat','Conditional approval checklist',[ev('c04-investment-case','/decision')],'REQUESTED_NOT_APPROVED; persetujuan tidak disimpulkan dari IRR.') ]}
]
for b in boards:
    for s in b['slides']:
        s['source_footer'] = f"Sumber: {b['case_id']}, kasus orisinal sintetis; bukan data perusahaan nyata."
write(ROOT / 'cases/storyboards.json', {'status':'ORIGINAL_SYNTHETIC_DEVELOPMENT_STORYBOARDS_NOT_RENDERED', 'boards':boards})
lines = ['# Storyboards orisinal — 4 alur / 23 content slides', '',
         '**SINTETIS. Belum dirender menjadi PPTX.** Setiap baris adalah usulan slide, bukan hasil visual yang telah dinilai. Semua nominal Rp miliar. Dua varian C03 memakai dataset yang sama dan tidak boleh dianggap dua independent test cases.', '',
         'Pointer ke input/expected output dan guardrail per slide tersedia pada `storyboards.json`. Semua source footers menamai SYN-*; sumber McKinsey/pihak lain tidak diatribusikan sebagai sumber angka.', '']
for b in boards:
    lines += [f"## {b['id']} — {b['audience']}", '', f"Tujuan forum: **{b['purpose']}**. Dataset: {b['case_id']}.", '',
              '| Slide | Action title | Exhibit | Hal yang harus dijaga |', '|---|---|---|---|']
    for s in b['slides']:
        lines.append(f"| {s['slide_id']} | {s['action_title']} | {s['exhibit']} | {s['guardrail']} |")
    lines.append('')
(ROOT / 'cases/storyboards.md').write_text('\n'.join(lines))

prior_coverage = read(HISTORY / 'phase1-mvp-coverage.json')
coverage = []
for c in prior_coverage['categories']:
    cid = c['category']
    syn = {'C02':'SYN-C02','C03':'SYN-C03','C04':'SYN-C04'}.get(cid)
    coverage.append(dict(category=cid, name=c['name'], product_scope='MVP',
                         real_reference_status=c['status'],
                         synthetic_integration_case=syn,
                         permitted_now='WRITE_STANDARD_FROM_TRACEABLE_PATTERNS_AND_LABELED_ORIGINAL_EXAMPLES',
                         source_limits='RETAINED_OPEN; see R-'+cid if syn else 'Reference foundation only; no product validation claim',
                         release_validation='Human gold review, independent rubric calibration, generated-deck QA and platform tests remain pending'))
write(ROOT / 'phase1-mvp-status-2026-09-18.json', {'date':'2026-09-18','decision':'DR-P1-02','categories':coverage})
with (ROOT / 'phase1-mvp-status-2026-09-18.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)

numeric=read(ROOT/'validation/reference-case-validation.json')
scorechecks=read(ROOT/'validation/scorecard-validation.json')
old_checkpoint=read(HISTORY/'phase1-checkpoint.json')
checkpoint=dict(date='2026-09-18', project='Productive AI / Consulting Deck OS', decision_id='DR-P1-02',
 phase1_blueprint_gate='COMPLETE_FOR_STANDARD_WITH_DOCUMENTED_LIMITS',
 extended_real_source_gaps='RETAINED_OPEN_AND_DISPOSITIONED_BY_DR_P1_02',
 residual_source_gaps=['R-C02','R-C03','R-C04'], human_gold_review='PENDING',
 phase2_status='IN_PROGRESS_CALIBRATION_REQUIRED', standard_version='0.1',
 two_reviewer_calibration='NOT_RUN', production_gold_approved=0,
 source_documents=old_checkpoint['stats']['source_documents'],
 source_pages_or_slides=old_checkpoint['stats']['source_pages_or_slides'],
 annotation_records=old_checkpoint['stats']['consolidated_annotation_records'],
 reference_decisions=old_checkpoint['stats']['reference_decisions'],
 rule_candidates_mapped=len(crosswalk), new_external_sources=0,
 original_development_cases=3, storyboard_variants=len(boards), storyboard_slide_count=sum(len(b['slides']) for b in boards),
 numeric_checks={'passed':numeric['passed'],'total':numeric['total'],'independent_methods':numeric['independent_numeric_crosscheck']},
 scorecard_aggregation_checks={'passed':scorechecks['passed'],'total':scorechecks['total']},
 claim_boundary='Code checks are not AI benchmarks, deck quality scores, or production validation.',
 blueprint_changed=False, phase0_changed=False, skill_or_compiler_created=False,
 pptx_created=False, platform_compatibility_tested=False, blind_holdout_established=False,
 next_step='Calibrate Phase 2 standard/rubrics using two independent reviews; preserve unverified technical checks for non-PPTX artifacts.',
 user_upload_required_now=False, icons_and_palette_phase=5, compiler_spike_phase=6,
 authority_note='Latest project status supersedes dated status snapshots in history; it does not overwrite historical evidence.')
write(ROOT / 'checkpoint-2026-09-18.json',checkpoint)

readme='''# Productive AI — Phase 1 closeout + Phase 2 foundation

18 September 2026 · **Mulai baca dari folder ini.** File di `history-2026-09-17/` adalah snapshot lama; status terakhir ada di `checkpoint-2026-09-18.json`.

## Hasil dan keputusan

- Phase 1 cukup untuk menyusun standard menurut keputusan DR-P1-02, dengan keterbatasan sumber nyata tetap tercatat.
- Tiga kasus orisinal sintetis memberi alur lengkap market entry, performance/board review, dan investment case; 51/51 pemeriksaan data/kalkulasi lulus.
- Standard, tiga rubrik, hard-fail rules, scorecard, dan crosswalk 22 kandidat Phase 1B tersedia sebagai **draft v0.1**.
- Kalibrasi dua reviewer **belum dijalankan**. Tidak ada production gold, PPTX, skill terpasang, compiler, atau compatibility pass yang diklaim.

## Urutan membaca

1. [Keputusan Phase 1](phase1-closeout.md) — koreksi gate, bukti yang tersedia, dan residual source gaps.
2. [Consulting-Grade Standard](phase2/consulting-grade-standard.md) — kontrak kualitas lintas lima MVP.
3. [Original casebook](original-casebook.md) — input, hasil, asumsi, dan batas tiga kasus sintetis.
4. [Storyboards](cases/storyboards.md) — 23 usulan content slides dalam empat alur; belum dirender.
5. [Rule crosswalk](phase2/rule-crosswalk.md) — 22 aturan Phase 1B masuk ke bagian standard/rubrik mana.
6. [Kalibrasi dua reviewer](phase2/reviewer-calibration.md) — gate Phase 2 yang masih harus dijalankan.

Rubrik terpisah: `phase2/story-rubric.md`, `slide-rubric.md`, `deck-rubric.md`; daftar kondisi gagal: `hard-fails.md`. `review-template.json` sengaja kosong. Jangan menganggapnya review yang sudah dilakukan.

## Mengulang pemeriksaan

Python 3.12 digunakan saat batch ini dijalankan. Kalkulator contoh, generator, dan scorecard memakai standard library. Verifikasi metode numerik berbeda memerlukan NumPy dan SciPy; versi yang diuji dicatat di `validation/environment.json`. Tidak ada API key atau akun AI yang diperlukan untuk tiga fixture ini.

Jalankan dari root paket:

```bash
python tools/build_examples.py
python tools/validate_examples.py
python tools/build_scorecard.py
python tools/validate_scorecard.py
python tools/build_handoff.py
```

Setelah reviewer asli melengkapi salinan template:

```bash
python tools/score_review.py path/to/completed-review.json
```

Script terakhir **hanya menghitung rating yang diberikan reviewer**; ia tidak menilai bukti atau slide sendiri. Skor parsial tidak dinormalisasi menjadi /100. Kondisi gagal mengalahkan skor tinggi; pemeriksaan wajib yang unknown menghalangi pass.

## Hubungan dengan blueprint

Blueprint asli tetap tersedia di `history-2026-09-17/history-2026-09-16/baseline/blueprint-produk-consulting-grade-ppt.md`; hasil Phase 1B dan GEI ada di folder baseline yang sama. Katalog 35 dokumen / 2.979 halaman atau slide, 170 anotasi, dan 23 keputusan referensi tetap historis. Angka jumlah halaman adalah inventaris; bukan klaim semua halaman dianalisis mendalam. Tiga SYN-* dicatat terpisah, tidak ditambahkan ke hitungan external corpus.

Paket ini memuat dokumen dan kode pengembangan orisinal beserta catatan analisis historis. Tidak memuat raw decks/PDF, logo, template berbayar, screenshot sumber, atau aset komersial pesaing. D012 tetap excluded. Belum ada lisensi produk akhir atau izin distribusi aset sumber yang disimpulkan dari tersedianya PDF publik.

Langkah berikutnya: **kalibrasi standard Phase 2**. Pengumpulan PPT umum tidak diperlukan sekarang. Ikon/palet tetap Phase 5; compiler spike tetap Phase 6. Klaim lintas Claude/GPT/Gemini/DeepSeek baru dapat dibuat untuk adapter/runtime yang benar-benar diuji.
'''
(ROOT/'README.md').write_text(readme)
print(json.dumps({'rules_mapped':len(crosswalk),'storyboards':len(boards),'slides':sum(len(b['slides']) for b in boards),'mvp_categories':len(coverage)}))
