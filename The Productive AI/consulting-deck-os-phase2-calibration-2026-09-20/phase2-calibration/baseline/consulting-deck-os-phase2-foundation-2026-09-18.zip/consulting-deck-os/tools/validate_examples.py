"""Bounded arithmetic and semantic checks for development examples, not PPTX QA."""
from pathlib import Path
from datetime import date
import copy,json,math,sys
from reference_math import D,npv,irr,xnpv,xirr,c02_flows,c03_results,c04_flows

ROOT=Path(__file__).resolve().parents[1]
def read(n):return json.loads((ROOT/'cases'/n).read_text())

def close(a,b,tol=1e-9):return math.isclose(float(a),float(b),rel_tol=0,abs_tol=tol)

def validate_c03(case,output):
    issues=[]
    if case.get('data_status')!='SYNTHETIC_ORIGINAL':issues.append('SYNTHETIC_LABEL_MISSING')
    if case['ytd'].get('includes_monthly_period') is not True:issues.append('PERIOD_SCOPE_UNRESOLVED')
    known_issues={i['issue_id'] for i in case['issues']}
    decisions={d['decision_id']:d for d in case['decisions']}
    for a in case['actions']:
        if not a.get('owner'):issues.append('ACTION_OWNER_MISSING')
        try:date.fromisoformat(a.get('due',''))
        except ValueError:issues.append('ACTION_DUE_INVALID')
        if a.get('issue_id') not in known_issues:issues.append('ACTION_ISSUE_UNRESOLVED')
        if a.get('decision_id') not in decisions:issues.append('ACTION_DECISION_UNRESOLVED')
        if a['confidence']=='COMMITTED' and decisions.get(a.get('decision_id'),{}).get('status')!='APPROVED_IN_SYNTHETIC_CASE':issues.append('COMMITTED_IMPACT_WITHOUT_AUTHORITY')
    recomputed=c03_results(case)
    for key in ['final_forecast_ebit','closing_cash','conditional_july_cash']:
        if not close(output.get(key,999999),recomputed[key]):issues.append('VALUE_MISMATCH:'+key)
    if output.get('decision_status')=='APPROVED' and decisions['DEC-C03-01']['status']=='REQUESTED_NOT_APPROVED':issues.append('APPROVAL_FABRICATED')
    return issues

def run():
    c2,c3,c4=[read(n) for n in ['c02-market-entry.json','c03-performance-review.json','c04-investment-case.json']]
    o2,o3,o4=[read(n) for n in ['c02-expected.json','c03-expected.json','c04-expected.json']]
    tests=[]
    def check(name,ok,detail=''):
        tests.append(dict(id=name,passed=bool(ok),detail=detail))
    check('NPV_t0_known_answer',close(npv(.1,[-100,110]),0))
    check('IRR_known_answer',close(irr([-100,110]),.1))
    check('XIRR_730_day_known_answer',close(xirr([-100,121],['2026-01-01','2028-01-01']),.1))
    # A public independent worked example, not a fabricated expected number.
    official=xnpv(.09,[-10000,2750,4250,3250,2750],['2008-01-01','2008-03-01','2008-10-30','2009-02-15','2009-04-01'])
    check('Microsoft_XNPV_worked_example',round(official,2)==2086.65,'https://support.microsoft.com/en-us/excel/functions/xnpv-function')
    for name,values,message in [('IRR_all_positive_rejected',[1,2,3],'IRR_UNDEFINED_NO_SIGN_CHANGE'),('IRR_multiple_sign_changes_held',[-100,230,-132],'IRR_NONCONVENTIONAL_REQUIRES_REVIEW')]:
        try:irr(values);ok=False
        except ValueError as e:ok=str(e)==message
        check(name,ok)
    check('C02_weights_sum_1',close(sum(c2['market_weights'].values()),1))
    check('C02_market_score_known_answer',o2['selected_market']=='Market B' and close(o2['market_scores']['Market B'],4.2))
    check('C02_partner_cashflow_hand_reconciled',o2['modes'][1]['cashflows']==[-1.5,.6,1,1.4,1.6,2.2])
    best_raw=max(o2['modes'],key=lambda x:x['npv'])
    check('C02_highest_NPV_can_be_excluded',not best_raw['eligible'] and best_raw['mode']!=o2['selected_mode'])
    check('C02_select_feasible_partner',o2['selected_mode']=='partner' and o2['modes'][1]['eligible'])
    check('C02_requested_is_not_approved',o2['decision_status']=='REQUESTED_NOT_APPROVED')
    check('C03_June_EBIT_known_answer',close(o3['monthly_actual']['ebit'],.4) and close(o3['monthly_budget']['ebit'],1.5))
    check('C03_EBIT_bridge_reconciles',close(sum(o3['ebit_bridge'].values()),-1.1) and close(o3['monthly_ebit_variance'],-1.1))
    check('C03_YTD_EBIT_known_answer',close(o3['ytd_ebit']['actual'],7.1))
    check('C03_forecast_known_answer',close(o3['final_forecast_ebit'],16.6) and close(o3['implied_h2_ebit'],9.5))
    check('C03_cash_known_answer',close(o3['closing_cash'],2.5) and close(o3['conditional_july_cash'],3.0))
    check('C03_action_lineage_complete',not validate_c03(c3,o3))
    mutations=[('missing_owner',lambda c,o:c['actions'][0].update(owner=''),'ACTION_OWNER_MISSING'),
               ('missing_due',lambda c,o:c['actions'][0].update(due=''),'ACTION_DUE_INVALID'),
               ('missing_issue',lambda c,o:c['actions'][0].update(issue_id='NO_ISSUE'),'ACTION_ISSUE_UNRESOLVED'),
               ('potential_savings_included',lambda c,o:o.update(final_forecast_ebit=17.2),'VALUE_MISMATCH:final_forecast_ebit'),
               ('cash_collection_counted_as_profit',lambda c,o:o.update(final_forecast_ebit=17.4),'VALUE_MISMATCH:final_forecast_ebit'),
               ('invented_approval',lambda c,o:o.update(decision_status='APPROVED'),'APPROVAL_FABRICATED')]
    for n,fn,expected in mutations:
        c,o=copy.deepcopy(c3),copy.deepcopy(o3);fn(c,o)
        check('C03_negative_'+n,expected in validate_c03(c,o))
    base=o4['scenarios'][0]
    check('C04_cashflow_hand_reconciled',base['cashflows']==[-5,1.2,1.7,1.9,2.4,3.4])
    check('C04_final_cumulative_known_answer',close(base['cumulative_cash'][-1],5.6))
    check('C04_payback_observed_at_year_4',base['observed_period_end_payback']==4)
    check('C04_no_fake_approval',o4['decision_status']=='REQUESTED_NOT_APPROVED')
    check('C04_base_funding_vs_stress',o4['gates']['base_funding'] and not o4['gates']['combined_downside_funding'])
    # Different numerical methods: Decimal NPV / bisection versus NumPy polynomial roots and SciPy Brent solver.
    try:
        import numpy as np
        from scipy.optimize import brentq
        for c,o,prefix in [(c2,o2,'C02'),(c4,o4,'C04')]:
            entries=o['modes'] if prefix=='C02' else o['scenarios']
            for e in entries:
                flows=np.array(e['cashflows'],dtype=float)
                if not flows.any():continue
                rid=e.get('mode',e.get('scenario_id'))
                vector_npv=float(np.dot(flows,(1+float(c['discount_rate']))**(-np.arange(len(flows),dtype=float))))
                expected_npv=e['npv'] if prefix=='C02' else e['annual_npv']
                check(f'{prefix}_{rid}_independent_NPV',close(vector_npv,expected_npv))
                # Polynomial in (1+r): CF0*x^n+CF1*x^(n-1)+...+CFn=0.
                roots=np.roots(flows)
                rates=[z.real-1 for z in roots if abs(z.imag)<1e-8 and z.real>0]
                expected_irr=e['irr'] if prefix=='C02' else e['annual_irr']
                check(f'{prefix}_{rid}_independent_IRR',len(rates)==1 and close(rates[0],expected_irr,1e-8))
                if prefix=='C04':
                    dates=[date.fromisoformat(x) for x in c['cashflow_dates']]
                    tt=np.array([(x-dates[0]).days/365 for x in dates])
                    fn=lambda r:float(np.dot(flows,np.exp(-tt*np.log1p(r))))
                    independent_root=brentq(fn,-.9,10,xtol=1e-13)
                    check(f'{prefix}_{rid}_independent_XIRR',close(independent_root,e['xirr'],1e-9))
                    check(f'{prefix}_{rid}_XIRR_zero_residual',abs(fn(e['xirr']))<1e-9)
        independent='COMPLETED'
    except ImportError:
        independent='NOT_RUN_REQUIRES_NUMPY_AND_SCIPY'
    report=dict(scope='Development fixtures only; no PPTX render, editability, AI adapter or two-reviewer calibration tested',
                synthetic=True,independent_numeric_crosscheck=independent,tests=tests,total=len(tests),passed=sum(t['passed'] for t in tests))
    report['all_passed']=all(t['passed'] for t in tests) and independent=='COMPLETED'
    target=ROOT/'validation';target.mkdir(exist_ok=True)
    (target/'reference-case-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return report['all_passed']

if __name__=='__main__':sys.exit(0 if run() else 1)
