"""Materialize the agreed six-dimension scorecard and review templates."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DIMENSIONS=[
 ('STR','Strategic reasoning and storyline',25,[
  ('STR1','Decision framing','Tujuan, audience, decision question dan batas utama jelas.'),
  ('STR2','Governing thought','Ringkasan menjawab masalah dan menyatakan kondisi material.'),
  ('STR3','Horizontal logic','Urutan judul membentuk argumen tanpa lompatan logika.'),
  ('STR4','Vertical logic','Setiap pesan didukung bukti dan reasoning yang sesuai.'),
  ('STR5','Options and action','Trade-off, constraints, risiko dan tindakan mengikuti diagnosis.')]),
 ('EVI','Evidence and numeric integrity',20,[
  ('EVI1','Evidence traceability','Fakta material terhubung ke sumber yang dapat diperiksa.'),
  ('EVI2','Calculation lineage','Perhitungan dapat diulang dari input, rumus dan timing.'),
  ('EVI3','Definitions and reconciliation','Unit, periode, scope, denominator dan totals konsisten.'),
  ('EVI4','Uncertainty and status','Assumption, scenario, unknown, synthetic dan approval status jelas.')]),
 ('MSG','Slide message and copy',15,[
  ('MSG1','Action title','Content slide menyampaikan insight yang didukung exhibit.'),
  ('MSG2','Concise interpretation','Copy memberi implikasi yang relevan tanpa menenggelamkan bukti.'),
  ('MSG3','Language and consistency','Istilah, singkatan, format angka dan bahasa konsisten.')]),
 ('CHR','Chart selection and annotation',15,[
  ('CHR1','Analytical intent','Exhibit dipilih sesuai tugas; structured text boleh menjadi pilihan terbaik.'),
  ('CHR2','Truthful encoding','Sumbu, baseline, skala, unit dan visual encoding tidak menyesatkan.'),
  ('CHR3','Labels and annotations','Pembaca dapat memahami seri, delta dan konteks penting tanpa menebak.')]),
 ('VIS','Visual craft and consistency',15,[
  ('VIS1','Hierarchy and layout','Hierarchy, alignment, grid dan scan order membantu membaca.'),
  ('VIS2','Readability and density','Ukuran teks, spacing dan density sesuai mode penggunaan.'),
  ('VIS3','System consistency','Palet, tipografi, icon treatment dan komponen konsisten serta sah digunakan.')]),
 ('TEC','Technical PPTX integrity',10,[
  ('TEC1','File and render integrity','File membuka tanpa repair dan tampilan diperiksa pada aplikasi sasaran.'),
  ('TEC2','Practical editability','Konten bisnis inti bisa diedit sesuai kontrak; bukan full-slide screenshot.')])
]
HARD_FAILS=[
 ('HF01','Data atau sumber faktual diada-adakan'),
 ('HF02','Action title tidak didukung exhibit/evidence'),
 ('HF03','Angka material tidak konsisten'),
 ('HF04','Calculation error yang mengubah hasil'),
 ('HF05','Chart atau encoding menyesatkan'),
 ('HF06','Sumber factual external claim material hilang'),
 ('HF07','File tidak dapat dibuka atau meminta repair'),
 ('HF08','Clipping atau overlap material'),
 ('HF09','Elemen tak sengaja berada di luar slide'),
 ('HF10','Aset terlindungi disalin tanpa dasar penggunaan'),
 ('HF11','Konten confidential terekspos tidak sesuai izin'),
 ('HF12','Human review wajib untuk kesimpulan finansial berisiko tinggi belum dipenuhi')
]

def build():
    dimensions=[]
    for did,name,weight,criteria in DIMENSIONS:
        dimensions.append(dict(id=did,name=name,weight=weight,criteria=[dict(id=i,name=n,description=d,weight=weight/len(criteria)) for i,n,d in criteria]))
    score=dict(version='0.1',status='DRAFT_CALIBRATION_REQUIRED',pass_threshold=85,rating_scale=[0,1,2,3,4],
        anchors={0:'Tidak tersedia atau tidak dapat digunakan',1:'Kelemahan besar; perlu pengerjaan ulang',2:'Sebagian terpenuhi; perbaikan material diperlukan',3:'Memenuhi kebutuhan dengan kekurangan kecil',4:'Kuat, jelas dan konsisten; bukti rating tersedia'},
        dimensions=dimensions,hard_fail_ids=[i for i,n in HARD_FAILS],
        missing_policy='INCOMPLETE; no normalization of partial score to /100',
        final_pass_rule='All ratings supplied; every hard-fail check clear or justified not_applicable; score >=85; no failed or unknown required checks')
    folder=ROOT/'phase2';folder.mkdir(exist_ok=True)
    (folder/'weighted-scorecard.json').write_text(json.dumps(score,ensure_ascii=False,indent=2)+'\n')
    template=dict(artifact_id=None,artifact_version=None,reviewer_id=None,review_date=None,
        ratings={c['id']:None for d in dimensions for c in d['criteria']},
        rating_evidence={c['id']:[] for d in dimensions for c in d['criteria']},
        hard_fail_checks={i:{'status':'unverified','evidence':[],'reason':''} for i,n in HARD_FAILS},
        note='A template only. Null ratings are unreviewed, not zero. Use exact artifact page/slide/element as evidence.')
    (folder/'review-template.json').write_text(json.dumps(template,ensure_ascii=False,indent=2)+'\n')
    return score

if __name__=='__main__':
    s=build();print(json.dumps({'dimensions':len(s['dimensions']),'criteria':sum(len(d['criteria']) for d in s['dimensions']),'weight_sum':sum(d['weight'] for d in s['dimensions'])}))
