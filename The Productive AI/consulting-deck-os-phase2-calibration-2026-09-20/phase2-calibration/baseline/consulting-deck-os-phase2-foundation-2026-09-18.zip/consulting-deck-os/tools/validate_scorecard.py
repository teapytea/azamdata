"""Test aggregation and blocking behavior, not the quality of any real deck."""
import copy
import json
from pathlib import Path
from score_review import score

ROOT = Path(__file__).resolve().parents[1]
config = json.loads((ROOT / 'phase2/weighted-scorecard.json').read_text())
template = json.loads((ROOT / 'phase2/review-template.json').read_text())
tests = []

def check(name, condition):
    tests.append({'id': name, 'passed': bool(condition)})

def fixture(rating=4):
    r = copy.deepcopy(template)
    r.update(artifact_id='TEST_FIXTURE_ONLY', artifact_version='test', reviewer_id='TEST_NOT_A_REVIEWER', review_date='2026-09-18')
    for key in r['ratings']:
        r['ratings'][key] = rating
        r['rating_evidence'][key] = ['TEST FIXTURE: no real deck judgment asserted']
    for value in r['hard_fail_checks'].values():
        value.update(status='clear', evidence=['TEST FIXTURE ONLY'])
    return r

check('weights_total_100', sum(d['weight'] for d in config['dimensions']) == 100 and
      all(sum(c['weight'] for c in d['criteria']) == d['weight'] for d in config['dimensions']))
out = score(fixture(), config)
check('complete_top_ratings_pass', out['status'] == 'PASS' and out['total_score_100'] == 100)
out = score(fixture(3), config)
check('adequate_ratings_are_75_and_need_revision', out['status'] == 'REVISE' and out['total_score_100'] == 75)
r = fixture(); r['hard_fail_checks']['HF04']['status'] = 'failed'
check('hard_failure_overrides_high_score', score(r, config)['status'] == 'FAIL_HARD_CONDITION')
r = fixture(); r['ratings']['TEC1'] = None; r['ratings']['TEC2'] = None
out = score(r, config)
check('partial_technical_review_is_not_normalized', out['status'] == 'INCOMPLETE' and out['total_score_100'] is None and out['reviewed_maximum'] == 90)
r = fixture(); r['hard_fail_checks']['HF07']['status'] = 'unverified'
out = score(r, config)
check('unknown_required_check_blocks_pass', out['status'] == 'INCOMPLETE' and out['total_score_100'] is None)
r = fixture(); r['rating_evidence']['EVI2'] = []
check('rating_without_evidence_blocks_pass', score(r, config)['status'] == 'INCOMPLETE')
r = fixture(); r['ratings']['EVI2'] = 5
try:
    score(r, config); invalid_rejected = False
except ValueError as exc:
    invalid_rejected = str(exc) == 'INVALID_RATING:EVI2'
check('out_of_range_rating_rejected', invalid_rejected)
r = fixture(); r['reviewer_id'] = None
check('anonymous_unattributed_review_incomplete', score(r, config)['status'] == 'INCOMPLETE')
r = fixture(); r['hard_fail_checks']['HF12'].update(status='not_applicable', reason='')
check('not_applicable_requires_reason', score(r, config)['status'] == 'INCOMPLETE')
out = score(template, config)
check('blank_template_never_passes', out['status'] == 'INCOMPLETE' and out['reviewed_maximum'] == 0)
report = {'scope': 'Scorecard aggregation only; fixtures are not independent reviews or quality ratings.',
          'tests': tests, 'total': len(tests), 'passed': sum(t['passed'] for t in tests),
          'all_passed': all(t['passed'] for t in tests)}
(ROOT / 'validation/scorecard-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'tests'}))
raise SystemExit(0 if report['all_passed'] else 1)
