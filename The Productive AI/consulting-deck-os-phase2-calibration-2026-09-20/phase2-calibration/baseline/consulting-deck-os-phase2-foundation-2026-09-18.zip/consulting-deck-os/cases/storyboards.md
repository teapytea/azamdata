# Storyboards orisinal — 4 alur / 23 content slides

**SINTETIS. Belum dirender menjadi PPTX.** Setiap baris adalah usulan slide, bukan hasil visual yang telah dinilai. Semua nominal Rp miliar. Dua varian C03 memakai dataset yang sama dan tidak boleh dianggap dua independent test cases.

Pointer ke input/expected output dan guardrail per slide tersedia pada `storyboards.json`. Semua source footers menamai SYN-*; sumber McKinsey/pihak lain tidak diatribusikan sebagai sumber angka.

## SB-C02 — Simulated Investment Committee

Tujuan forum: **decide**. Dataset: SYN-C02.

| Slide | Action title | Exhibit | Hal yang harus dijaga |
|---|---|---|---|
| C02-01 | Kemitraan menjadi opsi masuk Market B yang memenuhi batas dana dan waktu | Executive decision summary | Permintaan approval belum disetujui. |
| C02-02 | Market B memimpin shortlist sintetis dengan skor 4,2 | Weighted option table | Skor bukan statistik pasar atau bukti optimum semua pasangan market–mode. |
| C02-03 | Build direct memberi NPV tertinggi, tetapi melampaui dua batas kelayakan | Four-option table | Opsi tidak layak tidak boleh menang hanya karena NPV. |
| C02-04 | Partner membutuhkan Rp1,5 miliar di awal dan menghasilkan NPV dasar Rp3,095 miliar | Cashflow chart + NPV summary | Kas tahunan; diskonto 12%; bukan return pasti. |
| C02-05 | NPV partner tetap positif saat annual contribution turun 20% | Scenario comparison | Sensitivity bukan probabilitas; opex dan initial cost tetap. |
| C02-06 | Otorisasi dana Rp1,5 miliar diminta dengan tiga syarat pelepasan | Approval conditions and fallback | DEC-C02-01 REQUESTED_NOT_APPROVED; fallback do nothing. |

## SB-C03-MONTHLY — Simulated management team

Tujuan forum: **discuss**. Dataset: SYN-C03.

| Slide | Action title | Exhibit | Hal yang harus dijaga |
|---|---|---|---|
| C03M-01 | EBIT Juni tertinggal Rp1,1 miliar dari anggaran | Actual-budget scorecard | Juni adalah bagian dari YTD, bukan periode tambahan. |
| C03M-02 | Volume dan harga menjelaskan Rp0,975 miliar penurunan EBIT Juni | Signed variance bridge | Driver biaya tetap ditampilkan agar total -1,1 direkonsiliasi. |
| C03M-03 | Forecast EBIT FY menjadi Rp16,6 miliar setelah aksi committed Rp0,5 miliar | Forecast bridge | Potential savings Rp0,6 tidak termasuk. |
| C03M-04 | Kas Juni berada Rp0,5 miliar di bawah batas operasi | Cash bridge + floor | Arus kas tidak disamakan dengan EBIT. |
| C03M-05 | Empat aksi memiliki owner dan tenggat, dengan status manfaat yang berbeda | Issue-action-owner-due table | Committed, conditional dan potential tidak dijumlahkan sebagai forecast. |
| C03M-06 | Perubahan credit control perlu keputusan board pada 8 Juli | Decision and escalation log | Forum management tidak mengubah board request menjadi approved. |

## SB-C03-BOARD — Simulated Board

Tujuan forum: **decide**. Dataset: SYN-C03.

| Slide | Action title | Exhibit | Hal yang harus dijaga |
|---|---|---|---|
| C03B-01 | Forecast EBIT FY Rp16,6 miliar masih di bawah budget Rp18,0 miliar | Summary with gap and ask | Forecast bukan actual. |
| C03B-02 | EBIT YTD Rp7,1 miliar menuntut Rp9,5 miliar pada H2 untuk mencapai forecast | YTD + H2 bridge | Kebutuhan H2 tidak dipresentasikan sebagai hasil terjamin. |
| C03B-03 | Penagihan tambahan Rp0,8 miliar dapat membawa kas Juli ke floor Rp3,0 miliar | Conditional cash scenario | Dampak conditional dan cash-only. |
| C03B-04 | Penghematan potensial Rp0,6 miliar belum dimasukkan ke forecast | Benefit status table | Jangan menambahkan benefit yang belum memenuhi status. |
| C03B-05 | Board diminta menyetujui credit control dan eskalasi kas mingguan | Decision conditions | Status REQUESTED_NOT_APPROVED. |

## SB-C04 — Simulated Investment Committee

Tujuan forum: **decide**. Dataset: SYN-C04.

| Slide | Action title | Exhibit | Hal yang harus dijaga |
|---|---|---|---|
| C04-01 | Base investment layak menurut asumsi kasus; komitmen penuh menunggu penanganan downside | Decision summary | Tidak menyatakan unconditional go. |
| C04-02 | Dana awal Rp5,0 miliar mencakup capex, implementasi, dan working capital | Initial funding bridge | Pre-tax project cashflow; financing tidak dimasukkan. |
| C04-03 | Base cashflow kembali positif secara kumulatif pada akhir tahun ke-4 | Annual cashflow and cumulative table | Payback undiscounted period-end, bukan interpolasi tanggal. |
| C04-04 | Jadwal kas base menghasilkan XNPV Rp2,672 miliar dan XIRR 25,94% | Return summary with basis | Actual days/365; hurdle 10% sintetis; recovery/disposal adalah asumsi. |
| C04-05 | Combined downside menghasilkan XNPV negatif dan kebutuhan awal Rp5,8 miliar | Scenario and gate matrix | Ceiling Rp5,5 terlampaui; jangan sembunyikan pada appendix. |
| C04-06 | Otorisasi ulang diperlukan sebelum komitmen penuh jika batas downside atau biaya terlampaui | Conditional approval checklist | REQUESTED_NOT_APPROVED; persetujuan tidak disimpulkan dari IRR. |
