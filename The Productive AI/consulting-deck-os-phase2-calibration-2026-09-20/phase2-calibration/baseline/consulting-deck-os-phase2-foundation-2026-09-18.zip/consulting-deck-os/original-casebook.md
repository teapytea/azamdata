# Original development casebook — C02, C03, C04

Productive AI / Consulting Deck OS · 18 September 2026 · v0.1

**Semua kasus, angka, perusahaan, pasar, jabatan, tenggat, dan keputusan berikut adalah simulasi orisinal.** Kasus ini menguji integrasi alur dan perhitungan; bukan laporan McKinsey/BCG, benchmark produk, atau rekomendasi investasi nyata. Satuan nominal: **Rp miliar** kecuali dinyatakan lain. Nilai display dibulatkan; kode menghitung dari input penuh.

## Cara menggunakan

1. Baca input `cases/c02-market-entry.json`, `c03-performance-review.json`, atau `c04-investment-case.json`.
2. Susun cerita mengikuti tujuan forum dan constraints, menggunakan storyboard sebagai contoh pengembangan.
3. Cocokkan angka dengan `*-expected.json`; gunakan kode untuk mengulang perhitungan.
4. Terapkan standard/rubrik pada hasil. Kasus yang benar secara angka masih bisa gagal pada storyline, visual, atau editability.

Sumber pola memakai ID dokumen dan halaman dari katalog historis. Angka sintetis tidak diturunkan dari angka sumber. Semua SYN-* termasuk **development set**, bukan blind holdout.

## SYN-C02 — Market entry

Pertanyaan: pasar mana yang diprioritaskan, lalu bagaimana memasuki pasar tersebut dalam batas dana awal 3,0 dan waktu peluncuran enam bulan?

Shortlist sintetis memakai skor ordinal 1–5; lebih tinggi lebih baik. Bobot demand 30%, economics 30%, reach 20%, dan risk resilience 20%. Skor tertimbang A = 4,1; **B = 4,2**; C = 3,8. Selisih kecil ini merupakan alat prioritisasi berdasarkan asumsi kasus, bukan bukti bahwa B secara objektif terbaik di dunia nyata. Economics berikut hanya mengevaluasi entry modes untuk B; tidak membuktikan optimasi gabungan semua pasangan pasar–mode.

Basis model: incremental project cash flow sebelum pajak dan pendanaan, nominal; t0 ditambah lima periode tahunan sama panjang; diskonto asumsi 12%. Working capital dipulihkan pada t5; tidak ada going-concern terminal value. Contribution sudah memasukkan timing/ramp, kemudian dikurangi opex.

| Opsi B | Dana awal | Launch bulan | NPV dasar | NPV downside | Hasil hard gates |
|---|---:|---:|---:|---:|---|
| Do nothing | 0,0 | — | 0,000 | 0,000 | Fallback; tidak ada launch |
| Partner | 1,5 | 4 | 3,095 | 1,579 | Memenuhi seluruh batas |
| Build direct | 4,8 | 9 | 8,965 | 4,638 | Gagal dana dan waktu |
| Acquire | 6,5 | 4 | 3,921 | 0,397 | Gagal dana |

Downside menurunkan annual contribution 20%; opex dan biaya awal tetap. NPV dasar/downside harus nonnegative menurut batas kasus. Partner memiliki cash flow `[-1.5, 0.6, 1.0, 1.4, 1.6, 2.2]`. Angka 2,2 terakhir termasuk pemulihan working capital 0,5.

Rekomendasi contoh: minta otorisasi masuk lewat partner dengan dana awal maksimal 1,5. Status **REQUESTED_NOT_APPROVED**, decision `DEC-C02-01`, simulated Investment Committee, 1 Oktober 2026. Pelepasan dana bersyarat kontrak, validasi economics oleh CFO, dan launch plan yang tetap memenuhi batas. Jika syarat gagal, kembali ke do nothing; jangan mengganti diam-diam dengan opsi yang tidak layak.

Pelajaran produk: weighted score tidak menggantikan cashflow; NPV tertinggi tidak mengalahkan hard constraint; recommendation tidak sama dengan approval. Keterbatasan: tidak ada probabilitas skenario, confidence interval market score, tax, FX, atau joint market–mode optimization.

Pola struktur: D005:721, D033:14/125, D035:4. Sumber angka: **SYN-C02 original inputs**, bukan dokumen-dokumen tersebut.

## SYN-C03 — Monthly management dan board review

As-of 30 Juni 2026; rapat 8 Juli 2026. Satu dataset digunakan untuk dua audience. Monthly management menekankan drivers dan pemilik aksi; board menekankan outlook, liquidity, dan keputusan yang membutuhkan kewenangannya.

| Metrik | Budget | Actual | Actual − budget |
|---|---:|---:|---:|
| Juni revenue | 10,000 | 9,025 | -0,975 |
| Juni EBIT | 1,500 | 0,400 | -1,100 |
| YTD EBIT | 9,000 | 7,100 | -1,900 |

Juni sudah termasuk YTD. EBIT = revenue − direct cost − opex. Revenue menggunakan unit × harga: budget 10.000 × Rp1.000.000; actual 9.500 × Rp950.000. **Bridge EBIT**: volume -0,500; price -0,475; direct cost +0,025; opex -0,150; total -1,100. Dekomposisi revenue memakai volume pada harga budget lalu price pada volume actual; metode urutan ini dinyatakan agar interaction tidak dihitung dua kali. Direct-cost variance tetap total perubahan biaya, bukan klaim efisiensi unit-cost.

**Forecast FY2026:** versi sebelumnya 17,6 → demand -0,8 → pricing -0,5 → opex -0,2 = 16,1 sebelum aksi → committed actions +0,5 = **16,6**. Budget FY 18,0. Dengan actual YTD 7,1, forecast tersebut memerlukan H2 sebesar **9,5**. Ini implied requirement, bukan hasil yang sudah dicapai.

| Action | Issue / dampak | Owner sintetis | Tenggat | Status / confidence | Authority |
|---|---|---|---|---|---|
| ACT-01 | Volume / +0,3 FY EBIT | Head of Sales | 15 Jul | In progress / committed | DEC-C03-00 |
| ACT-02 | Price / +0,2 FY EBIT | Commercial Director | 10 Jul | Planned / committed | DEC-C03-00 |
| ACT-03 | Cash / +0,8 kas Juli saja | Accounts Receivable Lead | 12 Jul | Proposed / conditional | DEC-C03-01 |
| ACT-04 | Opex / +0,6 FY EBIT potensial | COO | 20 Jul | Draft / potential | DEC-C03-02 |

`DEC-C03-00` telah disetujui **dalam simulasi** oleh CFO pada 25 Juni. “Committed” berarti klasifikasi planning pada kasus ini, bukan jaminan realisasi. Dua action pertama sudah masuk forecast 16,6; jangan ditambahkan lagi. ACT-04 belum masuk forecast karena belum tervalidasi.

**Kas Juni:** 3,2 opening + 8,5 receipts − 5,9 supplier − 2,4 staff/overhead − 0,7 capex − 0,2 loan principal = **2,5**, atau 0,5 di bawah floor 3,0. Base forecast kas Juli 2,2 merupakan input skenario eksplisit. Jika ACT-03 terealisasi, kas Juli mencapai **3,0**. Penagihan piutang tidak menambah EBIT dan tidak otomatis membuktikan pemulihan penjualan.

Board diminta menyetujui perubahan credit control serta eskalasi kas mingguan (`DEC-C03-01`, **REQUESTED_NOT_APPROVED**). Tambahan penghematan hanya untuk dibahas pada Executive Committee (`DEC-C03-02`, **NOT_DECIDED**).

Pelajaran produk: bedakan actual/budget/forecast, period flow/cumulative, laba/kas, proposal/approval/hasil. Rantai issue → action → owner → due → authority harus dapat dilacak. Pola struktur D031:39, D032:146/164/165, D034:58, D035:13; angka sepenuhnya orisinal.

## SYN-C04 — Business case automasi

Pertanyaan: apakah investasi dapat diajukan berdasarkan return, kebutuhan pendanaan, dan risiko downside?

Basis: incremental project cashflow sebelum tax/financing; nominal; do nothing = nol. Tidak memodelkan tax shield, financing flows, existing business, sunk cost, atau going-concern terminal value. Diskonto 10% adalah hurdle sintetis untuk latihan, bukan market WACC. Seluruh kas diakui pada tanggal 31 Desember yang tertera; XNPV/XIRR memakai actual days/365.

| Komponen | t0 2026 | 2027 | 2028 | 2029 | 2030 | 2031 |
|---|---:|---:|---:|---:|---:|---:|
| Initial capex | -4,0 | — | — | — | — | — |
| Implementation | -0,4 | — | — | — | — | — |
| Initial working capital | -0,6 | — | — | — | — | — |
| Cash benefit | — | 1,6 | 2,2 | 2,8 | 3,0 | 3,0 |
| Incremental cash opex | — | -0,4 | -0,5 | -0,6 | -0,6 | -0,6 |
| Maintenance capex | — | — | — | -0,3 | — | — |
| Working-capital recovery | — | — | — | — | — | 0,6 |
| Disposal proceeds | — | — | — | — | — | 0,4 |
| **Net cash flow** | **-5,0** | **1,2** | **1,7** | **1,9** | **2,4** | **3,4** |
| Cumulative cash | -5,0 | -3,8 | -2,1 | -0,2 | 2,2 | 5,6 |

Annual equal-period NPV = 2,673731 dan IRR = 25,964992%. Berdasarkan tanggal sebenarnya, **XNPV = 2,672012 dan XIRR = 25,943687%**. Selisih kecil berasal dari timing/day-count, bukan angka yang dapat dipertukarkan tanpa label. Undiscounted payback pertama yang teramati pada period-end adalah **tahun ke-4**; tidak mengklaim interpolasi sebagai tanggal pembayaran nyata.

| Skenario | Perubahan | Dana awal | XNPV | XIRR | Implikasi |
|---|---|---:|---:|---:|---|
| Base | Input awal | 5,0 | 2,672 | 25,94% | Memenuhi batas base |
| Benefit down 20% | Benefit ×0,8 | 5,0 | 0,815 | 15,13% | Return lebih rendah |
| Capex up 20% | Initial + maintenance capex ×1,2 | 5,8 | 1,827 | 19,78% | Melewati funding ceiling 5,5 |
| Combined downside | Benefit ×0,8; opex ×1,15; capex ×1,2 | 5,8 | -0,332 | 8,11% | Gagal downside NPV dan ceiling |

Implementation, working capital, dan disposal tetap dalam sensitivitas ini. Recovery/disposal adalah asumsi yang perlu diperiksa, bukan nilai pasti.

`DEC-C04-01` meminta persetujuan base investment bersyarat oleh simulated Investment Committee pada 15 Oktober 2026, **REQUESTED_NOT_APPROVED**. Hasil stress test berarti **komitmen penuh ditahan** sampai downside/cost ditangani dan otorisasi ulang tersedia. Jangan mengubah headline menjadi “investasi pasti layak” hanya karena base IRR tinggi.

Pola struktur D003:21/47 dan D033:124/125/129/143. Angka D033 tetap belum direkonsiliasi; kasus orisinal ini tidak membenarkan angka sumber tersebut.

## Hasil verifikasi dan batas penggunaan

51 pemeriksaan data/kalkulasi lulus. Pemeriksaan mencakup manual reconciliation, known-answer math, contoh XNPV resmi Microsoft, negative mutations pada lineage, dan metode numerik berbeda: Decimal/bisection dibanding NumPy polynomial roots dan SciPy Brent solver. Detail per check ada di `validation/reference-case-validation.json`.

Rujukan metode: [Microsoft IRR](https://support.microsoft.com/en-us/excel/functions/irr-function) dan [Microsoft XNPV](https://support.microsoft.com/en-us/excel/functions/xnpv-function). Implementasi ini kalkulator terbatas untuk tiga development cases; belum general-purpose financial-model engine.

Storyboards berikutnya adalah contoh alur pesan, bukan slide yang sudah dirender. Tidak ada klaim skor visual, PPTX editability, AI compatibility, human gold review, atau lulus kalibrasi dua reviewer.
