# Phase 1B - Tambahan referensi visual McKinsey GEI 2024

Tanggal pemeriksaan: 15 September 2026  
Proyek: Productive AI - PPT consulting-grade  
ID sumber tambahan: D030  
Status: review tambahan selesai; gate korpus Phase 1 tetap IN PROGRESS.

## 1. Keputusan

**Global Economics Intelligence edisi Februari 2024 layak menjadi referensi tambahan untuk tampilan slide analitis modern.** Anchor terkuat adalah halaman 8: satu kesimpulan, grafik dominan, dan commentary di samping. Pola ini relevan dengan komposisi pada screenshot yang menjadi target pengguna.

Prioritas visual tetap mengikuti arahan terbaru pengguna: McKinsey 2024-2026. D030 melengkapi D001 *Advancing Adaptation* (2026), D017 *Emerging Generative AI Use Cases in Credit* (2025), dan D026 *Taking Action on Nature* (2024). Ketiga sumber tersebut sudah ada dalam korpus; review ini berfokus pada tambahan GEI.

GEI merupakan laporan ekonomi berkala dalam format slide, dengan banyak halaman untuk dibaca dekat. Produk perlu mengambil prinsip hierarki dan hubungan analitisnya, lalu menyesuaikan kepadatan dengan cara presentasi akan digunakan.

## 2. Validasi file dan provenance

| Item | Hasil |
|---|---|
| Unggahan pengguna | `gei-global-summary-february-2024.pdf.crdownload` |
| Ukuran unggahan | 1.725.939 byte |
| Kondisi unggahan | Unduhan parsial; penanda akhir PDF tidak ditemukan dan halaman tidak dapat dibaca |
| Sumber yang dipakai untuk review | PDF lengkap yang sudah diperoleh dari tautan resmi McKinsey pada pemilihan referensi sebelumnya |
| Ukuran PDF lengkap | 3.494.251 byte |
| Pencocokan | Seluruh byte unggahan cocok dengan bagian awal PDF lengkap |
| Validasi PDF lengkap | Parser strict berhasil membaca 29 halaman; renderer membuka tanpa perbaikan struktur |
| Format halaman | Seluruhnya 960 x 540 point, rasio 16:9 |
| Tanggal pada cover | Dirilis Februari 2024; cover menyebut data sampai Januari 2024 |

SHA-256 PDF lengkap: `5ae3432e9edd1744e81aaf33c680db7de08e192e27e47847b6c2e763cb991e4a`.

Sumber: [PDF resmi McKinsey - GEI Februari 2024](https://www.mckinsey.com/~/media/mckinsey/business%20functions/strategy%20and%20corporate%20finance/our%20insights/global%20economics%20intelligence%20executive%20summary%20february%202024/gei-global-summary-february-2024.pdf?shouldindex=false). Pada [katalog Analyst Academy](https://www.theanalystacademy.com/consulting-presentations/), tautannya diberi judul *Global Economics Intelligence January 2024*.

Beberapa halaman memuat pembaruan Februari. Karena itu, tanggal rilis laporan dan periode setiap metrik harus dicatat terpisah.

## 3. Cakupan pemeriksaan

- Metadata dan teks diekstrak untuk 29 halaman; halaman penutup tidak menghasilkan teks.
- Seluruh 29 halaman dirender dan ditinjau melalui empat contact sheet untuk melihat struktur dan konsistensi layout.
- Enam halaman diperiksa lagi secara individual pada preview 1.152 x 648 piksel: 8, 9, 11, 18, 21, dan 27.
- Font, ukuran teks, posisi elemen teks, dan sebagian warna vektor diperiksa dari PDF.

Nomor halaman dalam laporan ini adalah nomor halaman PDF mulai dari 1. Pemeriksaan ini bukan audit seluruh data ekonomi, pemeriksaan pixel-perfect, atau pengujian editabilitas PPTX native.

## 4. Struktur deck

| Bagian | Halaman PDF | Jumlah |
|---|---|---:|
| Cover | 1 | 1 |
| Disclaimer | 2 | 1 |
| Executive summary | 3-5 | 3 |
| Pembatas kelompok ekonomi | 6, 16 | 2 |
| Ringkasan negara/wilayah dengan foto | 7, 10, 13, 17, 20, 23, 26 | 7 |
| Exhibit analitis | 8, 11, 14, 18, 21, 24, 27 | 7 |
| Heatmap indikator dan penjelasan | 9, 12, 15, 19, 22, 25, 28 | 7 |
| Penutup | 29 | 1 |
| **Total** | | **29** |

Pola berulangnya adalah **ringkasan wilayah -> bukti grafik -> status indikator**. Untuk produk, pengulangan seperti ini dapat menjadi struktur per unit bisnis, pasar, atau segmen, asalkan jenis bukti dan kebutuhan keputusan memang cocok.

## 5. Anchor visual dan implikasi untuk produk

| Anchor | Yang diamati | Keputusan desain yang disarankan |
|---|---|---|
| Hlm.8 | Grafik besar, commentary sempit di kanan, anotasi perubahan, sumber di bawah | Kandidat utama varian A06: trend dengan implikasi. Commentary harus menerangkan makna bukti, bukan mengulang judul. |
| Hlm.11 | Ranking batang di kiri dan grafik indikator di kanan | Mendukung A09 dan A06. Dua exhibit perlu menjawab satu pertanyaan; keterkaitan keduanya dijelaskan dalam judul atau takeaway. |
| Hlm.18 | Dua panel tren, beberapa seri, garis ambang, sumbu kiri/kanan | Sediakan kontrak metrik, unit, periode, threshold, dan axis binding per seri. Dua panel tidak otomatis membutuhkan skala identik. |
| Hlm.9 | Heatmap dengan dua periode pembanding dan penjelasan per kelompok indikator | Mendukung visualisasi status terkait A23. Status harus punya definisi dan bukti; warna saja tidak cukup. |
| Hlm.21 dan 27 | Dua panel analitis dengan sumber, catatan definisi, dan seri yang berbeda | Footnote, satuan, normalisasi indeks, dan periode harus tetap terhubung dengan exhibit yang benar. |
| Hlm.6 dan 16 | Pembatas bagian berwarna navy dengan kesimpulan kelompok | Berguna sebagai jeda narasi. Produk tetap perlu membuat kalimat pembatas yang ringkas. |
| Hlm.3-5 dan ringkasan wilayah | Layout editorial yang padat teks | Cocok sebagai referensi mode read-ahead. Untuk presentasi langsung, pecah informasi menjadi beberapa pesan dan pindahkan detail ke catatan atau appendix. |

Pemetaan A06, A09, dan A23 merujuk keluarga pola pada hasil Phase 1B sebelumnya. Ini menambah evidence untuk keluarga tersebut, bukan menambah kuota template MVP secara otomatis.

### Pengamatan tipografi dan warna

| Elemen | Pengamatan pada PDF | Pemanfaatan saat menyusun standar produk |
|---|---|---|
| Judul | Georgia Bold; contoh hlm.8 berukuran 25 pt, hlm.9 20 pt, hlm.11 18 pt | Gunakan hierarki serif untuk judul dan sans serif untuk isi sebagai salah satu kandidat style. Ukuran final ditentukan bersama aturan kepadatan dan pengujian render. |
| Isi dan label | Keluarga Arial; commentary hlm.8 sekitar 12 pt, isi heatmap hlm.9 banyak memakai 9-10 pt | Angka ini adalah hasil observasi sumber, bukan rekomendasi default slide presentasi langsung. |
| Tata letak hlm.8 | Judul rata kiri; awal judul sekitar 4,34% dari lebar halaman; grafik mendapat porsi jauh lebih besar daripada commentary | Gunakan grid dengan area judul, exhibit, commentary, dan footer yang terdefinisi. Proporsi perlu diuji memakai konten produk sendiri. |
| Dasar dan garis grafik | Putih dan navy `#051C2C` | Pisahkan warna latar, teks, garis, dan highlight sebagai peran semantik. |
| Heatmap hlm.9 | Biru `#1F40E6`, cyan `#00A9F4`, abu-abu `#BFBFBF`, peach `#FAA082`, rose `#E5546C` | Definisikan lima tingkat status serta labelnya. Palet ini dicatat sebagai observasi, bukan penetapan palet produk. |

Warna tersebut berasal dari elemen PDF yang diperiksa, bukan hasil menebak screenshot. Tidak semua chart dalam laporan memakai kombinasi yang sama. Pengamatan satu laporan tidak mewakili seluruh aturan internal McKinsey.

## 6. Temuan QA yang berguna

| ID | Halaman | Temuan | Aturan kandidat untuk skill |
|---|---:|---|---|
| GEI-Q01 | 9 | Headline menyebut 253.000 pekerjaan baru; subjudul dan isi menyebut 353.000 untuk Januari | Tandai ketidaksesuaian angka pada headline dan evidence. Tentukan angka benar dari sumber data, bukan dari tampilan yang lebih menonjol. |
| GEI-Q02 | 8 | Penurunan 37% dan sekitar 17% memakai titik awal pembandingan berbeda | Validasi angka bersama baseline dan periodenya. Persentase berbeda tidak otomatis merupakan konflik. |
| GEI-Q03 | 11, 21 | Terdapat pemutusan skala untuk nilai ekstrem | Pemutusan skala harus eksplisit. Generator perlu menguji apakah panel terpisah atau tampilan lain lebih mudah dipahami. |
| GEI-Q04 | 18 | Dua seri pada panel kanan terikat ke sumbu berbeda | Simpan axis binding dan label setiap seri. Jangan membandingkan tinggi garis sebagai nilai absolut yang sama. |
| GEI-Q05 | 9 dan heatmap berikutnya | Status membandingkan periode berjalan dengan bulan sebelumnya dan periode sebelum COVID | Kolom perbandingan harus punya basis yang jelas; untuk kasus baru, gunakan baseline yang relevan dengan kebutuhan pengguna. |

GEI-Q01 adalah konflik internal yang terlihat pada sumber. Review ini tidak menetapkan angka ekonomi mana yang benar. GEI-Q02 sampai Q05 merupakan kasus semantik dan desain yang memerlukan aturan khusus, bukan vonis bahwa semua exhibit tersebut salah.

## 7. Korelasi dengan pembangunan skill

Hasil review ini dapat diterjemahkan menjadi tiga lapisan pada fase implementasi berikutnya:

1. **Instruksi penalaran:** pilih pesan utama, cocokkan bukti, tentukan relevansi commentary, dan pilih pola slide sesuai hubungan analitis.
2. **Spesifikasi terstruktur:** simpan `layout_id`, `headline`, `metric`, `unit`, `period`, `baseline`, `series`, `axis_binding`, `status_definition`, `insight`, dan `source` sesuai kebutuhan pola. Ini kandidat field, bukan schema final.
3. **Kode dan QA:** periksa angka serta periode, bentuk chart dan layout, lalu render untuk mengecek overflow, keterbacaan, label, serta posisi sumber.

Untuk penggunaan lintas AI, spesifikasi dan aturan layout perlu berada pada inti produk yang dapat dipanggil adapter masing-masing platform. Review PDF ini memberi bahan aturan; kompatibilitas eksekusi dan editabilitas baru dapat dibuktikan melalui pengujian implementasi.

Archetype prioritas dari tambahan ini adalah **trend + commentary**, **dua exhibit pendukung**, dan **heatmap status + penjelasan**. Kebutuhan ikon tidak menjadi alasan untuk menambah bahan pada review GEI ini. Ikon dan aset produk dibuat pada fase aset sesuai blueprint.

## 8. Dampak pada status proyek

| Area | Dampak tambahan GEI |
|---|---|
| Acuan visual modern | Bertambah satu sumber 2024 yang relevan dan telah ditinjau |
| C01 Strategy | Mendukung cara menyajikan evidence; alur keputusan strategi bukan fokus laporan ini |
| C02 Market/Competitive/Entry | Mendukung konteks ekonomi dan perbandingan wilayah; entry mode dan go/no-go masih perlu contoh yang sesuai |
| C03 Performance/Board | Memperkuat bentuk laporan berkala dan status indikator; actual-vs-budget, forecast perusahaan, owner, dan decision ask masih perlu dilengkapi |
| C04 Business Case | Tidak menambahkan kasus investasi utuh dengan cashflow dan approval |
| C05 Transformation/PMO | Tidak menambahkan status program yang menghubungkan milestone, dependency, owner, risiko, dan eskalasi |

Korpus sebelumnya berisi 29 file dengan 2.432 halaman/slide. Dengan sumber tambahan unik D030, inventaris gabungan menjadi **30 sumber dan 2.461 halaman/slide**. Angka ini adalah inventaris, bukan jumlah halaman yang seluruh isi dan datanya telah diaudit. Statistik 120 anotasi Phase 1B terdahulu tetap dilaporkan sesuai lingkup review awal; pemeriksaan GEI dicatat dalam addendum ini.

**Langkah berikutnya:** gunakan tambahan ini bersama referensi 2024-2026 yang sudah ada untuk pemilihan kandidat style, lalu lanjutkan penutupan celah alur MVP yang tercatat pada Phase 1B. Kebutuhan visual umum tidak memerlukan batch besar deck tambahan sekarang. Gate Phase 1 belum otomatis selesai karena adanya satu referensi baru.

Status sumber adalah development reference; `production_gold_approved: false`. Temuan ini menjadi bahan menyusun layout dan aset produk yang orisinal. Implementasi skill, compiler, template produk, dan pengujian lintas AI berada pada fase berikutnya dalam blueprint.
