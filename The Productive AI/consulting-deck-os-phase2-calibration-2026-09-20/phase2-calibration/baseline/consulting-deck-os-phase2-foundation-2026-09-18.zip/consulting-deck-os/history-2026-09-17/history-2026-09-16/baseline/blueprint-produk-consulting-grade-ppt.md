# Blueprint Produk Digital: Cross-AI Consulting-Grade PowerPoint System

**Status dokumen:** Blueprint produk dan rencana pembangunan end-to-end — Phase 0 completed  
**Versi:** 1.1  
**Tanggal:** 30 Agustus 2026  
**Nama kerja produk:** `Consulting Deck OS` — nama final belum ditentukan  
**Target harga:** USD 50–100 untuk lisensi individual  

---

## Daftar Isi

| Bagian | Cakupan |
| --- | --- |
| A — Definisi produk | [1. Ringkasan Eksekutif](#1-ringkasan-eksekutif) sampai [7. Bentuk Produk yang Dijual](#7-bentuk-produk-yang-dijual) |
| B — Sistem dan standard kualitas | [8. Arsitektur Sistem](#8-arsitektur-sistem) sampai [19. QA, Validation, dan Repair](#19-qa-validation-dan-repair) |
| C — Knowledge dan portabilitas | [20. Reference Corpus](#20-reference-corpus-dan-learning-system) sampai [24. User Experience](#24-user-experience) |
| D — Scope dan pembangunan | [25. Scope MVP, V1, dan V2](#25-scope-mvp-v1-dan-v2), [25A. Phase 0 Execution Record](#25a-phase-0-execution-record--product-contract-v10), sampai [27. Prioritas Backlog](#27-prioritas-backlog-implementasi-pertama) |
| E — Komersialisasi dan tata kelola | [28. Product Packaging dan Harga](#28-product-packaging-dan-harga) sampai [32. Success Metrics](#32-success-metrics) |
| F — Release dan keputusan akhir | [33. Release Gates](#33-release-gates) sampai [38. Sumber Dasar](#38-sumber-dasar-yang-sudah-menjadi-acuan) |

---

## 1. Ringkasan Eksekutif

Produk yang akan dibangun **bukan sekadar prompt, kumpulan template, atau satu Claude Skill**. Produk akhirnya adalah sebuah **sistem operasi pembuatan presentasi consulting-grade yang dapat digunakan oleh berbagai AI**.

Sistem ini menerima brief, dokumen, data, dan instruksi pengguna; menyusun argumentasi secara answer-first; membangun storyline; memilih bentuk visual yang tepat; lalu menghasilkan PowerPoint `.pptx` yang:

- memiliki logika komunikasi setara praktik konsultan top-tier;
- menggunakan action title dan alur Pyramid Principle/MECE;
- menampilkan chart, tabel, diagram, dan anotasi yang menjawab pertanyaan bisnis;
- rapi secara visual, konsisten, dan siap dipresentasikan;
- dapat diedit di PowerPoint;
- memiliki sumber dan jejak perhitungan yang jelas;
- memakai tema, layout, dan ikon orisinal;
- dapat dioperasikan melalui Claude, GPT/ChatGPT, Gemini, DeepSeek, atau AI lain melalui adapter masing-masing.

Definisi produk yang paling tepat adalah:

> **A cross-AI consulting deck operating system that transforms briefs, documents, and data into an answer-first storyline, a validated semantic deck specification, and a fully editable consulting-grade PowerPoint.**

Targetnya bukan menyalin merek, logo, font proprietary, atau template McKinsey/BCG/Bain. Targetnya adalah mencapai **functional similarity** dalam kualitas berpikir, struktur pesan, data storytelling, dan disiplin visual—dengan identitas produk yang orisinal.

---

## 2. Interpretasi Target Akhir

Screenshot dan video yang menjadi inspirasi menunjukkan hasil AI yang secara visual tampak sangat dekat dengan deck consulting. Namun thumbnail atau kemiripan sekilas bukan standar kualitas yang cukup. Produk harus dinilai melalui output aktual dan kriteria objektif.

Target akhir produk adalah:

1. Pengguna memberi brief, dokumen, atau data.
2. AI memahami keputusan yang harus didukung oleh deck.
3. AI menyusun argumen dan storyline sebelum membuat slide.
4. Sistem menghasilkan title-only storyboard untuk ditinjau.
5. Sistem mengubah storyboard menjadi spesifikasi slide terstruktur.
6. Mesin deterministic memilih layout, chart, ikon, dan anotasi.
7. Sistem membangun `.pptx` editable.
8. File dirender, diaudit, dan diperbaiki otomatis.
9. Pengguna menerima deck, sumber, dan laporan QA.

Hasil dianggap berhasil apabila deck terasa seperti hasil kerja tim strategy consulting yang matang dalam empat aspek:

| Dimensi | Arti keberhasilan |
| --- | --- |
| Problem solving | Deck menjawab keputusan bisnis, bukan hanya merangkum informasi. |
| Storyline | Judul-judul slide membentuk argumen yang runtut dan answer-first. |
| Evidence | Setiap klaim utama ditopang data atau sumber yang dapat dilacak. |
| Visual craft | Chart, layout, anotasi, hierarchy, dan spacing mempercepat pemahaman. |

Kemiripan yang dikejar adalah **kualitas fungsional**, bukan duplikasi identitas:

| Area | Sasaran |
| --- | --- |
| Logika dan struktur | Sangat dekat dengan praktik consulting top-tier |
| Disiplin visual | Sangat dekat dalam kerapian dan hierarchy |
| Chart dan anotasi | Setara dalam kejelasan analitis |
| Template/aset | Orisinal dan brand-neutral |
| Logo, merek, font proprietary | Tidak disalin |

---

## 3. Masalah yang Diselesaikan

### 3.1 Masalah pengguna

Pengguna bisnis umumnya mengalami lima hambatan:

- Tidak tahu cara mengubah data dan dokumen menjadi storyline yang kuat.
- AI biasa menghasilkan slide yang cantik tetapi generik dan tidak decision-oriented.
- Template pack memberi tampilan, tetapi tidak memberi kecerdasan memilih slide yang tepat.
- Generator AI sering menghasilkan elemen raster, layout rusak, atau file yang sulit diedit.
- Pengguna masih menghabiskan banyak waktu untuk memperbaiki alignment, label, CAGR, connector, sumber, dan konsistensi antar-slide.

### 3.2 Job to be done

> “Ketika saya memiliki brief, analisis, atau data yang harus disampaikan kepada eksekutif, bantu saya mengubahnya menjadi deck PowerPoint yang tajam, kredibel, editable, dan siap dipakai—tanpa harus menjadi mantan konsultan atau ahli desain.”

### 3.3 Kesempatan pasar

Paket template premium dapat dijual dengan harga tinggi karena menghemat waktu visual. Produk ini dapat memberi nilai lebih besar pada harga USD 50–100 dengan menggabungkan:

- consulting intelligence;
- storyline engine;
- slide and chart decision system;
- original visual assets;
- deterministic PPTX generation;
- automated QA;
- adapter lintas-AI.

Keunggulan utamanya bukan jumlah template semata, tetapi kemampuan mengotomatisasi **“final 5%”** yang biasanya masih membutuhkan perbaikan manual.

---

## 4. Positioning Produk

### 4.1 Kategori

**Cross-AI consulting presentation system**, bukan hanya:

- prompt pack;
- PowerPoint template pack;
- icon library;
- chart library;
- Claude Skill;
- AI slide generator.

Semua unsur tersebut merupakan bagian produk, tetapi bukan keseluruhan produk.

### 4.2 Positioning statement

> Untuk profesional, founder, analyst, consultant, dan corporate strategist yang perlu membuat presentasi eksekutif, Consulting Deck OS mengubah brief dan data menjadi deck PowerPoint consulting-grade yang logis, terverifikasi, visual, dan editable. Berbeda dari template pack atau generator slide generik, sistem ini menggabungkan consulting reasoning, original design system, deterministic PPTX engine, serta quality assurance lintas-slide dan lintas-model AI.

### 4.3 Janji utama

**From messy inputs to an executive-ready, editable consulting deck.**

### 4.4 Diferensiasi utama

1. **Full-deck intelligence** — memahami tujuan dan keputusan, bukan membuat slide secara terpisah.
2. **Title-only storyline validation** — cerita diuji sebelum desain dimulai.
3. **Deterministic chart annotations** — CAGR, delta, connector, bracket, scenario band, dan callout dibuat dengan aturan dan perhitungan.
4. **Cross-slide consistency** — angka, istilah, warna, periode, dan unit diperiksa di seluruh deck.
5. **Editable by design** — chart dan elemen utama tetap dapat diedit.
6. **Render–audit–repair loop** — hasil tidak berhenti pada file generation.
7. **Cross-AI portability** — knowledge core dan runtime tidak bergantung pada satu vendor AI.
8. **Original IP** — layout, tema, iconography, dan dokumentasi dibuat sendiri.

---

## 5. Pengguna Sasaran dan Use Case

### 5.1 Pengguna primer

Daftar berikut menggambarkan addressable users secara umum. Prioritas komersial yang telah dikunci terdapat pada Section 25A: independent/boutique consultants sebagai beachhead, diikuti corporate strategy/transformation dan FP&A/finance professionals.

| Segmen | Kebutuhan utama |
| --- | --- |
| Founder dan business owner | Investor, strategy, board, dan internal planning deck |
| Corporate strategy / transformation | Strategy review, operating model, roadmap, dan recommendation deck |
| Analyst dan finance | Performance review, market analysis, business case, dan scenario deck |
| Independent consultant | Client-ready deck dengan waktu produksi lebih cepat |
| Product/marketing/operations lead | Executive update, diagnosis, plan, dan performance story |
| Mahasiswa MBA/case competition | Structured problem solving dan presentation craft |

### 5.2 Use case prioritas untuk versi awal

1. Strategy recommendation deck.
2. Market, competitor, and market-entry analysis.
3. Performance review, management report, and board update.
4. Business case, financial impact, and profitability.
5. Transformation roadmap, PMO, and implementation plan.

Kelima kategori telah dikunci pada Phase 0; detail playbook dan seluruh V2 taxonomy terdapat pada Section 25A. Executive summarization from documents/data merupakan shared capability, bukan business-topic category terpisah.

### 5.3 Use case yang sebaiknya tidak menjadi prioritas MVP

- pitch deck yang sangat ilustratif atau cinematic;
- social media carousel;
- presentation dengan animasi kompleks;
- desain advertising-heavy;
- scientific poster;
- event keynote yang bergantung pada fotografi besar;
- cloning pixel-perfect dari deck milik firma tertentu.

---

## 6. Prinsip Produk

### 6.1 Problem-first

Sistem selalu memulai dari keputusan, audiens, pertanyaan utama, dan bukti—bukan dari pemilihan template.

### 6.2 Argument first, storyline second, slides last

Slide tidak boleh dibuat sebelum governing thought dan argument tree cukup jelas.

### 6.3 AI reasons; deterministic engine compiles

AI bertanggung jawab atas reasoning, synthesis, wording, dan pemilihan semantic intent. Mesin kode bertanggung jawab atas geometry, math, rendering, file integrity, dan validasi berulang.

### 6.4 Progressive disclosure

Instruksi inti tetap ringkas. Detail mengenai chart, layout, copy, ikon, sumber, dan QA dimuat dalam reference files yang dipanggil hanya saat relevan.

### 6.5 Evidence before polish

Klaim yang tidak didukung tidak boleh menjadi lebih meyakinkan hanya karena desainnya bagus.

### 6.6 Editable by default

Rasterisasi hanya digunakan untuk preview atau ilustrasi tertentu. Teks, shape, chart, tabel, dan diagram utama harus editable.

### 6.7 Original, not imitative

Produk mempelajari prinsip dan pola, bukan menyalin aset atau trade dress firma tertentu.

### 6.8 Fail visibly

Jika data tidak cukup, sumber tidak tersedia, atau layout tidak bisa diperbaiki otomatis, sistem harus memberi status yang jelas—bukan mengarang atau menyembunyikan masalah.

---

## 7. Bentuk Produk yang Dijual

Produk akhir sebaiknya berupa **hybrid skill + local runtime pack** yang memiliki lima komponen.

### 7.1 Portable Consulting Core

Kumpulan aturan vendor-neutral mengenai:

- intake dan decision contract;
- Pyramid Principle dan MECE;
- storyline construction;
- action title writing;
- slide archetype selection;
- chart selection;
- source discipline;
- deck review;
- tone dan executive writing.

### 7.2 AI Adapter Packs

Instruksi dan wrapper khusus untuk:

- Claude;
- OpenAI/ChatGPT/Codex;
- Gemini;
- DeepSeek;
- generic system-prompt/agent environment.

Adapter hanya menerjemahkan cara masing-masing platform menemukan instruksi, memanggil tool, dan mengelola file. Aturan bisnis inti tidak diduplikasi.

### 7.3 Deterministic Deck Runtime

Mesin lokal yang:

- membaca Semantic DeckSpec;
- menghitung metric dan annotation;
- menentukan geometry dari layout archetype;
- membangun chart, tabel, diagram, dan slides;
- menulis file `.pptx`;
- merender preview;
- menjalankan audit;
- memperbaiki masalah yang dapat diperbaiki otomatis.

### 7.4 Original Asset System

Berisi:

- tema dan design tokens;
- layout archetypes;
- shape primitives;
- original SVG icons;
- maps dan flags yang lisensinya jelas jika disertakan;
- diagram components;
- sample visual patterns.

### 7.5 QA and Evaluation Pack

Berisi:

- schema validators;
- numeric and source checks;
- layout linting;
- rendered-slide audit;
- benchmark prompts;
- scorecards;
- golden examples;
- regression tests.

---

## 8. Arsitektur Sistem

```mermaid
flowchart TD
    A["Brief, documents, data"] --> B["AI adapter"]
    B --> C["Consulting intelligence"]
    C --> D["StorySpec and SlideSpec"]
    D --> E["Deterministic deck runtime"]
    E --> F["Editable PPTX"]
    F --> G["Render, audit, repair"]
    G --> H["Final deck and QA report"]
    G -->|Critical issue| C
```

### 8.1 Lapisan arsitektur

| Lapisan | Tanggung jawab | Harus vendor-neutral? |
| --- | --- | --- |
| Orchestrator | Menjalankan urutan kerja dan approval | Ya |
| Consulting intelligence | Decision framing, Pyramid, MECE, storyline | Ya |
| Semantic specification | ProjectSpec, StorySpec, SlideSpec, EvidenceLedger | Ya |
| Chart engine | Pemilihan chart, calculation, annotation | Ya |
| Layout engine | Grid, density, spatial rules, collision prevention | Ya |
| Asset system | Tema, icons, maps, diagram primitives | Ya |
| PPTX compiler | Menulis PowerPoint editable | Ya |
| QA engine | Structural, numeric, visual, technical audit | Ya |
| AI adapters | Platform-specific invocation and packaging | Tidak |

### 8.2 Batas tanggung jawab AI dan kode

| Pekerjaan | AI | Kode deterministic |
| --- | ---: | ---: |
| Memahami konteks bisnis | Utama | Pendukung |
| Menyusun governing thought | Utama | Validasi aturan |
| Menulis action title | Utama | Length/style checks |
| Memilih analytical intent | Utama | Validasi compatibility |
| Menghitung CAGR/variance | Tidak | Utama |
| Menentukan koordinat elemen | Tidak | Utama |
| Mendeteksi overflow/collision | Pendukung visual review | Utama |
| Membuat file PPTX | Mengarahkan | Utama |
| Menilai apakah cerita meyakinkan | Utama | Rubric checks |
| Memastikan file dapat dibuka | Tidak | Utama |

Aturan penting: model tidak boleh diminta mengarang koordinat absolut untuk setiap elemen. Model memilih intent dan archetype; layout engine menentukan geometry.

---

## 9. Alur End-to-End dari Brief sampai PPTX

### Tahap 0 — Intake dan capability check

Sistem memeriksa:

- format input;
- ketersediaan runtime;
- ketersediaan PowerPoint template/theme;
- apakah AI environment dapat menjalankan kode;
- apakah sumber eksternal diperbolehkan;
- mode deck yang diminta.

Output: `ProjectSpec` awal dan daftar informasi yang masih kurang.

### Tahap 1 — Input normalization

Input yang didukung secara bertahap:

- plain-text brief;
- Markdown/TXT;
- DOCX/PDF;
- XLSX/CSV;
- PPTX lama;
- URL yang diizinkan pengguna;
- brand guidelines dan theme file.

Sistem mengekstrak:

- facts;
- claims;
- metrics;
- dates and periods;
- entities;
- tables;
- citations;
- user constraints.

Output: normalized content store, source registry, dan warnings.

### Tahap 2 — Evidence and claim ledger

Setiap klaim penting diberi status:

- `sourced` — didukung sumber;
- `calculated` — berasal dari perhitungan dengan lineage;
- `inferred` — interpretasi yang masuk akal tetapi harus ditandai;
- `placeholder` — memerlukan input pengguna;
- `unsupported` — tidak boleh masuk sebagai factual claim.

Output: `EvidenceLedger` dan `ClaimLedger`.

### Tahap 3 — Decision contract

Sistem merumuskan kontrak keputusan:

| Field | Pertanyaan |
| --- | --- |
| Audience | Siapa pembaca dan seberapa paham mereka? |
| Decision | Keputusan apa yang harus diambil setelah membaca deck? |
| Governing thought | Apa jawaban utama sementara? |
| Situation | Apa konteks yang disepakati? |
| Complication | Apa perubahan, masalah, atau ketegangan? |
| Key question | Pertanyaan inti apa yang harus dijawab? |
| Answer | Apa rekomendasi atau kesimpulan utama? |
| Evidence | Bukti apa yang mendukung jawaban? |
| Constraints | Waktu, panjang, kerahasiaan, brand, dan format apa? |
| Mode | Live presentation, executive pre-read, atau workshop? |

Jika decision contract belum cukup jelas, sistem meminta maksimal beberapa pertanyaan yang benar-benar material.

### Tahap 4 — Hypothesis and argument tree

Sistem menyusun:

- governing thought;
- 2–4 argument branches;
- supporting evidence;
- counterarguments;
- gaps;
- recommendation logic.

Pemeriksaan:

- apakah cabang pada level yang sama sejenis;
- apakah urutannya logis;
- apakah bersama-sama cukup menjawab pertanyaan;
- apakah tumpang tindih dapat dikurangi;
- apakah ada kesimpulan tanpa bukti.

Output: `StorySpec`.

### Tahap 5 — Title-only storyboard

Sistem membuat urutan action title tanpa mendesain slide. Judul harus dapat dibaca berurutan sebagai executive summary.

Contoh logika:

1. Market growth remains attractive, but profitability has deteriorated since 2024.
2. Margin erosion is concentrated in two high-volume customer segments.
3. Pricing leakage and service complexity explain 80% of the decline.
4. A targeted pricing and service redesign can restore 4–6 percentage points of margin.
5. A 12-month implementation roadmap can capture most value with limited customer risk.

Gate sebelum lanjut:

- story menjawab keputusan;
- tidak ada lompatan logika;
- setiap judul adalah claim, bukan topik;
- slide sequence memiliki situation → complication → resolution;
- jumlah slide sesuai batas.

Pada `Guided Mode`, pengguna menyetujui storyboard ini.

### Tahap 6 — Semantic DeckSpec

Setiap slide diubah menjadi spesifikasi semantik yang mendefinisikan apa yang harus dikomunikasikan, bukan koordinat mentah.

```yaml
schema_version: "1.0"
slide_id: S07
story_role: proof
slide_job: demonstrate_margin_concentration
action_title: "Two high-volume segments account for 80% of the margin decline"
subtitle: "Contribution to margin change, FY2024–FY2026, percentage points"
evidence_ids: [E14, E18, CALC07]
exhibit:
  analytical_intent: change_decomposition
  chart_family: waterfall
  measure: margin_percentage_points
  highlight_target: [enterprise, mid_market]
  annotations: [total_delta, contribution_share]
layout:
  archetype: chart_with_right_insight_panel
  density_mode: executive_preread
source_ids: [SRC03, SRC06]
confidence: high
```

### Tahap 7 — Visual planning

Mesin memilih:

- slide archetype;
- chart family;
- highlight color;
- annotation pattern;
- icon category;
- density rules;
- footnote/source pattern;
- fallback layout jika konten melebihi kapasitas.

### Tahap 8 — Content and data preparation

Sistem:

- memformat unit dan periode;
- menghitung CAGR, delta, mix, index, contribution, dan scenario;
- mengurutkan series;
- memilih direct labels;
- menulis insight bullets;
- menyederhanakan copy;
- mempersiapkan workbook data untuk native charts.

### Tahap 9 — PPTX compilation

Compiler:

- membuat slide 16:9;
- menerapkan theme tokens;
- menempatkan text boxes dan shapes;
- membangun native chart atau shape-based chart;
- menambahkan icons dan diagrams;
- menambahkan source notes;
- menambahkan speaker notes bila diminta;
- menanamkan metadata dan schema version.

### Tahap 10 — Render and automated audit

PPTX dirender menjadi PDF/PNG untuk audit visual. Sistem menjalankan:

- schema validation;
- file integrity check;
- text overflow detection;
- collision detection;
- safe-area check;
- font fallback check;
- number consistency;
- source completeness;
- title/body support check;
- cross-slide terminology check;
- visual hierarchy review.

### Tahap 11 — Automated repair

Perbaikan deterministic dapat meliputi:

- mengecilkan copy dengan batas yang wajar;
- memilih alternate layout;
- memindahkan label;
- memperlebar plot area;
- mengganti legend dengan direct labels;
- mengurangi tick density;
- memperbaiki source wrap;
- mengubah table menjadi appendix jika terlalu padat;
- membagi satu slide menjadi dua dengan persetujuan policy.

Repair loop dibatasi, misalnya maksimal tiga iterasi. Masalah yang tidak aman untuk diperbaiki otomatis dieskalasikan.

### Tahap 12 — Final delivery

Output minimum:

- `final-deck.pptx`;
- `deckspec.yaml` atau `.json`;
- `sources.md`;
- `qa-report.html` atau `.json`;
- `preview.pdf` opsional;
- `data-lineage.xlsx` opsional untuk deck berbasis data.

---

## 10. Operating Modes

| Mode | Karakter | Approval pengguna | Target |
| --- | --- | --- | --- |
| Fast | Lebih otomatis, pertanyaan minimum | Hanya saat blocker | Draft cepat |
| Guided | Storyboard dan beberapa keputusan visual disetujui | 2–3 checkpoints | Default premium |
| Expert | Pengguna dapat override archetype, chart, dan tokens | Sesuai kebutuhan | Konsultan/desainer berpengalaman |

### 10.1 Deck density modes

| Mode deck | Ciri | Copy dan visual |
| --- | --- | --- |
| Live presentation | Presenter menjelaskan | Sedikit teks, font besar, satu pesan dominan |
| Executive pre-read | Deck harus berdiri sendiri | Lebih padat, sumber dan anotasi lebih lengkap |
| Workshop | Memfasilitasi diskusi | Framework, prompts, options, dan working areas |

Sistem tidak boleh menerapkan aturan “minimal text” secara buta. Consulting deck dapat padat jika berfungsi sebagai pre-read.

---

## 11. Consulting-Grade Standard

### 11.1 Horizontal logic

Action titles dari awal sampai akhir harus membentuk cerita yang koheren. Pembaca yang hanya membaca judul harus memahami:

- konteks;
- masalah;
- penyebab;
- implikasi;
- rekomendasi;
- nilai yang dihasilkan;
- cara implementasi.

### 11.2 Vertical logic

Pada setiap slide:

- title menyatakan claim;
- subtitle memberi konteks, unit, periode, dan scope;
- body memberi bukti;
- annotation mengarahkan perhatian;
- takeaway/implication menjelaskan makna;
- source menunjukkan asal data.

Tidak boleh ada klaim dalam title yang tidak didukung body. Tidak boleh ada elemen body yang tidak membantu title.

### 11.3 Action title rules

Action title harus:

- berupa kalimat atau klaim, bukan label topik;
- spesifik;
- quantified bila datanya tersedia;
- menggunakan bahasa langsung;
- idealnya maksimal dua baris;
- konsisten dengan tense dan terminology deck;
- tidak melampaui kekuatan bukti;
- menyampaikan “so what”.

Contoh:

| Lemah | Consulting-grade |
| --- | --- |
| Market overview | The market will grow 8% annually, led by two underserved segments |
| Customer survey results | Reliability matters twice as much as price for enterprise buyers |
| Recommendations | Three no-regret moves can capture USD 25–30M within 12 months |

### 11.4 One slide, one governing insight

Satu slide dapat memiliki beberapa bukti, tetapi hanya satu pesan utama. Jika terdapat dua kesimpulan independen, slide harus dipecah atau salah satunya dipindahkan ke appendix.

### 11.5 MECE as an operating test

MECE bukan ritual. Gunakan untuk:

- issue tree;
- grouping recommendations;
- organizing causes;
- organizing segments;
- structuring workstreams;
- preventing double counting.

### 11.6 Mental-math minimization

Pembaca tidak boleh dipaksa menghitung sendiri jika implikasinya penting. Sistem harus menambahkan:

- delta;
- CAGR;
- share of change;
- total;
- ranking;
- variance;
- index;
- bridge;
- comparison callout.

### 11.7 Source discipline

Setiap slide berbasis fakta eksternal harus memiliki source note. Calculated values harus memiliki lineage. Jika sumber tidak dapat ditampilkan karena confidential, gunakan penanda yang disepakati seperti `Source: Client data; team analysis`—hanya bila benar.

---

## 12. Standard Anatomi Slide

Setiap content slide menggunakan lima zona konseptual:

1. **Action title** — pesan utama.
2. **Exhibit context** — subtitle, unit, periode, scope.
3. **Evidence exhibit** — chart, table, diagram, atau structured text.
4. **Interpretation layer** — annotation, callout, implication.
5. **Source and navigation** — source, footnote, page, section marker.

### 12.1 Baseline geometry

Default slide: 16:9, 13.333 × 7.5 inch.

Baseline awal yang harus diuji terhadap render:

- horizontal safe margin: 0.50–0.60 inch;
- title zone: sekitar 0.35–1.20 inch;
- body zone: sekitar 1.30–6.90 inch;
- footer zone: sekitar 7.00–7.30 inch;
- 12-column grid dengan consistent gutters;
- alignment mengikuti shared anchors, bukan penempatan bebas.

Angka tersebut adalah design tokens awal, bukan hukum tetap. QA visual menentukan penyesuaian akhir.

### 12.2 Typography baseline

Gunakan font yang aman dan berlisensi jelas. Default dapat memakai Aptos, Arial, Inter, atau Source Sans tergantung kompatibilitas.

| Element | Live | Executive pre-read |
| --- | ---: | ---: |
| Action title | 24–30 pt | 20–24 pt |
| Subtitle | 12–16 pt | 10–13 pt |
| Body | 16–22 pt | 10–14 pt |
| Chart label | 12–16 pt | 9–12 pt |
| Source/footer | 8–10 pt | 7–9 pt |

Ukuran final mengikuti content budget, tetapi tidak boleh mengorbankan keterbacaan untuk mempertahankan layout yang salah.

---

## 13. Slide Archetype Library

MVP sebaiknya tidak mengejar ratusan template. Mulailah dengan archetype yang kuat, parametrik, dan dapat dikombinasikan.

### 13.1 Archetype inti

| Kelompok | Archetype |
| --- | --- |
| Navigation | Cover, agenda, section divider, closing |
| Synthesis | Executive summary, recommendation summary, key takeaways |
| Quantitative | Big number, trend, comparison, composition, waterfall/bridge, scenario |
| Diagnostic | Driver tree, issue tree, root-cause view, heatmap |
| Strategic | 2×2 matrix, market map, portfolio, option assessment |
| Operating model | Capability model, process, organization/governance, role split |
| Implementation | Roadmap, workplan, milestones, initiative cards, impact/effort |
| Evidence | Table, benchmark, customer quote, case example |
| Appendix | Detailed table, methodology, definitions, source register |

### 13.2 Target MVP

Target awal yang realistis:

- 15–20 archetypes;
- masing-masing memiliki 2–4 layout variants;
- setiap variant diuji pada short, medium, dan high-density content;
- fallback behavior didefinisikan;
- seluruh archetype memakai design tokens yang sama.

Dengan 20 archetypes × rata-rata 3 variants, produk sudah memiliki sekitar 60 pola yang lebih berguna daripada ratusan slide statis tanpa decision logic.

---

## 14. Chart Decision Engine

Chart dipilih berdasarkan pertanyaan analitis, bukan berdasarkan estetika.

| Analytical intent | Visual utama | Contoh pertanyaan |
| --- | --- | --- |
| Comparison | Horizontal bar / dot plot | Segmen mana paling besar? |
| Trend | Line / column | Bagaimana perubahan dari waktu ke waktu? |
| Composition | Stacked bar / 100% stacked | Apa komposisi total? |
| Change decomposition | Waterfall / bridge | Apa pendorong perubahan? |
| Relationship | Scatter / bubble | Apakah dua variabel berkorelasi? |
| Distribution | Histogram / box plot | Bagaimana sebaran nilai? |
| Positioning | 2×2 / bubble matrix | Opsi mana paling menarik? |
| Flow/process | Process / Sankey-like diagram | Bagaimana alur bekerja? |
| Cause-effect | Driver tree / fishbone-like structure | Apa penyebab hasil? |
| Precise lookup | Table / heatmap | Berapa nilai exact per item? |

### 14.1 Chart rules

- Urutkan kategori ketika urutan nominal tidak penting.
- Gunakan horizontal bar untuk label kategori panjang.
- Hindari pie chart jika perbandingan kecil atau kategori banyak.
- Gunakan direct labels jika legend menambah beban kognitif.
- Highlight hanya data yang mendukung pesan utama.
- Gunakan grey untuk context dan satu warna accent untuk insight.
- Zero baseline wajib untuk bar chart kecuali ada alasan eksplisit.
- Sumbu, units, periods, dan basis harus jelas.
- Hindari 3D charts dan dekorasi yang tidak membawa informasi.

### 14.2 Annotation engine

Annotation yang harus didukung secara deterministic:

- CAGR arrow;
- absolute and percentage delta;
- subtotal/total labels;
- aggregation bracket;
- contribution share;
- target/reference line;
- scenario band;
- peak/trough marker;
- category highlight;
- stacked connector;
- variance callout;
- forecast boundary;
- event marker;
- source footnote.

### 14.3 Native versus shape-based charts

| Metode | Gunakan ketika | Trade-off |
| --- | --- | --- |
| Native PowerPoint chart | Chart standar dan data perlu diedit | Lebih editable, styling kadang terbatas |
| Shape-based chart | Visual khusus/annotated dan data relatif sederhana | Sangat terkontrol, editing data tidak sepraktis native chart |
| SVG/raster | Ilustrasi kompleks yang tidak perlu data edit | Jangan dipakai untuk chart utama jika editability dijanjikan |

---

## 15. Original Visual Design System

### 15.1 Brand-neutral design profiles

Hindari profil bernama `McKinsey`, `BCG`, atau `Bain`. Buat profil orisinal, misalnya:

- `Executive Blue` — analytical, neutral, precise;
- `Strategy Green` — visual, framework-oriented;
- `Transformation Red` — action and implementation-oriented;
- `Monochrome Board` — minimal, board-ready;
- `Client Brand` — berdasarkan token milik pengguna.

### 15.2 Design tokens

Setiap profile memiliki:

- font families dan fallback;
- title/body/footer sizes;
- neutral palette;
- semantic accent colors;
- status colors;
- line weights;
- corner radius;
- spacing scale;
- grid and margins;
- chart defaults;
- table defaults;
- icon style;
- source/footer style.

### 15.3 Semantic color roles

Warna tidak dipilih per slide secara acak. Gunakan role:

- `ink_primary`;
- `ink_secondary`;
- `context_neutral`;
- `accent_primary`;
- `accent_secondary`;
- `positive`;
- `negative`;
- `warning`;
- `forecast`;
- `background`;
- `divider`.

Satu meaning harus mempertahankan warna yang sama di seluruh deck.

### 15.4 Visual restraint

Consulting-grade bukan berarti setiap slide harus penuh warna atau dekorasi. Prinsipnya:

- hierarchy lebih penting daripada ornament;
- whitespace dipakai untuk grouping;
- alignment lebih penting daripada banyak shapes;
- highlight digunakan secara ekonomis;
- konsistensi lebih penting daripada novelty per slide.

---

## 16. Custom Icon System

### 16.1 Spesifikasi teknis

Semua ikon harus:

- orisinal atau memiliki lisensi redistribusi yang jelas;
- memakai canonical SVG;
- memiliki viewBox yang konsisten;
- memakai grid, stroke width, caps, joins, dan optical padding yang konsisten;
- tersedia dalam outline dan/atau filled style yang didefinisikan;
- recolorable melalui theme tokens;
- memiliki semantic tags;
- diuji pada ukuran kecil di PowerPoint;
- tidak bergantung pada font icon yang mudah hilang.

### 16.2 Taxonomy awal

- strategy;
- finance;
- customer;
- marketing and sales;
- operations;
- supply chain;
- digital and AI;
- people and organization;
- risk and compliance;
- sustainability;
- governance;
- transformation;
- project management;
- common industries.

### 16.3 Strategi jumlah ikon

Jangan mengejar 1.500 ikon pada MVP. Rekomendasi:

- 250–400 original core icons;
- 30–50 diagram primitives;
- parametric icon composition;
- search melalui tags dan synonyms;
- penambahan library berdasarkan use-case aktual beta users.

Nilai produk datang dari pemilihan ikon yang tepat dan konsistensinya, bukan jumlah mentah.

---

## 17. Semantic Data Model

### 17.1 ProjectSpec

Menyimpan konteks proyek:

```yaml
schema_version: "1.0"
project_id: client_strategy_001
language: en
audience: executive_committee
decision: approve_pricing_transformation
deck_mode: executive_preread
target_slide_count: 15
aspect_ratio: "16:9"
design_profile: executive_blue
source_policy: strict
editability: full
confidentiality: confidential
```

### 17.2 StorySpec

Menyimpan:

- situation;
- complication;
- key question;
- governing thought;
- argument branches;
- evidence mappings;
- recommended sequence;
- counterarguments;
- appendix routing.

### 17.3 SlideSpec

Field minimum:

- `slide_id`;
- `story_role`;
- `slide_job`;
- `action_title`;
- `subtitle`;
- `evidence_ids`;
- `exhibit_intent`;
- `chart_family` atau `diagram_family`;
- `layout_archetype`;
- `highlight_target`;
- `annotations`;
- `insight_text`;
- `source_ids`;
- `density_mode`;
- `speaker_notes`;
- `confidence`;
- `review_status`.

### 17.4 EvidenceLedger

Setiap evidence record menyimpan:

- source ID;
- file/URL reference;
- page, sheet, range, atau table locator;
- extraction timestamp;
- raw value;
- normalized value;
- unit;
- time period;
- transformation/calculation;
- confidence;
- permitted usage.

### 17.5 ClaimLedger

Menghubungkan setiap claim dengan:

- supporting evidence;
- calculation IDs;
- caveats;
- strength of claim;
- slides where used.

Data model ini menjadi tulang punggung audit, konsistensi, dan portabilitas lintas-AI.

---

## 18. PPTX Generation Engine

### 18.1 Rekomendasi arsitektur teknis

Gunakan toolchain hybrid:

- **Python 3.11+** untuk ingestion, data transformation, calculations, schema validation, OOXML inspection, dan QA;
- **TypeScript/Node + PptxGenJS** sebagai kandidat compiler utama untuk slide primitives dan chart generation;
- **OOXML patch layer** untuk fitur PowerPoint yang tidak tersedia melalui high-level library;
- **LibreOffice headless** untuk render/check dalam development dan CI;
- **Poppler** untuk mengubah PDF preview menjadi images;
- **JSON Schema atau Pydantic** untuk ProjectSpec/StorySpec/SlideSpec validation.

Sebelum dikunci, lakukan technical spike yang membandingkan PptxGenJS dan `python-pptx` pada:

- native editable charts;
- embedded workbook;
- text measurement;
- SVG handling;
- notes;
- theme/master behavior;
- OOXML stability;
- render fidelity di PowerPoint Windows, Mac, dan LibreOffice.

### 18.2 Compiler pipeline

1. Validate DeckSpec.
2. Resolve design profile.
3. Resolve slide archetype.
4. Calculate content budget.
5. Prepare chart data and annotations.
6. Place elements from shared anchors.
7. Add sources and metadata.
8. Save PPTX.
9. Open/parse generated OOXML.
10. Render and audit.

### 18.3 Editability contract

Produk harus mendefinisikan level editability:

| Level | Definisi |
| --- | --- |
| Full | Text, shapes, charts, tables, and diagrams editable |
| Practical | Semua konten bisnis editable; decorative artwork dapat berupa SVG |
| Visual-only | Rasterized output; tidak sesuai janji utama produk |

Default produk adalah `Practical`, dengan `Full` untuk archetype yang mendukungnya.

### 18.4 File compatibility

Test matrix minimum:

- PowerPoint desktop Windows;
- PowerPoint desktop macOS;
- PowerPoint web;
- Google Slides import sebagai best-effort;
- LibreOffice sebagai diagnostic renderer, bukan sumber kebenaran tunggal.

---

## 19. QA, Validation, dan Repair

### 19.1 Quality score

| Dimensi | Bobot |
| --- | ---: |
| Strategic reasoning and storyline | 25 |
| Evidence and numeric integrity | 20 |
| Slide message and copy | 15 |
| Chart selection and annotation | 15 |
| Visual craft and consistency | 15 |
| Technical PPTX integrity | 10 |
| **Total** | **100** |

Target pass awal: **≥85/100 dan tidak memiliki critical failure**.

### 19.2 Hard-fail conditions

Deck gagal otomatis jika terdapat:

- hallucinated data;
- unsupported action title;
- angka yang tidak konsisten;
- calculation error;
- chart yang menyesatkan;
- missing source untuk factual external claim;
- file tidak dapat dibuka atau meminta repair;
- clipping atau overlap material;
- elemen di luar slide;
- copied protected asset;
- confidential content bocor ke source atau output yang tidak diizinkan.

### 19.3 Structural checks

- Semua slide memiliki ID dan story role.
- Content slide memiliki action title.
- SlideSpec valid terhadap schema.
- Source IDs dapat di-resolve.
- Appendix references valid.
- Page number dan section markers konsisten.

### 19.4 Narrative checks

- Judul-judul membentuk cerita yang runtut.
- Tidak ada slide topik tanpa point of view.
- Recommendation mengikuti diagnosis.
- Quantified impact tidak muncul sebelum basisnya tersedia atau dijelaskan.
- Executive summary cocok dengan isi deck.

### 19.5 Numeric checks

- Totals reconcile.
- Percentages memiliki denominator yang jelas.
- CAGR memakai periode yang benar.
- Currency, scale, dan unit konsisten.
- Rounding tidak mengubah kesimpulan.
- Angka yang sama tidak berbeda antar-slide tanpa alasan.

### 19.6 Layout checks

- Text overflow;
- overlapping bounding boxes;
- label collision;
- minimum font size;
- safe margins;
- alignment deviation;
- inconsistent gutters;
- legend/plot conflict;
- source wrapping;
- orphaned words;
- excessive density.

### 19.7 Visual AI review

Rendered slide dapat ditinjau model vision untuk menilai:

- hierarchy;
- balance;
- emphasis;
- scan path;
- apparent clutter;
- apakah visual benar-benar mendukung title.

Vision review tidak menggantikan geometry checks. Keduanya saling melengkapi.

### 19.8 Repair policy

| Severity | Tindakan |
| --- | --- |
| Cosmetic | Perbaiki otomatis tanpa interupsi |
| Material but safe | Perbaiki otomatis dan catat pada QA report |
| Semantic | Kembali ke SlideSpec atau minta review AI |
| Evidence/decision critical | Hentikan dan minta input pengguna |

---

## 20. Reference Corpus dan Learning System

Reference deck dari McKinsey, BCG, Bain, dan firma lain tidak secara otomatis “melatih” skill. Agar berguna, corpus harus diubah menjadi knowledge artifacts dan benchmark.

### 20.1 Metadata setiap deck

- firm/source;
- year;
- client deck versus public research;
- industry;
- business objective;
- live/pre-read/workshop mode;
- aspect ratio;
- visual era;
- slide count;
- source and license status;
- permitted internal use.

### 20.2 Metadata setiap slide

- storyline role;
- action title quality;
- slide archetype;
- analytical intent;
- chart/diagram family;
- layout pattern;
- density;
- annotation types;
- source treatment;
- strengths;
- weaknesses;
- reusable principle;
- prohibited-to-copy assets.

### 20.3 Memisahkan logic dan style

Deck publik tahun 2010–2012 dapat memberi pelajaran kuat mengenai logic, tetapi style-nya mungkin 4:3 dan terlihat lama. Corpus harus memisahkan:

- **consulting logic** — relatif tahan lama;
- **visual style** — harus mengikuti standar modern;
- **brand-specific artifact** — tidak boleh disalin.

### 20.4 Hasil distilasi corpus

Corpus tidak dibundel mentah ke produk kecuali lisensinya memungkinkan. Yang masuk ke produk adalah:

- rules;
- archetype definitions;
- anonymized patterns;
- original examples;
- scoring rubric;
- benchmark cases;
- failure examples;
- derived decision logic.

### 20.5 Benchmark suite

Siapkan minimal:

- 20 single-slide tasks;
- 10 mini-deck tasks, 5–7 slides;
- 5 full-deck tasks, 12–20 slides;
- data-cleaning cases;
- inconsistent-source cases;
- sparse-input cases;
- high-density pre-read cases;
- multilingual cases;
- brand customization cases.

Setiap perubahan skill, runtime, atau model adapter dijalankan terhadap benchmark yang sama.

---

## 21. Cross-AI Architecture

### 21.1 Prinsip portabilitas

Tidak ada satu format skill universal untuk seluruh AI. Karena itu produk harus menggunakan **portable core + thin adapters**.

```mermaid
flowchart TD
    A["Portable consulting core"] --> B["Claude adapter"]
    A --> C["OpenAI adapter"]
    A --> D["Gemini adapter"]
    A --> E["DeepSeek or generic adapter"]
    B --> F["Shared DeckSpec and runtime"]
    C --> F
    D --> F
    E --> F
```

### 21.2 Portable core

Portable core berisi Markdown, JSON/YAML schema, assets, dan CLI yang tidak bergantung pada provider.

### 21.3 Adapter contract

Setiap adapter harus mendefinisikan:

- trigger/description;
- cara membaca reference files;
- tool invocation;
- file input/output;
- context budget strategy;
- approval behavior;
- error handling;
- model limitations;
- installation steps;
- smoke tests.

### 21.4 Compatibility levels

| Level | Kemampuan |
| --- | --- |
| A — Full runtime | AI dapat membaca file, menjalankan code, render, dan mengembalikan PPTX |
| B — Assisted runtime | AI menghasilkan DeckSpec; local CLI membangun dan mengaudit PPTX |
| C — Prompt-only | AI menghasilkan storyline/spec; pengguna menjalankan langkah lain secara manual |

Marketing harus menyatakan compatibility level per platform secara jujur. “Works with all AI” tidak boleh berarti fitur penuh identik di semua platform jika runtime mereka berbeda.

### 21.5 Claude adapter

Claude package mengikuti prinsip skill:

- `SKILL.md` ringkas dan berorientasi workflow;
- references dimuat sesuai kebutuhan;
- scripts menangani pekerjaan deterministic;
- assets dipisahkan;
- examples dan evals tersedia;
- kemampuan Claude.ai, API, dan Claude Code didokumentasikan terpisah jika berbeda.

---

## 22. Struktur Paket Produk

```text
consulting-deck-os/
├── README.md
├── LICENSE.md
├── CHANGELOG.md
├── core/
│   ├── schemas/
│   │   ├── project-spec.schema.json
│   │   ├── story-spec.schema.json
│   │   ├── slide-spec.schema.json
│   │   └── evidence-ledger.schema.json
│   ├── references/
│   │   ├── consulting-grade-standard.md
│   │   ├── decision-contract.md
│   │   ├── pyramid-and-mece.md
│   │   ├── storyline-engine.md
│   │   ├── action-titles.md
│   │   ├── slide-archetypes.md
│   │   ├── chart-decision-rules.md
│   │   ├── annotation-rules.md
│   │   ├── source-discipline.md
│   │   └── qa-rubric.md
│   └── examples/
├── adapters/
│   ├── claude/
│   ├── openai/
│   ├── gemini/
│   ├── deepseek/
│   └── generic/
├── runtime/
│   ├── python/
│   ├── typescript/
│   ├── ooxml/
│   └── cli/
├── design-system/
│   ├── themes/
│   ├── layouts/
│   ├── icons/
│   ├── diagrams/
│   └── maps/
├── templates/
├── evals/
│   ├── cases/
│   ├── fixtures/
│   ├── expected/
│   └── scorecards/
├── docs/
│   ├── installation/
│   ├── quickstart/
│   ├── user-guide/
│   ├── troubleshooting/
│   └── platform-compatibility/
└── samples/
    ├── briefs/
    ├── data/
    ├── deckspecs/
    └── outputs/
```

---

## 23. Struktur Claude Skill

### 23.1 Peran `SKILL.md`

`SKILL.md` bukan tempat menaruh seluruh pengetahuan. Isinya harus cukup ringkas untuk:

- menjelaskan kapan skill digunakan;
- menetapkan urutan workflow;
- menunjukkan file referensi yang harus dibaca pada tiap tahap;
- menentukan kapan menjalankan scripts;
- menentukan checkpoints;
- menentukan hard stops;
- mendefinisikan output contract.

### 23.2 Outline `SKILL.md`

```markdown
---
name: consulting-deck-builder
description: Build or improve editable, evidence-backed consulting-grade PowerPoint decks from briefs, documents, and data.
---

# Consulting Deck Builder

## When to use
## Inputs and prerequisites
## Operating modes
## Required workflow
## Decision contract
## Storyboard approval
## DeckSpec generation
## Runtime invocation
## Render and QA
## Repair and escalation
## Deliverables
## References routing
```

### 23.3 Progressive disclosure map

| Tahap | Reference yang dimuat |
| --- | --- |
| Intake | decision-contract.md, source-discipline.md |
| Storyline | pyramid-and-mece.md, storyline-engine.md, action-titles.md |
| Slide planning | slide-archetypes.md, chart-decision-rules.md |
| Visual build | annotation-rules.md, design profile, icon taxonomy |
| QA | qa-rubric.md, repair-policy.md |

Long reference files harus memiliki table of contents dan tidak membuat rantai referensi terlalu dalam.

### 23.4 Scripts yang direncanakan

- `normalize_inputs.py`;
- `extract_sources.py`;
- `build_evidence_ledger.py`;
- `validate_deckspec.py`;
- `calculate_metrics.py`;
- `build_deck.ts`;
- `audit_pptx.py`;
- `render_deck.py`;
- `detect_collisions.py`;
- `repair_layout.py`;
- `package_delivery.py`.

Nama final mengikuti implementasi. Script kritikal harus memiliki deterministic tests.

---

## 24. User Experience

### 24.1 Quick-start flow

Pengguna memasang adapter dan runtime, kemudian memberi instruksi seperti:

> Create a 12-slide executive pre-read for the leadership team. The decision is whether to enter Market X in 2027. Use the attached market report and financial model. Keep all factual claims sourced, use the Executive Blue profile, and generate an editable PowerPoint.

Sistem merespons dengan:

1. decision contract ringkas;
2. material gaps/questions;
3. title-only storyboard;
4. build status;
5. final deliverables dan QA summary.

### 24.2 Default checkpoints

Guided Mode memiliki tiga checkpoints:

1. **Decision contract approval** — memastikan deck menjawab masalah yang benar.
2. **Storyboard approval** — memastikan cerita benar sebelum layout.
3. **Final review** — memilih apakah menerima, merevisi slide tertentu, atau mengubah profile.

### 24.3 Revision commands

Produk harus mendukung revisi semantik, misalnya:

- “Make the recommendation more assertive without overstating the evidence.”
- “Move detailed methodology to appendix.”
- “Use a waterfall to show the source of margin decline.”
- “Keep the story but restyle using our brand tokens.”
- “Rebuild slides 6–8 for a live presentation.”
- “Audit this existing deck without rewriting it.”

### 24.4 Existing deck modes

Setelah MVP, dukung:

- audit-only;
- storyline rewrite;
- restyle-to-system;
- data refresh;
- selected-slide rebuild;
- full-deck rebuild.

---

## 25. Scope MVP, V1, dan V2

### 25.1 MVP

MVP membuktikan bahwa sistem dapat menghasilkan deck yang logis, editable, dan rapi.

Target MVP:

- 5 validated business playbooks defined in Section 25A;
- input text, PDF, DOCX, XLSX, dan CSV;
- output PPTX 16:9;
- English dan Bahasa Indonesia;
- 15–20 slide archetypes;
- 8–10 chart families;
- 2 original design profiles;
- 250–400 icons;
- title-only storyboard workflow;
- strict source policy;
- basic render/audit/repair;
- Claude adapter;
- generic adapter/CLI;
- 20 benchmark cases;
- 3 complete sample decks.

### 25.2 Version 1.0

- OpenAI, Gemini, dan DeepSeek adapters;
- expanded annotation engine;
- advanced table and roadmap system;
- user brand tokens;
- existing deck audit;
- 30+ archetypes;
- cross-slide number and terminology checks;
- 50+ benchmark cases;
- installer dan guided diagnostics;
- comprehensive user documentation.

### 25.3 Version 2.0

- semi-automatic ingestion of brand guidelines;
- data refresh from spreadsheets;
- team review workflow;
- reusable corporate libraries;
- industry packs;
- localization packs;
- optional cloud runtime;
- telemetry yang opt-in dan privacy-safe;
- marketplace/community extensions.

---

## 25A. Phase 0 Execution Record — Product Contract v1.0

**Status:** COMPLETED  
**Decision date:** 30 Agustus 2026  
**Decision owner:** Productive AI  
**Purpose:** Mengunci beachhead market, persona pembeli, kategori bisnis, lima MVP playbooks, product promise, output contract, compatibility, distribution, pricing, dan license sebelum corpus work dan implementation dimulai.

### 25A.1 Executive decision

Produk akan diluncurkan sebagai **direct-to-professional, cross-AI consulting deck system** dengan beachhead market berupa independent/boutique consultants yang secara rutin membuat deck untuk klien. Corporate strategy/transformation analysts dan FP&A/finance professionals menjadi adjacent primary segments karena memiliki kebutuhan berulang, high-stakes audience, dan kebutuhan data storytelling yang sangat dekat.

Lima kategori yang dibangun dan diuji terlebih dahulu adalah:

1. **Strategy & Strategic Recommendation** — MVP.
2. **Market, Competitive & Market Entry Analysis** — MVP.
3. **Performance Review, Management Report & Board Update** — MVP.
4. **Business Case, Financial Impact & Profitability** — MVP.
5. **Transformation Roadmap, PMO & Implementation Plan** — MVP.

Kategori lain masuk **V2 — On-Progress Roadmap**. Artinya kategori telah ditetapkan dalam product taxonomy dan akan dikembangkan setelah kelima MVP melewati quality gate; bukan berarti seluruh kategorinya sedang dikodekan pada saat Phase 0 selesai.

Produk dijual sebagai hybrid bundle:

- portable consulting core;
- platform adapters;
- local deterministic runtime/CLI;
- original themes, layouts, and icons;
- benchmark and QA pack;
- documentation and sample projects.

Harga dikunci untuk validasi pasar:

- private/beta access: **USD 59**;
- public launch price: **USD 79**;
- standard list price setelah product maturity: **USD 99**.

### 25A.2 Basis riset dan demand signals

Phase 0 tidak menggunakan satu angka market-size yang spekulatif. Keputusan dibuat melalui triangulasi lima jenis sinyal: adoption, workplace pain, willingness to pay, creator attention, dan technical quality gap.

| Signal | Temuan | Implikasi produk |
| --- | --- | --- |
| AI presentation adoption | Gamma melaporkan 70 juta pengguna telah membuat lebih dari 400 juta presentation/document/site dan lebih dari satu juta artefak dibuat per hari pada 2025. | Text-to-presentation sudah menjadi kategori besar, bukan use case eksperimental. |
| Visual communication requirement | Canva melaporkan 92% business leaders mengharapkan pekerja non-design memiliki design skills; laporan 2025 menyatakan 89% melihat visual fluency sebagai kemampuan penting. | Buyer membutuhkan kualitas visual, tetapi mayoritas bukan presentation designer. |
| Last-minute deck pain | Microsoft Work Trend Index menemukan aktivitas edit PowerPoint melonjak 122% dalam 10 menit terakhir sebelum meeting. | Urgency dan deadline pressure adalah buying trigger yang nyata. |
| Productivity value | Studi yang dilaporkan Beautiful.ai menyebut rata-rata 5,6 jam per minggu dihemat oleh paid users; angka ini diperlakukan sebagai vendor-reported directional evidence. | Value proposition sebaiknya dijual sebagai time-to-decision dan cleanup reduction. |
| Willingness to pay | Slideworks menjual topic-specific consulting playbooks sekitar USD 129–179 dan menyebut 4.500+ customers. | Harga USD 79–99 layak untuk bundle yang memberi intelligence, assets, dan automation. |
| Creator attention | Video “Ex-McKinsey Consultant tests Claude for PowerPoint” memperoleh sekitar 51 ribu views dalam lima bulan; banyak konten serupa muncul di consulting, finance, dan AI-productivity channels. | YouTube adalah acquisition channel yang cocok untuk demonstrasi before/after. |
| Quality gap | PPT-Eval 2026 melaporkan frontier agents masih kesulitan pada PowerPoint tasks; hasil yang disebut untuk salah satu strong agent tetap jauh dari reliable completion. | Moat harus berada pada deterministic compiler, QA, dan repair—not prompt alone. |

Interpretasi:

- Demand untuk AI presentation telah tervalidasi secara kategori.
- Demand untuk **consulting-grade editable PowerPoint** merupakan subsegment yang lebih sempit, tetapi memiliki willingness to pay dan pain yang lebih tinggi.
- Produk tidak perlu mengalahkan Gamma/Canva sebagai general presentation maker.
- Produk harus memenangkan use case high-stakes business decks yang membutuhkan reasoning, evidence, PowerPoint editability, dan quality control.

Catatan: vendor metrics digunakan sebagai directional evidence, bukan audited market share atau proyeksi revenue.

### 25A.3 Behavioral buyer persona

#### Primary behavioral persona: The Executive Deck Owner

`Executive Deck Owner` adalah profesional yang secara pribadi bertanggung jawab mengubah analisis menjadi deck untuk pengambil keputusan. Ia dinilai dari kejelasan cerita, ketepatan angka, dan kualitas final slide—not merely from completing a presentation.

Karakter utama:

- membuat deck untuk client, C-suite, steering committee, atau board;
- memulai dari Excel, PDF, Word, research notes, dan existing slides;
- memerlukan editable PowerPoint karena review selalu berubah;
- memiliki deadline pendek dan high revision load;
- mampu menggunakan AI tetapi tidak mempercayai output generik tanpa audit;
- bersedia membayar jika produk mengurangi restructuring, formatting, dan cleanup;
- membutuhkan confidentiality dan local-file control;
- ingin hasil yang terlihat professional tanpa menjadi presentation designer.

#### Beachhead buyer: Independent/Boutique Consultant

**Status:** PRIMARY BEACHHEAD

Mengapa dipilih:

- consulting-grade fit paling tinggi;
- membuat external/client-facing decks;
- dapat membeli tanpa procurement enterprise yang panjang;
- value dari satu client deck dapat melampaui harga produk;
- aktif mencari skill, template, AI workflow, dan PowerPoint tutorials;
- mudah dijangkau melalui YouTube, LinkedIn, consulting communities, dan creator partnerships;
- berpotensi menjadi advocate karena output mereka terlihat oleh klien dan peers.

Jobs to be done:

- membuat diagnosis dan recommendation deck;
- mengubah research menjadi market/strategy deck;
- membuat business case dan implementation plan;
- memperbaiki deck junior analyst;
- mempercepat proposal dan client update;
- menyesuaikan story ke live meeting atau pre-read.

Buying triggers:

- project/client baru;
- deck review yang berulang;
- template perusahaan tidak cukup memberi storyline;
- deliverable harus selesai dalam satu atau dua hari;
- pengguna mencoba AI slide generator tetapi hasilnya terlalu generik;
- kebutuhan meningkatkan perceived professionalism tanpa menambah headcount.

Primary objections:

- “Apakah hasilnya benar-benar editable?”
- “Apakah datanya aman?”
- “Apakah hasilnya masih membutuhkan banyak perbaikan?”
- “Apakah ini hanya template/prompt pack?”
- “Apakah bisa mengikuti brand client?”
- “Apakah berjalan pada AI yang saya gunakan?”

Product response:

- practical editability contract;
- local deterministic runtime;
- QA score and hard-fail report;
- portable core and compatibility matrix;
- source lineage;
- original client-brandable design profiles.

#### Adjacent primary segment A: Corporate Strategy, Transformation, and Business Analysts

**Status:** PRIMARY ADJACENT

Use cases:

- strategic plan;
- market entry;
- growth initiatives;
- executive/board update;
- transformation portfolio;
- competitor and industry analysis;
- steering committee materials.

Advantages:

- high frequency;
- strong consulting-style fit;
- recurring internal decision cycles;
- potential team-license expansion.

Constraint:

- company procurement, data governance, and brand requirements may slow conversion; individual license remains entry point.

#### Adjacent primary segment B: FP&A, Finance Managers, and CFO Office Analysts

**Status:** PRIMARY ADJACENT

Use cases:

- monthly/quarterly performance review;
- management and board packs;
- budget versus actual;
- variance and driver analysis;
- business case;
- forecast and scenario;
- profitability and pricing.

Advantages:

- recurring monthly/quarterly workflow;
- strong need for Excel-to-story conversion;
- high cost of number inconsistency;
- strong fit for deterministic calculation and validation.

Constraint:

- finance outputs require stricter lineage, reconciliation, and human approval than generic presentations.

#### Secondary personas

| Persona | Status | Rationale |
| --- | --- | --- |
| Product, PMO, and Operations Managers | V2 — ON-PROGRESS ROADMAP | Strong roadmap/status demand, but topic packs need domain-specific patterns. |
| Founders and Startup Teams | V2 — ON-PROGRESS ROADMAP | Large visible demand and direct buying, but pitch decks are crowded and less recurring. |
| Sales, Marketing, and Agency Teams | V2 — ON-PROGRESS ROADMAP | High presentation frequency, but visual grammar differs from analytical consulting decks. |
| Investment Banking, PE, and M&A Professionals | V2 — ON-PROGRESS ROADMAP | High willingness to pay, but finance/legal precision and confidentiality raise complexity. |
| Researchers and Thought-Leaders | V2 — ON-PROGRESS ROADMAP | Good document-to-deck fit, but citation and long-form synthesis need specialized QA. |
| Students and Educators | V2 — ON-PROGRESS ROADMAP | High volume but lower willingness to pay and lower need for enterprise-grade editability. |

### 25A.4 Persona opportunity scoring

This is an internal Phase-0 prioritization score, not a market-share statistic. Score uses demand 25%, recurrence 20%, willingness to pay 20%, consulting-grade fit 20%, and direct acquisition accessibility 15%.

| Persona cluster | Demand | Recurrence | WTP | Consulting fit | Acquisition | Score / 5 | Decision |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Independent/boutique consultants | 5 | 5 | 5 | 5 | 5 | **5.00** | Beachhead |
| Corporate strategy/transformation analysts | 5 | 5 | 4 | 5 | 4 | **4.65** | Primary adjacent |
| FP&A/finance/CFO office | 5 | 5 | 4 | 4 | 4 | **4.45** | Primary adjacent |
| Sales/marketing/agency | 5 | 5 | 4 | 2 | 4 | **4.05** | V2 |
| Product/PMO/operations | 4 | 4 | 4 | 4 | 3 | **3.85** | V2 |
| Founders/startups | 5 | 2 | 4 | 3 | 4 | **3.65** | V2 |
| Investment/M&A professionals | 3 | 3 | 5 | 5 | 2 | **3.65** | V2 specialist pack |
| Students/educators | 5 | 2 | 1 | 2 | 5 | **3.00** | V2/lite offer only |

### 25A.5 Use-case prioritization method

Business topics were scored using:

- market demand: 25%;
- recurrence: 20%;
- consulting-grade fit: 20%;
- willingness to pay: 15%;
- cross-industry applicability: 10%;
- MVP feasibility: 10%.

The score is a strategic selection tool. It does not claim measured global market share.

| Use-case family | Weighted score / 5 | Decision |
| --- | ---: | --- |
| Strategy & strategic recommendation | **4.70** | MVP |
| Performance/management/board reporting | **4.70** | MVP |
| Business case/financial impact/profitability | **4.70** | MVP |
| Transformation roadmap/PMO/implementation | **4.65** | MVP |
| Market/competitive/market-entry analysis | **4.55** | MVP |
| Go-to-market/commercial strategy | 4.35 | V2 — on-progress roadmap |
| Consulting/service proposal | 4.35 | V2 — on-progress roadmap |
| Operations/process excellence | 4.10 | V2 — on-progress roadmap |
| Product strategy/portfolio | 4.00 | V2 — on-progress roadmap |
| Investor pitch/fundraising | 3.85 | V2 — on-progress roadmap |
| M&A/due diligence | 3.60 | V2 specialist pack |

### 25A.6 Five MVP playbooks

#### MVP-01 — Strategy & Strategic Recommendation

**Primary users:** consultants, corporate strategy, business analysts.  
**Decision supported:** What should the organization do and why?  
**Typical inputs:** management brief, research, interview notes, financials, prior strategy documents.  
**Default mode:** executive pre-read.

Core storyline:

1. Executive answer.
2. Situation and ambition.
3. Complication or performance gap.
4. Root causes/strategic diagnosis.
5. Strategic options.
6. Evaluation criteria.
7. Recommended direction.
8. Value/impact.
9. Risks and mitigations.
10. Roadmap and next decisions.

Core visuals:

- issue tree;
- strategic options matrix;
- benchmark comparison;
- driver analysis;
- portfolio/2×2;
- recommendation architecture;
- impact versus feasibility;
- roadmap.

Quality benchmark: titles alone must communicate the full argument from context to recommendation and implementation.

#### MVP-02 — Market, Competitive & Market Entry Analysis

**Primary users:** consultants, corporate strategy, founders, product/market analysts.  
**Decision supported:** Where should we compete, and is the opportunity attractive?  
**Typical inputs:** market reports, competitor data, internal sales, customer research, public sources.  
**Default mode:** executive pre-read.

Core storyline:

1. Executive market conclusion.
2. Scope, definition, and methodology.
3. Market size and growth.
4. Segment attractiveness.
5. Demand drivers and trends.
6. Customer needs/whitespace.
7. Competitor landscape.
8. Positioning or market-entry options.
9. Attractiveness versus ability to win.
10. Recommendation, risks, and entry roadmap.

Core visuals:

- TAM/SAM/SOM;
- growth trend;
- segment waterfall;
- competitor benchmark;
- market map;
- attractiveness matrix;
- customer segmentation;
- entry roadmap.

Quality benchmark: all market numbers require definition, period, geography, and source; assumptions must be visible.

#### MVP-03 — Performance Review, Management Report & Board Update

**Primary users:** FP&A, CFO office, business unit heads, corporate strategy.  
**Decision supported:** What changed, why, what is at risk, and what action is required?  
**Typical inputs:** Excel/CSV, financial statements, KPI exports, operational notes, prior-period decks.  
**Default mode:** executive pre-read with optional live summary.

Core storyline:

1. Executive performance summary.
2. KPI scorecard.
3. Revenue and profitability.
4. Budget/prior-period variance.
5. Segment/product/customer drivers.
6. Operational performance.
7. Cash, capacity, or resource implications.
8. Outlook and scenarios.
9. Risks and opportunities.
10. Management actions and decisions required.

Core visuals:

- KPI cards;
- actual versus budget bars;
- variance waterfall;
- trend charts;
- segment bridge;
- heatmap;
- forecast band;
- risk/action table.

Quality benchmark: every total reconciles, units remain consistent, and material variances receive an explanation or explicit unresolved flag.

#### MVP-04 — Business Case, Financial Impact & Profitability

**Primary users:** consultants, corporate strategy, finance, transformation leaders.  
**Decision supported:** Should the organization invest, change, launch, or stop?  
**Typical inputs:** baseline data, cost estimates, benefit assumptions, model outputs, risk inputs.  
**Default mode:** executive pre-read.

Core storyline:

1. Decision and executive recommendation.
2. Problem/opportunity and baseline.
3. Options considered.
4. Strategic and operational benefits.
5. Costs and resource requirements.
6. Financial returns.
7. Scenario and sensitivity.
8. Risks and dependencies.
9. Implementation path.
10. Decision requested.

Core visuals:

- benefit/cost bridge;
- NPV/ROI/payback summary;
- sensitivity matrix;
- scenario comparison;
- profitability waterfall;
- initiative economics;
- risk matrix;
- implementation roadmap.

Quality benchmark: assumptions, formulas, time horizon, currency, nominal/real basis, and scenario definitions are traceable.

#### MVP-05 — Transformation Roadmap, PMO & Implementation Plan

**Primary users:** consultants, transformation office, PMO, strategy execution leads.  
**Decision supported:** How will the recommendation be executed and governed?  
**Typical inputs:** target-state design, initiative list, dependency notes, owners, timing, benefits, risks.  
**Default mode:** steering committee pre-read or workshop.

Core storyline:

1. Case for change.
2. Transformation ambition and target state.
3. Current-to-target gaps.
4. Workstreams.
5. Initiative prioritization.
6. Integrated roadmap.
7. Milestones and dependencies.
8. Governance and accountabilities.
9. Benefits tracking.
10. Risks, mitigations, and immediate next steps.

Core visuals:

- target-state model;
- gap heatmap;
- initiative cards;
- impact/effort matrix;
- roadmap/swimlane;
- dependency map;
- governance/RACI;
- benefit realization curve.

Quality benchmark: initiatives, owners, milestones, dependencies, and benefits must reconcile across slides.

### 25A.7 Complete business-topic taxonomy

The taxonomy defines commercial packs and benchmark groups. A deck may combine several topics; status refers to the availability of a validated, quality-guaranteed playbook.

| ID | Business topic/category | Representative deck types | Status |
| --- | --- | --- | --- |
| C01 | Business Strategy & Strategic Recommendation | Corporate strategy, growth strategy, strategic options | **MVP** |
| C02 | Market, Industry, Competition & Market Entry | Market sizing, competitor analysis, market-entry assessment | **MVP** |
| C03 | Performance, Management & Board Reporting | MBR, QBR, board update, KPI review, variance story | **MVP** |
| C04 | Business Case, Finance, Pricing & Profitability | Investment case, ROI, pricing, margin improvement | **MVP** |
| C05 | Transformation, PMO & Implementation | Transformation plan, SteerCo, workstreams, roadmap | **MVP** |
| C06 | Go-to-Market & Commercial Strategy | GTM, channel strategy, commercial acceleration | V2 — ON-PROGRESS ROADMAP |
| C07 | Consulting, Service & Partnership Proposal | Consulting proposal, solution proposal, partnership pitch | V2 — ON-PROGRESS ROADMAP |
| C08 | Product Strategy & Portfolio | Product vision, portfolio choices, feature roadmap | V2 — ON-PROGRESS ROADMAP |
| C09 | Customer Insights, Segmentation & Experience | Segmentation, voice of customer, customer journey | V2 — ON-PROGRESS ROADMAP |
| C10 | Sales & Marketing Performance | Funnel, campaign review, sales effectiveness | V2 — ON-PROGRESS ROADMAP |
| C11 | Operations & Process Excellence | Process diagnosis, lean improvement, service operations | V2 — ON-PROGRESS ROADMAP |
| C12 | Supply Chain, Procurement & Network | Supply chain redesign, sourcing, inventory, network | V2 — ON-PROGRESS ROADMAP |
| C13 | Organization, Workforce & Operating Model | Org design, capability model, spans/layers, workforce plan | V2 — ON-PROGRESS ROADMAP |
| C14 | Digital, Data, Technology & AI Strategy | Digital strategy, AI portfolio, architecture roadmap | V2 — ON-PROGRESS ROADMAP |
| C15 | M&A, Due Diligence & Integration | Screening, diligence, synergy, integration plan | V2 — SPECIALIST PACK |
| C16 | Risk, Scenario, Resilience & Compliance | Enterprise risk, scenario planning, controls | V2 — ON-PROGRESS ROADMAP |
| C17 | Sustainability & ESG | ESG strategy, emissions roadmap, sustainability report | V2 — ON-PROGRESS ROADMAP |
| C18 | Investor Pitch & Fundraising | Startup pitch, investor update, fundraising story | V2 — ON-PROGRESS ROADMAP |
| C19 | Annual Planning, OKR & Leadership Offsite | Annual plan, OKRs, strategic offsite | V2 — ON-PROGRESS ROADMAP |
| C20 | Research, Industry Outlook & Thought Leadership | Industry report, whitepaper summary, trend outlook | V2 — ON-PROGRESS ROADMAP |
| C21 | Training, Workshop & Education | Workshop deck, training material, case presentation | V2 — ON-PROGRESS ROADMAP |
| C22 | Public Sector & Policy | Policy options, program evaluation, public-service roadmap | V2 — SPECIALIST PACK |

### 25A.8 Why visible high-demand categories are not all MVP

#### Investor pitch deck

Pitch decks have high search visibility and direct buyer access. They are not MVP because:

- general AI presentation tools already compete heavily here;
- the visual grammar is more marketing- and narrative-led than consulting pre-read;
- usage is less recurring per buyer;
- differentiation from Gamma, Canva, and Beautiful.ai would be weaker;
- fundraising claims require separate legal and evidence guardrails.

It remains a strong V2 pack after the core reasoning and visual engine is stable.

#### Sales/marketing deck

Sales and marketing teams create presentations frequently, but their needs include brand campaigns, persuasive imagery, and engagement analytics. The underlying asset and layout system differs from analytical consulting decks, so this category enters V2.

#### M&A/due diligence

Willingness to pay is high, but errors have greater legal and financial consequences. This becomes a specialist pack only after source lineage, financial validation, confidentiality, and data-room workflows mature.

### 25A.9 Product promise and claims contract

#### Locked primary promise

> **Turn briefs, reports, and spreadsheets into editable, evidence-backed, consulting-grade PowerPoint decks—using your preferred AI.**

#### Supporting promise

- answer-first story before slide generation;
- original consulting-grade visual system;
- fully editable business content;
- deterministic chart and annotation engine;
- source-aware analysis;
- automated QA and repair;
- portable workflow across leading AI platforms.

#### Claims allowed after validation

- “Consulting-grade PowerPoint workflow.”
- “Editable PPTX, not flattened images.”
- “Built for strategy, finance, and transformation professionals.”
- “Works across leading AI through a portable core and adapters.”
- “Original themes, layouts, and icons.”
- “Evidence and QA built into the workflow.”

#### Claims prohibited

- “Official McKinsey/BCG/Bain template.”
- “Affiliated with or approved by a consulting firm.”
- “Identical output on every AI platform.”
- “Zero human review required.”
- “Never hallucinates.”
- “Builds every type of presentation at launch.”
- “Pixel-perfect clone of a protected deck.”

### 25A.10 MVP output contract

| Dimension | Locked decision |
| --- | --- |
| Primary output | `.pptx` PowerPoint |
| Aspect ratio | 16:9 |
| Guaranteed content range | 8–20 content slides plus appendix |
| Languages | English and Bahasa Indonesia |
| Default deck mode | Executive pre-read |
| Other modes | Live presentation and workshop through density settings |
| Default workflow | Guided Mode with decision-contract and storyboard checkpoints |
| Inputs | Text/Markdown, PDF, DOCX, XLSX, CSV, and PPTX as reference |
| Evidence policy | Strict: sourced, calculated, inferred, placeholder, or unsupported |
| Default theme | Original `Executive Blue` profile |
| Second MVP theme | Original `Strategy Green` profile |
| Required delivery | PPTX, DeckSpec, sources file, and QA report |
| Optional delivery | Preview PDF and data-lineage workbook |
| Quality threshold | ≥85/100 and no critical hard fail |
| Privacy mode | Local-first runtime; no external transmission without permission |

MVP quality guarantee applies only to the five validated playbooks. The generic engine may draft other categories, but marketing must not claim the same benchmark coverage before V2 evaluation is complete.

### 25A.11 Editability contract

Default editability level is **Practical Editability**:

- titles, subtitles, body text, sources, tables, and business shapes are editable;
- native PowerPoint charts are used when reliable and appropriate;
- advanced charts may be shape-based, but individual elements remain editable;
- original icons remain recolorable SVG or native PowerPoint shapes where feasible;
- no slide is delivered as a single flattened image;
- raster content is limited to photographs or illustrations that are inherently raster;
- chart source data is preserved or delivered separately when the format allows;
- users can change theme colors and typography without rebuilding the deck.

The product does not promise that every imported SVG can be ungrouped into native PowerPoint paths on every platform.

### 25A.12 Cross-AI compatibility contract

The core product is model-neutral because all supported platforms exchange the same ProjectSpec, StorySpec, SlideSpec, and EvidenceLedger. Execution depth depends on each AI surface.

| Platform/surface | MVP status | Compatibility level | Promise |
| --- | --- | --- | --- |
| Claude with file/code runtime | Official MVP adapter | A — Full runtime | End-to-end plan, build, render, and audit where the surface permits |
| Generic local CLI | Official MVP interface | A/B | Any AI can produce DeckSpec; CLI builds and audits the PPTX |
| ChatGPT/Codex | Supported through portable core | B at MVP; A target in V2 | Guided handoff to the shared runtime; dedicated adapter follows |
| Gemini | Supported through portable core | B at MVP; A where runtime permits in V2 | Generate valid DeckSpec and use shared CLI |
| DeepSeek | Supported through portable core | B/C at MVP | Generate storyline/spec; use shared CLI for deterministic build |
| Other LLMs | Generic compatibility | C, upgradeable to B | Use generic instruction pack and schema |

Marketing wording:

> “Compatible with leading AI models through a shared open specification and local deck runtime. Automation depth varies by platform.”

This wording replaces an unqualified “works identically on all AI” claim.

### 25A.13 Distribution contract

MVP distribution is a **downloadable hybrid bundle**, not a mandatory SaaS.

Components:

1. Portable Markdown/JSON knowledge core.
2. Claude adapter.
3. Generic AI adapter.
4. Local runtime/CLI.
5. Original themes and assets.
6. Five MVP playbooks.
7. Benchmark and QA pack.
8. Quickstart, installation, and troubleshooting.
9. Sample inputs and reproducible sample outputs.

Platform adapters must remain thin. Consulting intelligence, schemas, assets, and runtime logic may not be duplicated independently in each adapter.

### 25A.14 License and pricing contract

#### Individual Pro license

- one named user;
- commercial use of generated client/company outputs is allowed;
- perpetual use of the purchased version;
- 12 months of updates from purchase date;
- no redistribution, resale, sublicensing, or public upload of skill source, runtime, themes, templates, or icon pack;
- generated decks belong to the buyer, subject to the buyer's input rights and applicable law;
- reference consulting decks are not included in the distributed bundle;
- support scope covers installation and reproducible product defects, not unlimited custom deck consulting.

#### Price ladder

| Stage | Price | Purpose |
| --- | ---: | --- |
| Private beta | USD 59 | Validate activation, output quality, and support burden |
| Public launch | USD 79 | Strong value relative to template packs while building adoption |
| Mature list price | USD 99 | Applied after cross-AI adapters, broader QA, and asset library mature |

Team/multi-seat, enterprise, and white-label licenses are V2 commercial products and require separate terms.

### 25A.15 Acquisition-channel contract

#### MVP channels

1. **YouTube creator partnerships and demonstrations**
   - AI productivity;
   - PowerPoint and presentation design;
   - consulting careers and skills;
   - finance/FP&A and CFO content;
   - business analysis and strategy.
2. **LinkedIn proof-of-work content**
   - before/after slides;
   - title-only storylines;
   - Excel-to-board-deck examples;
   - chart repair and QA examples.
3. **Productive AI website**
   - product page;
   - reproducible demos;
   - documentation previews;
   - checkout;
   - tutorials and comparison content.
4. **Affiliate program after beta validation**
   - creator codes;
   - tracked demos;
   - commission funded by digital-product margin.

Paid advertising is not an MVP priority. Product credibility depends on visible, reproducible transformation of real business inputs into editable outputs.

#### Five launch demo narratives

- Report → Strategy recommendation deck.
- Market research PDFs → Market-entry assessment.
- Excel financials → Monthly board/performance deck.
- Financial model → Investment business case.
- Initiative list → Transformation roadmap and SteerCo deck.

Every marketing demo must use the same product version delivered to customers.

### 25A.16 Phase-0 non-goals

MVP will not optimize for:

- generic school presentations;
- event keynotes;
- highly photographic brand campaigns;
- complex animation;
- social media carousels;
- native real-time Google Slides collaboration;
- automatic access to confidential enterprise systems;
- M&A-grade legal diligence;
- fundraising claim validation;
- exact replication of a named consulting firm's design.

### 25A.17 Phase-0 quality and hard-fail adoption

Phase 0 adopts the quality model in Section 19 without modification:

- score threshold ≥85/100;
- no hallucinated or unsupported factual claims;
- no calculation inconsistency;
- no misleading chart;
- no missing material source;
- no broken/repair-required PPTX;
- no material clipping/overlap;
- no protected asset copying;
- explicit human review for high-stakes financial conclusions.

### 25A.18 Phase-0 exit gate

| Requirement | Status |
| --- | --- |
| Beachhead persona selected | COMPLETE |
| Primary adjacent personas selected | COMPLETE |
| Five MVP playbooks selected | COMPLETE |
| Complete category taxonomy defined | COMPLETE |
| V2/on-progress roadmap marked | COMPLETE |
| Product promise locked | COMPLETE |
| Output contract locked | COMPLETE |
| Editability contract locked | COMPLETE |
| Compatibility contract locked | COMPLETE |
| Distribution model locked | COMPLETE |
| License and price ladder locked | COMPLETE |
| IP/source policy adopted | COMPLETE |
| QA threshold and hard fails adopted | COMPLETE |
| Compiler implementation selected | DEFERRED BY DESIGN TO PHASE 6 TECHNICAL SPIKE |

**Phase-0 conclusion:** Exit gate passed. Phase 1 may begin.

### 25A.19 Required input for Phase 1

Reference corpus should now be collected and classified against the five MVP playbooks—not uploaded as an undifferentiated folder.

Initial target:

- 3–5 representative full decks for each MVP family;
- approximately 15–25 decks in the first batch;
- PPTX preferred when legally available and editable;
- PDF accepted for pattern analysis;
- screenshots used only when no complete deck exists;
- each file retains its source, year, firm/publisher, and usage permission.

If files are not pre-classified, the corpus-inventory process will classify them. Icons, color palettes, and design styles remain Phase 5 inputs and are not required to start Phase 1.

### 25A.20 Research references

1. Gamma, [How we built a USD 100M business differently](https://gamma.app/insights/how-we-built-a-usd100m-business-differently).
2. Canva, [Visual Economy Report 2024](https://www.canva.com/newsroom/news/visual-economy-report-2024/).
3. Canva, [Visual Communications Report 2025](https://www.canva.com/visual-communications-report/).
4. Microsoft WorkLab, [Breaking down the infinite workday](https://www.microsoft.com/en-us/worklab/work-trend-index/breaking-down-infinite-workday).
5. Beautiful.ai, [Study on presentation productivity value](https://www.beautiful.ai/blog/study-reveals-beautiful-ai-presentation-tools-return-over-1b-in-annual-productivity-value).
6. Slideworks, [PowerPoint and Google Slides templates by ex-consultants](https://slideworks.io/templates).
7. Deckary, [Consulting and business PowerPoint templates](https://deckary.com/templates).
8. Firm Learning, [Ex-McKinsey Consultant tests Claude for PowerPoint](https://www.youtube.com/watch?v=0EKUBCCOlxc).
9. Gandhi et al., [PPT-Eval: A Benchmark for Computer-Use Agents on PowerPoint Tasks](https://arxiv.org/abs/2606.31154).

---

## 26. Roadmap Pembangunan Step by Step

Estimasi berikut adalah **effort range**, bukan janji kalender. Untuk satu builder full-time, MVP berkualitas kemungkinan membutuhkan sekitar 14–22 minggu tergantung kedalaman compiler dan asset creation.

### Phase 0 — Product contract and constraints

**Status:** COMPLETED — lihat Section 25A.  
**Tujuan:** Mengunci apa yang dijanjikan dan apa yang tidak.

Tasks:

1. Tetapkan buyer persona primer.
2. Pilih 3–5 use cases MVP.
3. Tetapkan output contract.
4. Tetapkan editability contract.
5. Tetapkan compatibility levels per AI.
6. Tetapkan IP and source policy.
7. Tetapkan quality score dan hard fails.

Deliverables:

- Product Requirements Document;
- MVP scope;
- acceptance criteria;
- legal/IP checklist.

Exit gate: seluruh klaim marketing dapat dibuktikan melalui test.

### Phase 1 — Reference corpus inventory

**Tujuan:** Mengubah koleksi deck menjadi dataset analisis yang terstruktur.

Tasks:

1. Inventarisasi seluruh file.
2. Catat source/license/status.
3. Pisahkan client deck, public report, template, dan modern/legacy style.
4. Buat slide-level metadata.
5. Pilih exemplars dan anti-patterns.
6. Pisahkan logic lessons dari visual imitation.

Deliverables:

- corpus catalog;
- slide annotation schema;
- exemplar set;
- prohibited redistribution list.

Exit gate: setiap reference dapat dilacak dan fungsi pembelajarannya jelas.

### Phase 2 — Consulting-Grade Standard

**Tujuan:** Menulis standard yang dapat diuji.

Tasks:

1. Definisikan decision contract.
2. Definisikan Pyramid/MECE checks.
3. Definisikan title rules.
4. Definisikan horizontal dan vertical logic.
5. Definisikan slide anatomy.
6. Definisikan source and evidence rules.
7. Buat weighted scorecard.

Deliverables:

- `consulting-grade-standard.md`;
- story rubric;
- slide rubric;
- deck rubric;
- hard-fail list.

Exit gate: dua reviewer dapat menilai deck yang sama dengan hasil relatif konsisten.

### Phase 3 — Semantic specifications

**Tujuan:** Membuat kontrak data antara AI dan compiler.

Tasks:

1. Desain ProjectSpec.
2. Desain StorySpec.
3. Desain SlideSpec.
4. Desain EvidenceLedger dan ClaimLedger.
5. Buat JSON schemas/Pydantic models.
6. Buat valid dan invalid fixtures.
7. Tentukan schema versioning.

Deliverables:

- versioned schemas;
- validators;
- sample specs;
- migration policy.

Exit gate: spec lengkap dapat membangun sample deck tanpa instruksi tambahan yang ambigu.

### Phase 4 — Consulting intelligence core

**Tujuan:** Membuat reasoning workflow yang portable.

Tasks:

1. Bangun intake workflow.
2. Bangun hypothesis and issue-tree workflow.
3. Bangun storyline workflow.
4. Bangun action-title generator dan critic.
5. Bangun chart and archetype selector.
6. Bangun approval flow.
7. Buat few-shot examples yang orisinal.

Deliverables:

- core reference files;
- orchestration instructions;
- example conversations;
- storyline evals.

Exit gate: model berbeda dapat menghasilkan DeckSpec dengan structure yang sebanding.

### Phase 5 — Original design system

**Tujuan:** Membuat visual language yang konsisten dan bukan tiruan.

Tasks:

1. Tentukan grid dan spacing scale.
2. Tentukan typography and fallback.
3. Buat semantic color system.
4. Buat dua design profiles.
5. Buat 15–20 archetypes.
6. Buat component library.
7. Buat icon style guide.
8. Produksi 250–400 icons.
9. Uji live versus pre-read density.

Deliverables:

- design tokens;
- theme files;
- layout definitions;
- icon pack;
- visual QA examples.

Exit gate: semua archetype terasa sebagai satu keluarga desain dan tetap terbaca pada kondisi nyata.

### Phase 6 — Compiler technical spike

**Tujuan:** Mengurangi risiko teknis sebelum membangun penuh.

Tasks:

1. Implementasikan 5 representative slides di PptxGenJS.
2. Implementasikan set yang sama di `python-pptx` bila perlu.
3. Uji native charts, shape-based charts, SVG, tables, notes, dan sources.
4. Uji PowerPoint Windows/Mac/Web.
5. Uji file repair warnings.
6. Pilih compiler utama dan OOXML patch strategy.

Deliverables:

- technical decision record;
- proof-of-concept PPTX;
- compatibility matrix;
- known limitations.

Exit gate: compiler utama dipilih berdasarkan bukti, bukan preferensi.

### Phase 7 — PPTX compiler MVP

**Tujuan:** Membangun DeckSpec menjadi PowerPoint editable.

Tasks:

1. Implement theme resolver.
2. Implement grid/layout engine.
3. Implement text measurement and content budgets.
4. Implement core chart families.
5. Implement tables and diagrams.
6. Implement source/footer system.
7. Implement icon resolver.
8. Implement metadata and file packaging.

Deliverables:

- CLI build command;
- 15–20 archetypes;
- 8–10 chart families;
- sample outputs;
- unit and snapshot tests.

Exit gate: sample decks dapat dibuka tanpa repair dan elemen utama editable.

### Phase 8 — Annotation and “final 5%” engine

**Tujuan:** Mengurangi manual cleanup yang membedakan draft AI dari deck profesional.

Tasks:

1. CAGR and delta annotations.
2. Series ordering.
3. Aggregation brackets.
4. Stacked connectors.
5. Direct-label placement.
6. Reference and target lines.
7. Scenario bands.
8. Collision-aware callouts.
9. Consistent highlight propagation.

Deliverables:

- annotation library;
- math tests;
- visual regression cases.

Exit gate: representative slides tidak membutuhkan koreksi manual pada anotasi dasar.

### Phase 9 — Render, QA, and repair loop

**Tujuan:** Menjamin kualitas secara otomatis.

Tasks:

1. Build render pipeline.
2. Build OOXML/file integrity checks.
3. Build geometry/collision checks.
4. Build numeric and source checks.
5. Build cross-slide consistency checks.
6. Build vision review prompts.
7. Build repair policies.
8. Produce QA report.

Deliverables:

- `audit` command;
- `repair` command;
- QA report schema;
- pass/fail dashboard for development.

Exit gate: benchmark deck mencapai ≥85/100 tanpa hard fail.

### Phase 10 — Claude adapter

**Tujuan:** Membuat first-class experience pada Claude.

Tasks:

1. Tulis concise `SKILL.md`.
2. Hubungkan progressive references.
3. Hubungkan runtime scripts.
4. Buat install guide per Claude surface.
5. Buat 10 trigger tests dan 10 workflow evals.
6. Uji model capability tiers.

Deliverables:

- installable Claude skill package;
- Claude quickstart;
- evaluation results;
- troubleshooting guide.

Exit gate: pengguna baru dapat menghasilkan sample deck tanpa bantuan pembuat produk.

### Phase 11 — Cross-AI adapters

**Tujuan:** Membuktikan portable core.

Urutan yang disarankan:

1. Generic CLI/system prompt adapter.
2. OpenAI/ChatGPT/Codex adapter.
3. Gemini adapter.
4. DeepSeek adapter.

Tasks per adapter:

- map platform capabilities;
- define instructions and tool calls;
- document limitations;
- run common benchmark suite;
- confirm output schema equivalence;
- publish compatibility level.

Exit gate: adapter tidak mengubah core business rules dan output tetap lolos benchmark minimum.

### Phase 12 — Beta program

**Tujuan:** Menguji produk pada pekerjaan nyata.

Beta cohort yang disarankan:

- 5 consultants/analysts;
- 5 founders/business users;
- 5 non-designers;
- variasi Windows dan macOS;
- variasi AI platform.

Track:

- time to first deck;
- completion rate;
- manual cleanup time;
- QA score;
- failed installation rate;
- revision count;
- perceived trust;
- willingness to pay.

Exit gate: minimal 80% beta users berhasil membuat deck, median cleanup ≤10 menit per 10 slides, dan tidak ada recurring hard fail.

### Phase 13 — Commercial packaging and launch

**Tujuan:** Mengubah engineering package menjadi produk yang dapat dibeli dan digunakan.

Tasks:

1. Buat installer dan diagnostics.
2. Buat 10-minute quickstart.
3. Buat sample briefs/data/decks.
4. Buat license terms.
5. Buat product page dan demo yang dapat direproduksi.
6. Buat support/troubleshooting flow.
7. Buat version and update policy.
8. Tetapkan refund policy.
9. Siapkan customer feedback channel.

Exit gate: pembeli dapat install, menjalankan demo, membangun deck, dan memahami batas platform tanpa bantuan langsung.

---

## 27. Prioritas Backlog Implementasi Pertama

Urutan pekerjaan ketika fase build dimulai:

1. Buat corpus inventory template.
2. Katalogkan 100 slide referensi pertama.
3. Finalkan Consulting-Grade Scorecard v0.1.
4. Finalkan ProjectSpec/StorySpec/SlideSpec v0.1.
5. Buat 10 gold-standard title-only storyboards.
6. Definisikan 15 archetype MVP.
7. Definisikan 8 chart decision paths.
8. Buat design tokens untuk `Executive Blue`.
9. Implementasikan satu “golden slide” per archetype.
10. Jalankan compiler spike.
11. Implementasikan build CLI.
12. Implementasikan render dan collision checks.
13. Implementasikan CAGR/delta/direct labels.
14. Buat Claude adapter.
15. Jalankan 20 benchmark cases.
16. Perbaiki failure clusters.
17. Baru setelah itu memperluas icon count dan adapter lain.

Prinsip urutan: **quality system terlebih dahulu, volume assets setelah core terbukti.**

---

## 28. Product Packaging dan Harga

### 28.1 Model harga yang dikunci pada Phase 0

Gunakan satu flagship product dengan price ladder berbasis maturity:

| Paket | Harga indikatif | Isi |
| --- | ---: | --- |
| Private Beta | USD 59 | Core, Claude + generic adapter, 2 themes, runtime, core icons, dan beta updates |
| Public Launch | USD 79 | Flagship individual license, lima MVP playbooks, assets, runtime, QA tools, examples, dan 12 bulan updates |
| Mature List Price | USD 99 | Diterapkan setelah adapter, QA coverage, documentation, dan asset library mencapai maturity gate |

Team/commercial multi-seat license dapat dibuat kemudian setelah pola penggunaan jelas.

### 28.2 Hindari jebakan pricing

- Jangan menjanjikan lifetime updates tanpa memperhitungkan support burden.
- Jangan menjual “all AI” sebelum compatibility matrix dapat dibuktikan.
- Jangan mengandalkan jumlah template/icon sebagai satu-satunya value metric.
- Jangan menjual hak redistribusi source assets pada lisensi individual.

### 28.3 Isi bundle pembeli

- adapter packages;
- runtime/CLI;
- original themes and templates;
- original icon pack;
- documentation;
- quickstart;
- sample projects;
- QA/evaluator;
- compatibility matrix;
- license;
- changelog.

---

## 29. IP, Trademark, dan Lisensi

### 29.1 Reference usage

Deck consulting publik digunakan untuk:

- analisis pola;
- pembelajaran internal;
- evaluasi;
- penurunan prinsip abstrak.

Jangan mendistribusikan ulang deck, screenshot, template, font, logo, icon, atau elemen proprietary tanpa izin.

### 29.2 Marketing language

Gunakan frasa seperti:

- consulting-grade;
- top-tier consulting quality;
- answer-first executive storytelling;
- MBB-inspired problem-solving principles, jika telah ditinjau secara legal.

Hindari klaim seolah-olah produk:

- dibuat oleh;
- disetujui oleh;
- berafiliasi dengan;
- menggunakan template resmi milik firma tertentu.

### 29.3 Originality requirements

- Semua themes dibuat dari nol.
- Semua sample deck menggunakan data sintetis atau data yang boleh digunakan.
- Semua icons dibuat sendiri atau memiliki lisensi redistribusi.
- Nama design profiles tidak meniru firma.
- Marketing demo harus reproducible dengan produk yang dijual.

Legal review tetap disarankan sebelum launch.

---

## 30. Privacy dan Security

Karena pengguna dapat memproses data rahasia, produk harus:

- mendukung local-first runtime;
- tidak mengirim file ke layanan lain tanpa izin;
- menjelaskan kapan platform AI dapat mengakses file;
- tidak menyimpan dokumen pengguna secara default;
- menyediakan temporary working directory cleanup;
- redaction option untuk logs;
- tidak memasukkan content pengguna ke telemetry;
- menyediakan mode offline sejauh dependency memungkinkan;
- memisahkan sample/test data dari customer data.

Security documentation harus menjelaskan data flow per platform.

---

## 31. Risiko Utama dan Mitigasi

| Risiko | Dampak | Mitigasi |
| --- | --- | --- |
| Output AI tidak konsisten | Deck quality bervariasi | Semantic schema, deterministic compiler, benchmark per model |
| “Works on all AI” terlalu luas | Ekspektasi pelanggan salah | Compatibility levels dan matrix yang transparan |
| PowerPoint render berbeda antar-platform | Layout rusak | Cross-platform test matrix dan safe fonts |
| Reference assets melanggar IP | Risiko legal | Distilasi prinsip, original assets, license registry |
| Storyline bagus tetapi data salah | Kehilangan kepercayaan | Evidence/Claim Ledger, strict source policy |
| Banyak templates tetapi sulit dipilih | User experience buruk | Archetype decision engine |
| Advanced annotations masih manual | Value proposition melemah | Prioritaskan “final 5%” engine |
| Instalasi terlalu teknis | Refund/support tinggi | Installer, diagnostics, one-command demo |
| Model update mengubah perilaku | Regression | Versioned eval suite dan adapter tests |
| File editable tetapi sulit dimodifikasi | Janji produk tidak terasa | Editability contract dan customer tests |
| Terlalu padat untuk live presentation | Engagement buruk | Deck density modes |
| Harga murah memicu support berlebihan | Margin rendah | Documentation, scoped support, 12-month updates |

---

## 32. Success Metrics

### 32.1 Product quality

- 100% generated PPTX terbuka tanpa repair prompt.
- 0 critical overlap/clipping pada released benchmark.
- 100% external factual claims memiliki source atau status placeholder.
- 100% calculated claims memiliki lineage.
- ≥85/100 Consulting-Grade Score pada benchmark release.
- ≥95% slide titles didukung oleh slide body menurut human review.
- ≥90% cross-slide numeric consistency.

### 32.2 User outcomes

- ≥80% pengguna baru menyelesaikan first deck tanpa bantuan langsung.
- Median time to first valid 10-slide deck ≤30 menit setelah instalasi.
- Median manual cleanup ≤10 menit per 10 slides pada MVP.
- Target V1: manual cleanup ≤5 menit per 10 slides.
- ≥70% beta users menyatakan output lebih baik daripada workflow AI mereka sebelumnya.

### 32.3 Commercial

- activation rate setelah pembelian;
- refund rate;
- support tickets per 100 customers;
- adapter usage share;
- repeat deck generation;
- upgrade conversion;
- willingness to recommend.

---

## 33. Release Gates

Produk belum boleh disebut siap jual sebelum semua gate berikut terpenuhi.

### Gate A — Strategy

- Buyer persona dan use case MVP jelas.
- Marketing promise dapat diuji.
- Scope dan non-goals tertulis.

### Gate B — Quality standard

- Consulting-Grade Standard selesai.
- Hard-fail conditions otomatis atau dapat dinilai.
- Reference corpus terklasifikasi.

### Gate C — Technical

- DeckSpec schema versioned.
- Compiler membangun seluruh archetype MVP.
- PPTX lolos compatibility tests.
- Render/audit/repair berjalan.

### Gate D — Cross-AI

- Claude adapter lolos eval.
- Generic CLI tersedia.
- Setidaknya satu adapter non-Claude terbukti.
- Capability limitations dipublikasikan.

### Gate E — Commercial

- Installer dan quickstart diuji pengguna baru.
- License/IP registry selesai.
- Demo reproducible.
- Support dan update policy jelas.

---

## 34. Definition of Done untuk Satu Deck

Satu deck dinyatakan selesai apabila:

- decision contract disetujui atau cukup jelas;
- title-only storyline koheren;
- setiap content slide memiliki satu governing insight;
- setiap claim utama didukung evidence;
- chart menjawab analytical intent yang benar;
- mental math penting sudah dihilangkan melalui annotation;
- design profile konsisten;
- sources dan notes tersedia;
- tidak ada critical numeric error;
- tidak ada overflow, clipping, atau overlap material;
- file terbuka tanpa repair;
- elemen utama editable sesuai contract;
- QA score ≥85/100;
- semua warnings tersisa disampaikan kepada pengguna.

---

## 35. Definition of Done untuk Produk V1

Produk V1 dinyatakan selesai apabila:

1. Portable consulting core terdokumentasi dan versioned.
2. Runtime dapat membangun deck dari valid DeckSpec.
3. Claude, OpenAI, Gemini, DeepSeek, dan generic adapters memiliki compatibility status yang jujur.
4. Minimal 30 archetypes dan core chart families tersedia.
5. Original design system dan icon pack selesai.
6. Automated QA dan repair menangani recurring layout failures.
7. Benchmark suite berjalan pada setiap release.
8. Dokumentasi instalasi dan troubleshooting diuji oleh pengguna baru.
9. Semua assets memiliki provenance/license record.
10. Sample outputs dapat direproduksi menggunakan produk yang dikirim ke pembeli.

---

## 36. Keputusan Produk yang Harus Dikunci Sebelum Coding

Phase 0 telah mengunci keputusan produk berikut:

1. **Beachhead persona:** independent/boutique consultants.
2. **Primary adjacent personas:** corporate strategy/transformation analysts dan FP&A/finance professionals.
3. **Use case MVP:** strategy, market analysis, performance/board reporting, business case, dan transformation roadmap.
4. **Distribution model:** downloadable hybrid bundle berupa portable core, adapters, local runtime/CLI, assets, dan QA pack.
5. **Compatibility promise:** shared specification untuk seluruh AI; automation depth dipublikasikan melalui level A/B/C.
6. **License model:** one-user commercial-output license, perpetual purchased version, dan 12 bulan updates.
7. **Price ladder:** USD 59 beta, USD 79 public launch, dan USD 99 mature list price.

Satu keputusan teknis sengaja belum dikunci: **compiler utama**. PptxGenJS versus `python-pptx` harus dipilih berdasarkan Phase 6 technical spike, bukan asumsi. Deferred decision ini tidak menghalangi Phase 1–5 karena seluruh layer berkomunikasi melalui versioned Semantic DeckSpec.

---

## 37. Rekomendasi Strategis Final

Produk terbaik untuk peluang ini bukan “Claude skill yang bisa membuat slide seperti McKinsey.” Formulasi tersebut terlalu sempit, terlalu bergantung pada satu vendor, dan terlalu mudah ditiru.

Produk yang lebih defensible adalah:

> **Sistem lintas-AI yang mengubah reasoning bisnis menjadi PowerPoint consulting-grade melalui portable consulting intelligence, semantic deck specifications, original visual assets, deterministic slide generation, dan automated quality assurance.**

Urutan prioritas yang benar adalah:

1. standard kualitas;
2. corpus yang terstruktur;
3. reasoning dan semantic specs;
4. original design system;
5. deterministic compiler;
6. final-5% annotation engine;
7. QA and repair;
8. Claude adapter;
9. adapter AI lain;
10. packaging dan komersialisasi.

Jika urutan ini dijaga, produk tidak hanya menghasilkan slide yang “terlihat consulting” pada screenshot. Produk akan menghasilkan deck yang **berpikir, berargumentasi, membuktikan, dan berkomunikasi** seperti deck consulting berkualitas tinggi—serta tetap editable, orisinal, dan dapat dipakai di berbagai AI.

---

## 38. Sumber Dasar yang Sudah Menjadi Acuan

- Anthropic, [The Complete Guide to Building Skills for Claude](https://resources.anthropic.com/hubfs/The-Complete-Guide-to-Building-Skill-for-Claude.pdf)
- SlideScience, [Consulting Slide Templates](https://slidescience.co/product/slide-templates/)
- YouTube, [Claude Just Changed PowerPoint Forever](https://www.youtube.com/watch?v=OP50TmSAUXI)
- Public consulting decks dan publikasi McKinsey, BCG, serta Bain yang telah dianalisis pada tahap riset sebelumnya
- Prinsip Pyramid Principle, MECE, action titles, evidence-led storytelling, dan chart selection yang telah didistilasi pada tahap riset

Catatan: sumber eksternal menjadi bahan pembelajaran dan evaluasi. Semua aset distribusi produk harus tetap orisinal atau memiliki lisensi yang sesuai.
