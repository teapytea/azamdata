# Phase 1B — Kurasi pola consulting-grade untuk produk PPT

Tanggal: 14 September 2026  
Proyek: Productive AI — sistem PPT consulting-grade  
Acuan: blueprint versi 1.1, keputusan Phase 0, dan inventaris Phase 1A.

## 1. Keputusan utama

**Kurasi Phase 1B atas korpus yang tersedia selesai.** Hasilnya adalah anotasi, peta alur, kandidat pola, dan kasus QA yang dapat dipakai untuk menyusun standar produk. **Gate korpus Phase 1 masih IN PROGRESS:** beberapa alur MVP belum mempunyai contoh lengkap, izin penggunaan aset sumber belum diselesaikan, dan kandidat belum menjadi gold set yang diperiksa manusia.

Koleksi Anda sudah kuat untuk mempelajari cara menyusun diagnosis, market analysis, financial impact, rekomendasi, dan rancangan transformasi. Kebutuhan berikutnya adalah **lima deck tambahan yang spesifik**, terutama untuk laporan manajemen/board, investment case, PMO berkala, dan market entry. Menambah banyak industry outlook umum tidak akan menutup celah tersebut.

Temuan penting: kualitas consulting-grade muncul dari hubungan **kesimpulan → bukti → implikasi → tindakan**, ditambah disiplin definisi, angka, dan penyajian. Kemiripan warna atau font saja belum cukup. Beberapa PDF referensi juga memperlihatkan kesalahan label, tanggal, dan layout; produk harus belajar mengenali kesalahan itu.

## 2. Apa yang benar-benar ditinjau

| Pekerjaan | Cakupan yang diselesaikan |
|---|---:|
| Korpus induk dari tiga ZIP | 29 file; 2.432 halaman/slide |
| File PDF yang seluruh teks/alurnya dibaca | 9 file; 269 halaman |
| Presentasi di dalam kompilasi D028 | Hlm.53–72; 20 halaman |
| Bagian terpilih D005 dan D003 | 27 + 4 halaman |
| Total halaman untuk review isi/alur | **320 halaman** |
| Kandidat yang diperiksa secara visual dan dianotasi | **120 halaman dari 12 sumber** |
| Keluarga pola analitis | **24** |
| Kandidat aturan produk | **22** |
| Pemeriksaan terpilih atas angka/tanggal/konteks/render | **24 kasus** |

Angka 320 dan 120 adalah ukuran review yang saling tumpang tindih; keduanya tidak dijumlahkan. Seluruh 2.432 halaman belum direview mendalam. Review visual dilakukan pada 30 contact sheet, lalu enam halaman bermasalah diperiksa lagi pada preview 1.600 piksel. Dua kasus collision/label juga diperiksa dengan dua renderer PDF. Ini bukan pengukuran pixel-perfect atau uji keterbacaan di ruang rapat.

Hasil klasifikasi 120 halaman:

| Klasifikasi | Jumlah | Arti |
|---|---:|---|
| `positive_logic` | 79 | Hubungan analitis yang berguna untuk dibuat ulang secara orisinal |
| `supporting_reference` | 27 | Mendukung metode, konteks, atau contoh parsial |
| `edge_case_semantics` | 7 | Kasus khusus yang mencegah QA keliru menilai angka/definisi |
| `anti_pattern` | 7 | Mengandung masalah yang perlu dicegah dalam output produk |

Klasifikasi ini bukan skor kualitas menyeluruh suatu firma atau deck. Status `positive_logic` juga bukan persetujuan menyalin desain/asetnya. Semua kandidat masih `production_gold_approved: false`.

## 3. Hasil pembacaan alur deck

Nomor halaman dalam laporan ini selalu **halaman PDF, dihitung mulai 1**. Nomor cetak di footer dapat berbeda. Nama asli dan hash setiap file tersedia pada katalog.

| ID dan sumber | Lingkup review isi | Pelajaran yang paling berguna | Batas cakupan |
|---|---|---|---|
| D023 — USPS Future Business Model | Seluruh 39 hlm. | Diagnosis historis → base case → tindakan internal → residual gap → urgensi keputusan | Belum recurring board report atau investment approval lengkap |
| D014 — MTA financial impact | Seluruh 38 hlm. | Metode dan asumsi per driver → skenario → rekonsiliasi funding gap | Cashflow pendapatan bukan otomatis investment cashflow |
| D024 — NHS digital impact | Seluruh 26 hlm. | Mekanisme biaya/volume, manfaat overlap, confidence, biaya adopsi, from-to | Hlm.4 sendiri menyatakan bukan pengganti business case lokal |
| D006 — ASEAN steel | Seluruh 19 hlm. | Tren pasar → implikasi → tiga arah tindakan; chart dengan commentary | Entry mode dan go/no-go belum lengkap; ada masalah render/label |
| D008 — Bain/Altagamma luxury | Seluruh 51 hlm. | Definisi pasar, restatement, currency basis, segmentasi, tujuh tema, rekomendasi | Outlook pasar belum keputusan market entry |
| D009 — Banking, Nordics | Seluruh 8 hlm. | Benchmark rasio, distribusi kinerja, revenue pools | Data industri belum company target-vs-actual report |
| D020 — King County, Some Facts | Seluruh 25 hlm. | Diagnosis → status reformasi → kapasitas/funding → solusi | Ada status implementasi terisi, tetapi belum PMO pack berkala |
| D028 — Administrative simplification | Presentasi hlm.53–72 | Annual run-rate, koreksi overlap, stakeholder dan enabler | Materi komisi serta laporan lain dalam kompilasi bukan satu deck yang sama |
| D007 — Vaccine innovation | Seluruh 40 hlm. | Temuan awal diuji dengan diagnosis lebih dalam, lalu solusi menurut tipe hambatan | Hlm.33–40 merupakan text versions terkait; isi medis bukan pengetahuan klinis produk |
| D010 — BCG OER ecosystem | Seluruh 23 hlm. | Definisi sukses → metrik → maturity → evidence | Arsitektur KPI belum dashboard target-actual terisi |
| D005 — Lebanon Economic Vision | 27 hlm. terpilih | Initiative-owner, mandat, reporting cadence, charter, dan Gantt | Mayoritas dokumen belum direview rinci; beberapa contoh bersifat preliminary |
| D003 — UK electricity efficiency | 4 hlm. terpilih | Residual opportunity, barrier taxonomy, assumptions ledger | Bukan review menyeluruh atas 129 halaman |

### Perubahan pemahaman dari Phase 1A

**C05 lebih kuat daripada yang terlihat pada sampel awal.** D005 hlm.1129, 1131, 1134, 1135, dan 1274 menyediakan lapisan governance, fungsi tools, frekuensi pelaporan, input implementasi, dan schedule. D020 hlm.15 menampilkan status lima rekomendasi implemented dan lima partially implemented. Kekurangannya kini lebih spesifik: contoh laporan periode berjalan yang menggabungkan actual-versus-plan, owner, dependency, risiko, eskalasi, dan keputusan.

**C04 kuat pada financial impact, belum lengkap untuk keputusan investasi.** D014 punya skenario dan rekonsiliasi pendanaan. D024 memisahkan biaya teknologi, training, adoption, dan running costs. D028 memisahkan manfaat tahunan dari investasi awal. Namun kombinasi ini belum menggantikan satu kasus investasi utuh dengan incremental cashflow, sensitivitas, dan syarat persetujuan.

**Atribusi D003 kini lebih jelas.** Listing resmi GOV.UK menyebut McKinsey & Co, dan PDF November 2012 berjumlah 129 halaman cocok pada judul/front matter. Draft Juli 2012 yang berjumlah 133 halaman adalah versi berbeda. Pencocokan ini mendukung identitas tingkat laporan; pencocokan byte web dengan unggahan tidak dilakukan.

## 4. Pola yang dapat menjadi fondasi produk

Berikut taxonomy hasil observasi. Ini **24 keluarga pola untuk analisis**, bukan penambahan otomatis menjadi 24 template MVP. Pemilihan archetype yang diimplementasikan tetap mengikuti fase desain pada blueprint.

| ID | Pola umum | Anchor yang dipelajari |
|---|---|---|
| A01 | Executive findings | D020 hlm.2 |
| A02 | Scope dan definisi metrik | D024 hlm.4 |
| A03 | Evidence dan assumptions ledger | D003 hlm.85 |
| A04 | Driver dan logic map | D024 hlm.9 |
| A05 | Waterfall dan residual bridge | D023 hlm.4 |
| A06 | Trend dengan implikasi | D023 hlm.18 |
| A07 | Perbandingan skenario | D014 hlm.13 |
| A08 | Komposisi dan kontribusi perubahan | D009 hlm.2 |
| A09 | Peer benchmark dan small multiples | D009 hlm.4 |
| A10 | Tabel financial impact/value pool | D014 hlm.33 |
| A11 | Assessment opsi dan kriteria | D007 hlm.26 |
| A12 | Prioritisasi dan penyaringan | D024 hlm.12 |
| A13 | Perubahan from-to | D024 hlm.21 |
| A14 | Inisiatif, charter, dan input eksekusi | D005 hlm.1135 |
| A15 | Accountability dan stakeholder map | D020 hlm.16 |
| A16 | Roadmap dan milestone | D005 hlm.1274 |
| A17 | Status implementasi | D020 hlm.15 — contoh parsial |
| A18 | Reporting cadence dan tool map | D005 hlm.1134 |
| A19 | Peta peluang/proyek geografis | D006 hlm.6 |
| A20 | Metode riset dan triangulasi | D008 hlm.50 |
| A21 | Evidence menjadi rekomendasi | D006 hlm.12 |
| A22 | Permintaan keputusan/diskusi | D023 hlm.39 — contoh parsial |
| A23 | Arsitektur KPI dan outcome | D010 hlm.5 |
| A24 | Diagnosis maturity | D010 hlm.6 |

Setiap keluarga pada file JSON memiliki tujuan penggunaan, kandidat semantic fields, referensi halaman, batas interpretasi, dan aturan terkait. Anchor adalah penunjuk untuk analisis; ia bukan template yang disalin.

### Aturan desain yang didukung observasi

1. **Satu kesimpulan utama dengan bukti yang tepat.** Judul perlu mengatakan apa yang ditemukan; nama topik saja cukup untuk pembatas bagian/metodologi, tetapi tidak cukup untuk setiap slide analitis.
2. **Hierarchy konsisten.** Pisahkan title, exhibit title, unit/periode, data, implication, serta source/footnote. Footer tidak boleh menjadi tempat menyembunyikan asumsi yang mengubah kesimpulan.
3. **Warna memiliki fungsi.** Pertahankan warna suatu skenario/segmen lintas slide. Aksen membantu menemukan hal penting. Persamaan warna dengan firma tertentu bukan ukuran kualitas analisis.
4. **Density mengikuti penggunaan.** Beberapa reference cocok sebagai read-ahead atau appendix. Tabel yang baik untuk dibaca dekat belum tentu cocok untuk presentasi langsung.
5. **Ikon mendukung kategori.** Kebutuhan ikon dapat dicatat sebagai makna—misalnya governance, people, finance, technology—lalu dibuat sebagai aset baru pada Phase 5. Ikon dekoratif bukan pengganti bukti.
6. **Detail angka adalah bagian desain.** Wrap angka, desimal terlalu panjang, label seri ambigu, dan axis break memengaruhi pemahaman. Render aktual tetap harus diperiksa.

Ini merupakan **sintesis korpus dan usulan standar produk**, bukan klaim telah memperoleh aturan internal resmi McKinsey, BCG, atau Bain. Belum ada ukuran font, grid, palette, atau design token firma yang ditetapkan sebagai default produk.

## 5. Temuan QA yang konkret

24 kasus pemeriksaan terdiri dari 16 hubungan aritmetika yang konsisten, satu yang konsisten setelah pembulatan, satu kasus rounding yang perlu input mentah, satu tanggal tidak valid, tiga ketidaksesuaian konteks, dan dua masalah render. Angka tersebut adalah hasil spot-check sumber; **bukan pass rate generator**.

| Contoh | Yang ditemukan | Implikasi untuk skill |
|---|---|---|
| D023 hlm.4 | `0.9 − 15.8 − 5.5 + 12.6 + 4.0 = −3.8` | Waterfall memerlukan signed drivers, bukan semua nilai dianggap positif |
| D023 hlm.19/23/24 | Annual: `33 − 18 = 15`; cumulative: `238 − 123 = 115` | Konsistensi lintas slide harus mempertahankan horizon waktu |
| D014 hlm.33 | Dampak beberapa akun menghasilkan gap, lalu bantuan mengurangi gap | Uji subtotal, tanda, dan definisi setiap skenario |
| D028 hlm.63 | `175 + 35 + 55 = 265`; manfaat gross 105 dikoreksi menjadi 55 | Simpan overlap adjustment; jangan menjumlahkan manfaat mentah |
| D008 hlm.27 | Kontribusi sekitar `130% + (−30%) = 100%` | Kontribusi pertumbuhan boleh melebihi 100% ketika komponen lain negatif |
| D028 hlm.64 | Komponen nominal tampil berjumlah 209, total tampil 210 | Selisih kecil akibat rounding perlu toleransi yang beralasan; jangan otomatis dinyatakan salah |
| D005 hlm.1124 | “31 Feb 2019” muncul dua kali | Tanggal harus lolos validasi kalender; tanggal pengganti tidak ditebak |
| D009 hlm.5 | Headline menyebut Austria, tabel tidak memuat Austria | Cocokkan entitas judul dengan entitas bukti |
| D014 hlm.28 | Non-fare pada judul/metode; fare-and-toll pada label hasil | Label metrik harus konsisten; jangan diam-diam mengganti angka |
| D006 hlm.8 | Tahun 2030 berlabel 12% pada chart, sekitar 5% pada commentary | Cocokkan pasangan tahun–nilai antara grafik dan kesimpulan |
| D006 hlm.3 dan 5 | Teks bertabrakan; sejumlah label angka panjang/bertumpuk pada dua renderer | Render QA diperlukan setelah build, meski asal referensi terlihat profesional |

Temuan ini berlaku pada **PDF yang diperiksa**. Penyebabnya—misalnya kesalahan authoring atau export—tidak ditentukan tanpa file native. Konsistensi aritmetika juga tidak membuktikan data bisnis dasarnya benar, mutakhir, atau sesuai untuk kasus pengguna baru.

## 6. Kecukupan lima kategori MVP

Penilaian berikut adalah **analisis cakupan koleksi**, bukan riset permintaan pasar baru. Lima kategori MVP yang sudah dikunci pada Phase 0 tetap dipertahankan.

| MVP | Yang sudah kuat | Yang perlu dilengkapi | Keputusan tambahan |
|---|---|---|---|
| C01 — Strategy | Diagnosis, opsi, constraints, dampak dan rekomendasi | Decision ask yang ringkas dan eksplisit masih perlu diperkuat | Tidak perlu batch strategi umum baru |
| C02 — Market/Competitive/Entry | Scope, pertumbuhan, segmentasi, value pools, peta pasar | Shortlist → entry mode → economics → go/no-go | **1 market-entry decision deck** |
| C03 — Performance/Board | Benchmark industri, tren output, sebagian status, arsitektur KPI/cadence | Company actual-vs-target, variance, forecast, cash, actions, decisions | **2 deck: monthly management + quarterly board/business review** |
| C04 — Business Case | Assumptions, skenario, costs-benefits, funding gap, overlap | Incremental investment cashflow, sensitivitas, return/payback yang relevan, approval | **1 investment business case lengkap** |
| C05 — Transformation/PMO | Charter, governance, roles, reporting cadence, Gantt, sebagian status terisi | Recurring actual-vs-plan, dependencies, RAID, eskalasi, decision log | **1 PMO status pack terisi** |

Lima deck adalah target tambahan untuk menutup celah, **bukan jaminan jumlah minimal yang secara otomatis membuat produk sempurna**. Jika satu deck memenuhi beberapa kebutuhan dengan baik, kebutuhan jumlah bisa berkurang setelah ditinjau.

Prioritaskan C03, C04, dan C05, lalu market entry C02. Bahan tidak harus berlogo firma besar. Deck perusahaan yang baik, milik sendiri atau teranonimisasi, dapat lebih relevan untuk alur operasional. Utamakan PPTX native jika tersedia; PDF tetap berguna untuk mempelajari pola. Spreadsheet pendukung sangat membantu untuk business case. Ikon dan palette belum dibutuhkan untuk menyelesaikan tahap ini.

## 7. Korelasi dengan pembangunan skill

Hasil ini mengubah koleksi referensi menjadi instruksi dan bahan yang dapat diperiksa:

| Bahan Phase 1B | Peran pada produk berikutnya |
|---|---|
| Story maps | Bahan menyusun playbook sesuai kebutuhan keputusan dan audiens |
| 24 keluarga pola | Bahan memilih bentuk slide berdasarkan hubungan analitis |
| Candidate semantic fields | Masukan untuk schema: metric, unit, period, scope, assumptions, owner, status |
| 22 aturan | Masukan Consulting-Grade Standard dan pemeriksaan kualitas |
| 24 kasus QA | Contoh pembeda: aritmetika salah, rounding wajar, label konflik, tanggal invalid |
| Catatan density/layout | Masukan mode presentasi, read-ahead, serta aturan render |
| Provenance dan exclusion list | Pemisahan antara sumber penelitian dan aset produk |

Pada implementasi nanti, model dapat membantu memilih storyline, menyusun kesimpulan, dan menilai kecocokan evidence. Kode deterministik menangani perhitungan, validasi data, tanggal, dan pembentukan file. Render kemudian diperiksa untuk masalah yang hanya terlihat secara visual. Adapter per AI mengikuti kemampuan eksekusi dan akses file yang benar-benar teruji.

Reference set ini **bukan fine-tuning model**. Tidak perlu memasukkan ribuan halaman ke setiap prompt. Bahan yang dipanggil sebaiknya sesuai playbook dan archetype yang dibutuhkan. Hasil desain akhir harus memakai data pengguna serta layout/aset orisinal.

Pemilihan compiler tetap pada technical spike Phase 6. Kompatibilitas semua AI dan editabilitas PPTX belum dibuktikan oleh review PDF ini. Tidak ada skill, compiler, template produk, atau ikon produk yang dibangun dalam Phase 1B.

## 8. Provenance dan batas penggunaan

URL sumber untuk 12 file prioritas sudah dicatat dan ditelusuri sejauh dapat diakses:

- **7 PDF pada host penerbit/client/mitra/penyelenggara berhasil dibuka:** D003, D006, D007, D008, D009, D014, dan D023. Pencocokan dilakukan pada identitas laporan, judul/front matter, dan jumlah halaman; bukan SHA256 web-versus-upload.
- **D024:** PDF pada host sekunder berhasil dibuka dan identitas laporan cocok.
- **D005:** listing kementerian berhasil dibuka; PDF besar belum berhasil diverifikasi melalui web. Atribusi penulis dan konteks watermark internal belum sepenuhnya terselesaikan.
- **D010:** kandidat URL foundation ditemukan, tetapi pengambilan PDF gagal.
- **D020:** listing sekunder berhasil dibuka; publikasi primer belum ditetapkan.
- **D028:** URL pemerintah ditemukan, tetapi akses mengembalikan 403.

Status akses publik dipisahkan dari izin penggunaan komersial. **D012 tetap dikeluarkan seluruhnya dari pengembangan produk** karena pembatasan template komersial yang dicatat pada Phase 1A. Ikon, slide, logo, dan komponen desainnya tidak digunakan.

Paket analisis hanya berisi catatan dan metadata. PDF/PPTX sumber, screenshot, logo, foto, atau icon pack sumber tidak disertakan sebagai aset produk. Original ZIPs, blueprint, dan hasil Phase 1A tidak diubah; hash 29 file sumber masih cocok dengan inventaris awal.

Rujukan web utama untuk pelacakan:

1. [Katalog asal pilihan pengguna — Slide Science](https://slidescience.co/mckinsey-presentations/).
2. [GOV.UK — laporan UK electricity efficiency, November 2012](https://www.gov.uk/government/publications/capturing-the-full-electricity-efficiency-potential-of-the-uk--2).
3. [USPS — Future Business Model](https://about.usps.com/future-postal-service/mckinsey-usps-future-bus-model2.pdf).
4. [MTA — financial impact assessment](https://new.mta.info/document/16951).
5. [Altagamma — Bain worldwide luxury market monitor](https://altagamma.it/media/source/WORLDWIDE%20LUXURY%20MARKET%20MONITOR_BAIN.pdf).
6. [Kementerian Ekonomi Lebanon — daftar laporan](https://www.economy.gov.lb/en/services/support-to-smes/files--reports).

URL lain, hasil akses, dan batas pencocokan tersedia pada `phase1b-provenance.json`. Semua klaim visual dan perhitungan dalam review ini berangkat dari file lokal yang Anda lampirkan; situs katalog tidak dijadikan bukti bahwa setiap deck adalah gold standard.

## 9. Hasil kerja dan urutan berikutnya

Paket `phase1b-analysis.zip` memuat:

| File | Isi |
|---|---|
| `phase1b-review.md` | Laporan ini |
| `phase1b-additional-deck-brief.md` | Instruksi lima deck tambahan |
| `phase1b-checkpoint.json` | Status, cakupan, hitungan, dan batas evaluasi |
| `phase1b-corpus-catalog.json` | Katalog 29 file dengan perkembangan review/provenance |
| `phase1b-annotations.json` dan `.csv` | 120 anotasi halaman yang dapat ditelusuri |
| `phase1b-annotation.schema.json` | Kontrak format anotasi checkpoint |
| `phase1b-story-maps.json` | Peta alur dan daftar halaman yang dibaca |
| `phase1b-archetypes.json` | 24 keluarga pola dan kandidat semantic fields |
| `phase1b-rule-candidates.json` | 22 usulan aturan dengan sumber halaman |
| `phase1b-qa-spotchecks.json` | 24 kasus pemeriksaan dan hasil terbatasnya |
| `phase1b-mvp-gaps.json` dan `.csv` | Cakupan, celah, dan brief tambahan per MVP |
| `phase1b-provenance.json` | URL dan status verifikasi 12 sumber prioritas |
| `phase1b-prohibited-redistribution.csv` | Perlakuan seluruh 29 sumber dalam produk |
| `phase1b-validation.json` | Pemeriksaan integritas, referensi, jumlah dan batas validasi |

Validasi checkpoint mencakup ID unik, kesesuaian dengan 120 halaman pilihan, nomor halaman yang sah, referensi aturan/pola, arithmetic checks dengan Decimal, validasi kalender, dan hash sumber. Pemeriksaan schema memakai kontrak terarah; validator lengkap JSON Schema Draft 2020-12 belum dipakai.

Urutan selanjutnya tetap mengikuti blueprint:

1. Tambahkan deck yang menutup lima kebutuhan pada brief, dimulai dari C03/C04/C05.
2. Tinjau hanya celah alur yang belum terwakili, selesaikan pencatatan sumber, dan periksa kandidat sebelum menjadi gold set.
3. Tutup gate korpus, lalu masuk **Phase 2 — Consulting-Grade Standard** dan kemudian schema pada Phase 3.
4. Ikon/palette tetap Phase 5; compiler tetap Phase 6.

Seluruh materi yang sudah memengaruhi review ini diperlakukan sebagai development reference. **Belum ada blind holdout.** Bagian Lebanon, text versions D007, serta deck/laporan satu studi D028 harus tetap dikelompokkan per proyek. Evaluasi kualitas produk nanti memerlukan brief/kasus baru yang belum dipakai untuk tuning, beserta output PPTX orisinal yang benar-benar diuji.
