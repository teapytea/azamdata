# Phase 1B analytical checkpoint

Mulai dari `phase1b-review.md`, kemudian `phase1b-additional-deck-brief.md`.

Untuk menelusuri contoh:

1. Cari category pada `phase1b-mvp-gaps.json`.
2. Cari archetype pada `phase1b-archetypes.json`.
3. Gunakan document ID dan nomor halaman pada `phase1b-annotations.json` atau `.csv`.
4. Cocokkan nama asli serta SHA256 di `phase1b-corpus-catalog.json` dengan file referensi Anda.

Semua nomor halaman adalah indeks PDF mulai 1, bukan nomor cetak di footer. D028 adalah kompilasi; unit presentasi yang direview adalah halaman 53–72. D005 hanya direview pada bagian terpilih.

`positive_logic` berarti hubungan analitis berguna, bukan izin menyalin slide. Semua `production_gold_approved` masih false. Pola dan aturan merupakan usulan produk berdasarkan observasi, bukan standar internal resmi firma consulting.

Paket ini tidak memuat PDF/PPTX sumber, screenshot sumber, template komersial, logo, atau ikon sumber. D012 dikeluarkan dari pengembangan produk. Belum ada skill, compiler, atau hasil PPTX yang diuji.

`phase1b-validation.json` menjelaskan checks yang dijalankan dan hal yang belum diverifikasi. `phase1b-qa-spotchecks.json` berisi hasil pemeriksaan terpilih atas sumber, bukan product benchmark. Semua materi review merupakan development reference; belum ada blind holdout.
