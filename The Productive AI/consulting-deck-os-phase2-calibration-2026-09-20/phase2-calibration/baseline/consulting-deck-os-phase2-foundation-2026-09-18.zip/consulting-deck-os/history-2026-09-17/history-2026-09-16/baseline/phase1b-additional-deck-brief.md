# Brief tambahan setelah Phase 1B

Tanggal: 14 September 2026

**Tambahkan lima deck berikut.** Tujuannya menutup celah workflow MVP yang ditemukan dari koleksi Anda. Tidak perlu menambah banyak market outlook umum, icon pack, atau palette sekarang.

| Prioritas | Kategori | Jumlah | Jenis deck | Isi yang perlu terlihat |
|---|---|---:|---|---|
| 1 | C03 | 1 | Monthly management/performance review | Actual vs target/budget, variance drivers, prior period, forecast, tindakan, owner, deadline |
| 1 | C03 | 1 | Quarterly board/business review | Ringkasan bisnis, hubungan keuangan-operasi, cash/resource constraints, risiko strategis, keputusan yang diminta, follow-up |
| 1 | C04 | 1 | Investment approval business case | Alternatif termasuk baseline, incremental capex/opex, cashflow timing, benefit ramp, return/payback yang relevan, sensitivitas, rekomendasi/approval |
| 1 | C05 | 1 | PMO/transformation status pack yang terisi | As-of date, RAG dengan definisi, milestone actual vs plan, owner, dependency, risks/issues, mitigasi, eskalasi, keputusan |
| 2 | C02 | 1 | Market-entry recommendation | Shortlist pasar, kriteria pilihan, customer/competitor evidence, entry mode, economics, risiko, go/no-go, urutan masuk |

C01 Strategy sudah cukup kuat untuk dasar kurasi saat ini. Kekurangan decision ask dapat turut diperkuat melalui lima deck di atas.

## Cara memilih

- Pilih **deck utuh**, termasuk executive summary, evidence utama, rekomendasi, dan appendix penting. Hindari hanya memilih beberapa halaman yang tampak bagus.
- Pilih contoh **yang sudah terisi**, bukan kumpulan layout kosong. Untuk C03 dan C05, laporan periode berjalan lebih berguna daripada artikel tentang cara membuat laporan.
- Tidak wajib McKinsey/BCG/Bain. Deck internal perusahaan yang rapi dan bisa Anda bagikan dapat lebih tepat untuk contoh workflow.
- Utamakan **PPTX native** jika tersedia. PDF diterima untuk mempelajari alur dan visual, tetapi tidak membuktikan editabilitas.
- Untuk business case, sertakan spreadsheet pendukung jika tersedia. Angka boleh disamarkan secara konsisten; hubungan rumus dan rekonsiliasinya perlu tetap masuk akal.
- Untuk report berkala, dua periode dari satu proyek membantu melihat perubahan dan follow-up. Tetap dihitung sebagai satu keluarga proyek untuk evaluasi.

Jumlah lima adalah target cakupan, bukan kuota mutlak. Satu deck dapat memenuhi beberapa kebutuhan jika alurnya lengkap. Contoh yang tidak mempunyai kas, NPV, atau IRR karena tidak relevan dengan kasusnya tidak perlu dipaksa memuat metrik tersebut; jelaskan metode keputusan yang dipakai.

## Cara melampirkan

Anda bisa unggah semua dalam satu ZIP dengan folder:

- `C03_monthly_review`
- `C03_board_review`
- `C04_investment_case`
- `C05_pmo_status`
- `C02_market_entry`

Tambahkan catatan singkat per file: nama/judul, tahun atau periode, URL asal jika ada, pemilik/penerbit, dan konteks izin berbagi/penggunaan yang Anda ketahui. Jika tidak ada informasi, tulis `belum diketahui`; tidak perlu mengarang metadata.

Materi milik sendiri atau yang boleh Anda gunakan lebih praktis untuk contoh produk. Jangan kirim informasi client yang tidak boleh dibagikan. Koleksi akan dianalisis untuk prinsip umum; logo, screenshot, dan aset firma tidak otomatis masuk produk yang dijual.

Setelah diterima, pekerjaan berfokus pada celah alur di atas. Inventaris 29 file dan 120 anotasi yang sudah selesai tidak perlu diulang dari awal.
