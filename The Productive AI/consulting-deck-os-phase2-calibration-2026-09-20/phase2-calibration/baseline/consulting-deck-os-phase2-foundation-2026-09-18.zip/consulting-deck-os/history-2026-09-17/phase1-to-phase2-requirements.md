# Handoff Phase 1 → Phase 2

Productive AI / Consulting Deck OS · 17 September 2026  
Status: kebutuhan hasil analisis; **bukan deklarasi Phase 2 selesai atau gate Phase 1 lulus seluruhnya**.

## A. Kontrak yang harus diterjemahkan menjadi standard

Blueprint tetap menjadi sumber keputusan produk. Bobot kualitas yang sudah disepakati: storyline 25, evidence/numeric integrity 20, message/copy 15, chart/annotation 15, visual craft 15, technical PPTX integrity 10. Ambang ≥85/100 dan tanpa critical failure tidak berubah.

Phase 2 harus menghasilkan standard, story rubric, slide rubric, deck rubric, dan hard-fail list. Gate dua reviewer dengan hasil relatif konsisten tetap berlaku pada Phase 2; satu AI tidak dapat mengklaim telah memenuhi dua reviewer dengan menjalankan penilaian dua kali.

## B. Requirement lintas lima MVP

| Area | Field/aturan yang diperlukan | Bukti uji yang diharapkan nanti |
|---|---|---|
| Decision contract | audience, decision_owner, purpose, decision_question, deadline, constraints | Inform tidak dipaksa menjadi approve; permintaan keputusan memiliki kewenangan dan waktu |
| Claim contract | claim_id, evidence_ids, assumption_ids, scope, confidence | Judul tidak melebihi yang dibuktikan isi slide |
| Metric contract | value, unit, period, comparator_type, scope, denominator, rounding | Prior year tidak berubah menjadi budget; nominal tidak bercampur real |
| Action contract | action_id, linked_issue, owner, due, status, dependency, decision_id | Semua aksi material dapat ditelusuri ke masalah dan pemilik |
| Forecast contract | version_date, baseline_version, assumptions, committed/potential/unidentified effects | Perubahan forecast mempunyai jembatan yang bisa diuji |
| Source contract | source_id, location/page, date, usage status, calculation lineage | Bukti dapat ditemukan kembali; asumsi ditandai |
| Visual contract | slide job, analytical intent, layout family, density, annotation | Layout dipilih karena tugas analitis, bukan nama firma |
| Output contract | editable text/charts/tables/shapes sesuai Practical level; raster decoration dibedakan | Uji file asli dan render; PDF referensi bukan bukti editability |

Field di atas adalah rancangan kebutuhan. Schema formal dan model validasinya tetap pekerjaan Phase 3.

## C. Minimum alur dan pemeriksaan per MVP

### C01 — Strategy & Strategic Recommendation

Input: pertanyaan keputusan, situasi, diagnosis berbukti, opsi termasuk status quo bila relevan, kriteria evaluasi, keterbatasan, dan implikasi implementasi.

Alur: keputusan yang dibutuhkan → diagnosis → opsi dan trade-off → rekomendasi → dampak dan risiko → tindakan.

Pemeriksaan: rekomendasi menjawab diagnosis; opsi dinilai dengan kriteria sebanding; tidak ada klaim kausal dari korelasi saja; judul berurutan membentuk argumen. Referensi: D023/D007 dan kandidat visual modern di register keputusan.

### C02 — Market, Competitive & Market Entry

Input: batas pasar, ukuran/periode, segmentasi, kompetitor, shortlist, entry modes, biaya/kapasitas tiap opsi, risiko, dan batas go/no-go.

Alur: pasar yang layak → pilihan sasaran → pilihan cara masuk → economics yang bisa dibandingkan → hard gates → rekomendasi dan izin yang diperlukan.

Pemeriksaan: TAM tidak otomatis revenue; hard gate mengalahkan skor menarik; kemitraan, akuisisi, dan pembangunan sendiri dibandingkan pada horizon serta basis yang sama; recommendation tidak dipresentasikan sebagai transaksi selesai.

Bukti komponen: D005; D033; D035. **Residual:** integrasi satu corporate entry case belum tervalidasi. Menggabungkan potongan berbeda tidak membuktikan keputusan nyata perusahaan tertentu.

### C03 — Performance, Management & Board Reporting

Input: actual, budget/target, prior actual, periode/YTD, drivers, forecast sebelumnya dan terbaru, implikasi kas, action log, serta tujuan rapat.

Alur: hasil utama → variance → penyebab → forecast dan kas → tindakan → tujuan forum.

Pemeriksaan: tanda variance mengikuti sifat metrik; perubahan basis dijelaskan; target masa depan tidak disamakan actual; angka bulanan dan YTD tidak dijumlahkan; mitigasi yang belum teridentifikasi tidak diperlakukan committed.

Detail monthly report dapat masuk appendix saat audience board membutuhkan rangkuman. Jumlah slide ditentukan isi dan batas pengguna, bukan menyalin jumlah halaman sumber.

Bukti komponen: D031/D032 dan D035. **Residual:** lineage tindakan finansial ke owner/due/keputusan dalam satu rantai internal perusahaan belum lengkap.

### C04 — Business Case, Financial Impact & Profitability

Input: baseline tanpa proyek, capex, opex incremental, benefit ramp, working capital, pajak bila relevan, nilai akhir bila digunakan, tanggal kas, discount basis, sensitivitas, funding, dan syarat keputusan.

Alur: masalah/alternatif → asumsi → kas incremental → nilai dan pendanaan → downside/sensitivitas → syarat persetujuan → implementasi.

Pemeriksaan: keuntungan akuntansi bukan kas; funding bukan operating benefit; project return dan investor return tidak dicampur; nominal/real harus sesuai discount basis; semua kalkulasi direkonsiliasi dari input. IRR tidak dipaksakan bila pola kas tidak mendukung hasil tunggal yang bermakna. Nilai terlapor pada PDF bukan kalkulasi yang otomatis benar.

Bukti komponen: D003/D014 dan D033. **Residual:** expected numerical output yang bisa direproduksi, varian capex nonzero terintegrasi, dan bukti final approval belum tersedia. Angka contoh produk harus berasal dari model orisinal yang diberi label sintetis dan dihitung, atau model berizin yang direkonsiliasi; bukan angka tebakan AI.

### C05 — Transformation Roadmap, PMO & Implementation

Input: as-of date, baseline, forecast, actual completion, workstream, dependency, RAID, owner/due, status definitions, decision/change log.

Alur: status keseluruhan → perubahan sejak laporan lalu → delivery vs plan → hambatan/critical path → eskalasi → keputusan dan aksi.

Pemeriksaan: baseline tidak diganti diam-diam; green memerlukan basis; approve tidak berarti implement; recommendation to close tidak berarti closed; tanggal tutup harus didukung bukti; tidak ada keputusan diperlukan adalah hasil yang sah.

Bukti workflow: D034; D005/D020 tetap mendukung komponen legacy. Kebutuhan contoh PMO terisi ditutup pada tingkat workflow. Penilaian visual dan uji PPTX tetap pekerjaan build/evaluation.

## D. Aturan pemilihan visual yang siap dibawa ke Phase 2

1. Gunakan GEI 2024 sebagai arah utama white analytical reporting; headline → exhibit → implikasi → sumber.
2. Gunakan kandidat 2024–2026 lainnya untuk variasi framework, matrix, dark analytical slide, dan data-dense exhibit.
3. Transposisi pola dilakukan dengan grid, font berlisensi, palet dan ikon orisinal. Tidak ada kewajiban meniru logo atau identitas firma.
4. Utamakan satu tugas analitis per slide. Kebutuhan dua panel harus berupa perbandingan yang jelas, bukan dua pesan yang tak terkait.
5. Axis break, dual-axis, dan ranking survey memerlukan aturan semantik khusus. Tidak menjadi default hanya karena muncul pada referensi terkenal.
6. Source footer, footnote, unit dan periode merupakan isi penting. Kekurangan ruang diselesaikan dengan penyuntingan/splitting, bukan mengecilkan font tanpa batas.

Ukuran font, grid, dan toleransi linting yang benar-benar final memerlukan pengujian render produk. Analisis visual referensi belum merupakan pengukuran token desain presisi.

## E. Backlog terarah berikutnya

| ID | Kebutuhan residual | Penerimaan bukti |
|---|---|---|
| GAP-C02 | Integrasi economics opsi corporate entry | Basis perbandingan yang konsisten, opsi/status quo, batas keputusan dan otoritas; bukan rationale satu transaksi saja |
| GAP-C03 | Lineage tindakan finansial | Masalah/variance tertentu terhubung ke tindakan, owner, due, status dan tujuan forum |
| GAP-C04 | Model dan keputusan investasi | Arus kas exact/bertanggal, return direkonsiliasi, capex nonzero bila relevan, dan syarat serta status approval yang jelas |

Pencarian harus berhenti menambah koleksi umum. Referensi komponen yang ada sudah cukup banyak; pekerjaan berikutnya harus menutup ID gap di atas atau mencatat keputusan scope secara eksplisit, bukan menurunkan standar secara diam-diam.

Setelah gate Phase 1 diselesaikan, lanjutkan Phase 2 sesuai blueprint. Ikon/palet tetap Phase 5, compiler spike Phase 6, dan klaim lintas-AI baru dapat dibuktikan melalui pengujian adapter kemudian.
