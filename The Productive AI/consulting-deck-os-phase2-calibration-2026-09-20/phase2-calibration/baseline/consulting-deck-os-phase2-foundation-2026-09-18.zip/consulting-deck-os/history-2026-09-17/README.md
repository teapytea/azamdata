# Productive AI — Referensi dan analisis, 17 September 2026

Mulai dari `phase1-continuation-2026-09-17.md`.

Status terbaru ada pada direktori utama. `history-2026-09-16/` menyimpan keluaran sebelumnya secara utuh, termasuk baseline blueprint, Phase 1B dan GEI; jangan gunakan status historis sebagai status terkini.

- `phase1-mvp-coverage.csv` / `.json`: cakupan lima MVP dan kebutuhan yang tersisa.
- `phase1-corpus-catalog.json` / `phase1-source-index.csv`: 35 sumber beserta identitas dan batas penggunaannya.
- `phase1-annotations.json`: 170 catatan, tidak semuanya pemeriksaan visual.
- `phase1-reference-decisions.json`: keputusan kandidat untuk pengembangan; tidak ada production gold.
- `phase1-source-addendum.json` / `phase1-review-ledger.json`: sumber dan kedalaman review tambahan.
- `phase1-numeric-reconciliation.json`: pemeriksaan terbatas, bukan sertifikasi model.
- `phase1-qa-addendum.json`: sembilan kasus QA tambahan.
- `phase1-to-phase2-requirements.md`: handoff kebutuhan; Phase 2 belum dinyatakan berjalan/lulus.
- `phase1-checkpoint.json`: status pekerjaan dan langkah berikutnya.
- `phase1-validation.json`: hasil verifikasi paket.
- `phase1-prohibited-redistribution.csv`: sumber/aset tidak dibundel untuk dijual; D012 tetap dikecualikan seluruhnya dari pembelajaran.

PDF/PPTX sumber, gambar render, raw extracted text, dan aset penerbit tidak disertakan. Referensi web-only tidak diberi hash palsu. File Python pembangunan analisis disimpan di `tools/`; menjalankannya kembali memerlukan input kerja yang disebut dalam script.
