import csv
import hashlib
import io
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/f07178664169')
BASE = ROOT / 'phase1_closure_2026_09_16/deliverables'
WORK = ROOT / 'phase1_gap_closure_2026_09_17'
OUT = WORK / 'deliverables'
OUT.mkdir(exist_ok=True)
DATE = '2026-09-17'

def read(path):
    return json.loads(path.read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

catalog = read(BASE / 'phase1-corpus-catalog.json')
baseline_annotations = read(BASE / 'phase1-annotations.json')['annotations']
baseline_docs = {d['document_id']: d for d in catalog['documents']}
download = {d['candidate_id']: d for name in ['download-log-initial.json', 'download-log-secondary.json'] for d in read(WORK / name) if d['status'] == 'DOWNLOADED'}

inputs = [
    ('D031', 'NBT_IPR_2025', 'North Bristol Integrated Performance Report, January 2025', 49, 2025, 'North Bristol NHS Trust', 'NBT_DEC2024', ['C03'], [1,2,3,8,39,40,43], [3,39], 'KPI, actual-budget, drivers, cash; reporting period December 2024.'),
    ('D032', 'NBT_BOARD_2025', 'Public Trust Board papers, 30 January 2025', 170, 2025, 'North Bristol NHS Trust', 'NBT_DEC2024', ['C03'], [19,21,22,65,146,147,149,162,164,165], [149,165], 'Governance context and financial report. Prior minutes have separate dates.'),
    ('D033', 'PUBLIC_ENERGY_OBC_2021', 'Public Energy Company: Outline Business Case', 200, 2021, 'Scottish Government; report by Grant Thornton UK LLP', 'PUBLIC_ENERGY_OBC_2019', ['C02','C04'], [13,14,19,20,21,22,25,116,118,119,124,125,126,127,129,131,133,134,135,143,149], [14,125,129,131], 'Entry options, staged decision and financial structure. Report/model 2019; published 2021.'),
    ('D034', 'MHHS_PSG41_2025', 'MHHS Programme Steering Group 41, 5 February 2025, v1.4', 85, 2025, 'MHHS Programme', 'MHHS_PROGRAMME', ['C05'], [1,2,3,4,5,6,54,55,58,59,63,64], [], 'Populated periodic PMO, actions, status, dependencies and prior decisions.'),
    ('D035', 'CARLSBERG_H1_2024', 'Carlsberg H1 2024 Financial Results Presentation', 14, 2024, 'Carlsberg Group', 'CARLSBERG_2024', ['C02','C03'], [3,4,7,8,9,10,11,12,13], [], 'Corporate performance and proposed acquisition rationale. External investor update, not internal board pack.'),
]
web_urls = {
    'D034': 'https://www.mhhsprogramme.co.uk/api/documentlibrary/Meeting%20Papers/MHHS-DEL3398%20PSG%2005%20February%202025%20v1.4.pdf',
    'D035': 'https://www.carlsberggroup.com/reports-downloads/h1-2024-financial-statement-presentation/',
}
landing = {
    'D031': 'https://www.nbt.nhs.uk/about-us/meet-our-board/trust-board-meetings-20262027/trust-board-meetings-20242025',
    'D032': 'https://www.nbt.nhs.uk/about-us/meet-our-board/trust-board-meetings-20262027/trust-board-meetings-20242025',
    'D033': 'https://www.gov.scot/publications/public-energy-company-outline-business-case/',
    'D034': 'https://www.mhhsprogramme.co.uk/programme-information/programme-steering-group',
    'D035': 'https://www.carlsberggroup.com/investor-relations/investor-home/reports-downloads/',
}
new_docs = []
for did, key, title, count, year, publisher, group, cats, pages, visual, role in inputs:
    local = key in download
    item = download.get(key, {})
    d = dict(document_id=did, original_filename=key + '.pdf', title_from_content=title,
             filename_note='Canonical analysis filename; publisher filename/path is preserved in source_url.',
             source_archive=None, file_type='pdf', page_or_slide_count=count, year=year,
             publisher_attribution=publisher, publisher_attribution_basis='primary_publisher_public_document',
             source_url=item.get('url', web_urls.get(did)), discovery_url=landing[did],
             sha256=item.get('sha256'), byte_size=item.get('bytes'),
             local_pdf_available=local, source_access='LOCAL_PRIMARY_PDF' if local else 'PRIMARY_URL_WEB_PDF_TEXT',
             external_authenticity_verified=True, exact_file_integrity_verified=local,
             subject_categories=cats, evaluation_group=group, learning_role=role,
             visual_role='NOT_A_MODERN_STYLE_TARGET', reviewed_pdf_pages_1based=pages,
             visual_reviewed_pdf_pages=visual, visual_review_method='contact sheet' if visual else 'not visually reviewed',
             review_status='selected_pages_only' if local else 'selected_web_text_excerpts_only',
             deep_review_all_pages_complete=False, rights_status='REFERENCE_ONLY_NO_REUSE_PERMISSION_ESTABLISHED',
             commercial_asset_reuse_approved=False, raw_source_redistribution_approved=False,
             production_gold_approved=False, product_bundle_policy='EXCLUDE_SOURCE_AND_ASSETS',
             review_date=DATE)
    if did == 'D033':
        d['model_report_year'] = 2019
        d['financial_model_reconciled'] = False
    if did == 'D034':
        d['access_limit'] = 'Direct download returned HTTP 403; official URL PDF text readable through web. No local bytes or SHA-256 claimed.'
    if did == 'D035':
        d['access_limit'] = 'Official URL PDF text reviewed through web. No local bytes, SHA-256, or visual review claimed.'
    new_docs.append(d)

docmap = baseline_docs | {d['document_id']: d for d in new_docs}

# Brief observations; product rules are proposed original requirements, not copied assets.
rows = [
 ('D031',3,'Monthly scorecard with basis notes.','Store target_basis per metric; never infer all RAG from one universal threshold.'),
 ('D031',39,'Actual/budget and explanatory drivers.','Use period, YTD, variance_sign and rounding tolerance explicitly.'),
 ('D031',40,'Cash view includes conditional outlook.','Keep forecast assumptions attached to the cash claim.'),
 ('D032',22,'Action deadlines are unspecified.','An owner alone does not close an action-tracking requirement.'),
 ('D032',146,'Finance paper purpose: information.','Use inform/discuss/decide routing; never invent an approval request.'),
 ('D032',149,'Finance summary combines table, trend and commentary.','Preserve financial logic but redesign dense content with original layout.'),
 ('D032',164,'Forecast revisions and an excluded risk are explicit.','Track forecast version, committed mitigation and downside separately.'),
 ('D032',165,'Mitigations include unidentified actions.','Unidentified actions cannot become committed savings in generated output.'),
 ('D033',14,'Mandatory eligibility gates precede weighted scoring.','Apply hard constraints before ranking feasible entry options.'),
 ('D033',124,'Capital costs are assumed absent.','Zero capex must be explicit; this is not a nonzero-capex benchmark.'),
 ('D033',125,'Project and investor return metrics differ.','Bind metric scope, cashflow, timing and discount basis.'),
 ('D033',129,'Annual investor funding/receipts table.','Validate cashflow signs and cumulative balances independently.'),
 ('D033',131,'Alternative revenue model has another funding profile.','Compare options on equivalent horizons and investor perspective.'),
 ('D033',133,'Alternative scenarios and sensitivities are tabulated.','Use immutable scenario IDs and trace each result to assumptions.'),
 ('D033',143,'Commercial choices remain conditional.','Recommendation is not evidence of final approval.'),
 ('D033',149,'Timetable is expressly proposed.','Do not label a target milestone as an achieved event.'),
 ('D034',4,'Action owner, due date and closure recommendation are populated.','Recommended closure and approved closure require distinct statuses.'),
 ('D034',6,'Workstream status has explicit RAG definitions.','Store status semantics; color must not carry the whole meaning.'),
 ('D034',54,'Change control distinguishes approval and implementation.','Approved does not mean implemented.'),
 ('D034',55,'Active RAID links delays to mitigation.','Connect dependency, critical path and escalation to an accountable action.'),
 ('D034',58,'Monthly report has dated actions and owners.','Allow no decision required without fabricating a decision.'),
 ('D034',59,'Milestones compare baseline and forecast dates.','Preserve baseline; record completion independently of forecast.'),
 ('D034',63,'Progress, outlook and milestones are combined.','Separate last-period delivery from next-period expectation.'),
 ('D034',64,'Risk, mitigation and ownership are populated.','Risk response needs a tracked owner and current status.'),
 ('D035',4,'Acquisition rationale includes return and leverage expectations.','Label forward-looking economics and transaction status explicitly.'),
 ('D035',10,'Corporate results distinguish reported and organic metrics.','Do not reconcile organic growth against rounded reported totals.'),
 ('D035',11,'Cash flow and capital deployment are explained.','Keep operating cash, investment and capital structure distinct.'),
 ('D035',12,'Capital allocation connects policy and transactions.','Separate strategic rationale from authorization and execution evidence.'),
 ('D035',13,'Outlook updates prior guidance with assumptions.','Version guidance; do not rename prior-year actuals as budget.'),
]
new_annotations = []
for did, page, observation, rule in rows:
    d = docmap[did]
    visual = page in d['visual_reviewed_pdf_pages']
    new_annotations.append(dict(annotation_id=f'P1C-{did}-{page:04}', document_id=did,
        pdf_page_1based=page, source_sha256=d['sha256'], source_url=d['source_url'],
        evidence_observation=observation, original_product_requirement=rule,
        review_method=('local PDF text plus contact sheet' if visual else 'local PDF text') if d['local_pdf_available'] else 'web PDF text excerpts; no visual verification',
        visually_reviewed=visual, disposition='development_logic_reference',
        source_asset_reuse_approved=False, production_gold_approved=False,
        evaluation_group=d['evaluation_group'], reviewer='Codex / single AI reviewer', review_date=DATE))

selected = [
 ('D030',8,'ACCEPT_DEVELOPMENT','Modern white analytical layout; trend with commentary.','Keep separate comparison baselines.'),
 ('D030',27,'ACCEPT_DEVELOPMENT','Modern paired exhibits.','Units and time periods belong to each panel.'),
 ('D030',11,'EDGE_CASE_ONLY','Axis-break QA reference.','Do not make broken axes the default chart style.'),
 ('D030',18,'EDGE_CASE_ONLY','Dual-axis QA reference.','Use only when justified and explicitly labeled.'),
 ('D030',21,'EDGE_CASE_ONLY','Axis-break and source-context QA.','Semantic exception; not a default gold chart.'),
 ('D001',12,'ACCEPT_DEVELOPMENT','Modern dark analytical waterfall.','Annual average, currency and rounding remain explicit.'),
 ('D001',18,'ACCEPT_DEVELOPMENT','Modern relative-comparison chart.','Ratio is not nominal cost.'),
 ('D001',19,'ACCEPT_DEVELOPMENT','Modern role framework.','Role map is not a populated PMO report.'),
 ('D017',12,'ACCEPT_DEVELOPMENT','Modern serif headline and survey exhibit.','Survey ranking is not computed investment ROI.'),
 ('D026',6,'ACCEPT_DEVELOPMENT','Modern two-sided value/risk framework.','Original artwork required.'),
 ('D026',7,'ACCEPT_DEVELOPMENT','Modern value-pool matrix.','Avoid double-counting enablers.'),
 ('D026',12,'ACCEPT_DEVELOPMENT','Modern explanation plus big-number hierarchy.','AUM and market capitalization are distinct.'),
 ('D023',4,'ACCEPT_LOGIC_ONLY','Legacy financial bridge.','Not a modern style target.'),
 ('D003',21,'ACCEPT_LOGIC_ONLY','Legacy sensitivity structure.','Do not adopt historical assumptions as universal defaults.'),
 ('D003',47,'ACCEPT_LOGIC_ONLY','Legacy payback communication.','Illustrative hurdle is not universal policy.'),
 ('D005',721,'ACCEPT_LOGIC_ONLY','Market shortlist reference.','Does not establish every entry-mode decision.'),
 ('D031',39,'ACCEPT_LOGIC_ONLY','Management reporting structure.','Not private-company board validation.'),
 ('D032',149,'ACCEPT_LOGIC_ONLY','Connected finance summary.','Do not imitate density or rounded frames.'),
 ('D032',22,'ANTI_PATTERN_ONLY','Missing deadline example.','Do not treat owner-only tracking as complete.'),
 ('D033',14,'ACCEPT_LOGIC_ONLY','Entry-mode eligibility and ranking.','Public-company context and historical assumptions.'),
 ('D033',125,'HOLD_NUMERIC_GOLD','Return metrics linked to a case.','Underlying model and timing not reconciled.'),
 ('D034',58,'ACCEPT_LOGIC_ONLY','Populated PMO operating workflow.','Text-only review; no visual or PPTX claim.'),
 ('D035',13,'ACCEPT_LOGIC_ONLY','Corporate forecast communication.','External reporting; no internal budget/action lineage.'),
]
base_index={(a['document_id'],a['pdf_page_1based']):a for a in baseline_annotations}
new_index={(a['document_id'],a['pdf_page_1based']):a for a in new_annotations}
decisions=[]
for did,page,decision,use,limit in selected:
    a=(base_index|new_index).get((did,page))
    assert a, (did,page)
    decisions.append(dict(reference_id=f'{did}:PDF:{page}',document_id=did,pdf_page_1based=page,
        annotation_id=a['annotation_id'],decision=decision,accepted_development_reference=decision.startswith('ACCEPT'),
        permitted_learning_use=use,limit=limit,production_gold_approved=False,
        review_basis='recorded annotation and targeted review; not an independent second review',
        reviewer='Codex / single AI reviewer',review_date=DATE))

coverage=read(BASE/'phase1-mvp-coverage.json')
updates={
 'C01':('TERPENUHI_UNTUK_FONDASI', 'Fondasi strategi dan kandidat referensi tetap tersedia.', 'Validasi output strategy deck berada pada fase build/evaluation.', []),
 'C02':('PARSIAL_VARIAN_CORPORATE_ENTRY', 'Mode masuk dan hard gates tersedia; corporate acquisition rationale ditambahkan.', 'Belum satu corporate case yang membandingkan seluruh opsi entry dengan economics setara dan keputusan berwenang.', [('D033',[13,14,19,25,125,143]),('D035',[4,12])]),
 'C03':('PARSIAL_KETERKAITAN_AKSI_FINANSIAL', 'Actual-budget, driver, forecast dan cash diperkuat; corporate external update tersedia.', 'Aksi finansial tertentu belum seluruhnya terhubung ke owner, tenggat dan keputusan pada satu internal corporate reporting chain.', [('D031',[3,39,40]),('D032',[22,65,146,147,149,162,164,165]),('D035',[3,10,11,12,13])]),
 'C04':('PARSIAL_REKONSILIASI_MODEL', 'Kas per periode, revenue/opex ramp, struktur pendanaan dan conditional approval diperkuat.', 'Model OBC bukan numeric gold: arus kas/timing belum direkonsiliasi ke return; nonzero capex case dan final-approval evidence belum terpenuhi.', [('D033',[19,25,118,119,124,125,126,127,129,131,133,134,135,143,149])]),
 'C05':('TERPENUHI_UNTUK_REFERENSI_WORKFLOW', 'PMO periodik terisi: baseline/forecast, aksi-owner-due, definisi status, RAID dan change decisions.', 'Visual MHHS, native editability dan kualitas generated deck belum diuji; bukan kekurangan struktur workflow.', [('D034',[1,2,4,5,6,54,55,58,59,63,64])]),
}
for cat in coverage['categories']:
    code=cat['category'];status,delta,remaining,refs=updates[code]
    cat['status_2026_09_16']=cat['status']
    cat['status']=status;cat['delta_2026_09_17']=delta;cat['remaining']=remaining
    cat['new_evidence']=[dict(document_id=d,original_filename=docmap[d]['original_filename'],pdf_pages_1based=p,source_url=docmap[d]['source_url'],source_sha256=docmap[d]['sha256']) for d,p in refs]
    cat['next']='Use requirements handoff and explicit residual backlog; no generic request for more decks.'
    cat['evidence'].extend(cat['new_evidence'])
coverage['review_date']=DATE
coverage['scope']='Reference evidence only. Composite patterns are not claimed as one end-to-end validated corporate case.'
write('phase1-mvp-coverage.json',coverage)
with (OUT/'phase1-mvp-coverage.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['category','name','status','delta_2026_09_17','remaining','evidence_pdf_pages_1based'])
    for c in coverage['categories']:
        w.writerow([c['category'],c['name'],c['status'],c.get('delta_2026_09_17'),c['remaining'],'; '.join(e['document_id']+':'+','.join(map(str,e['pdf_pages_1based'])) for e in c['evidence'])])

stats=dict(source_documents=len(docmap),source_pages_or_slides=sum(d['page_or_slide_count'] for d in docmap.values()),
    added_source_documents=5,added_source_pages=518,added_local_primary_pdfs=3,added_web_text_pdfs=2,
    additional_study_groups=4,new_selected_pages_reviewed=sum(len(d['reviewed_pdf_pages_1based']) for d in new_docs),
    page_count_note='Selected pages can be partial web-text review; not all pages deeply read. NBT documents share study group and duplicated financial content.',
    new_annotation_records=len(new_annotations),new_visually_reviewed_pages=8,
    consolidated_annotation_records=len(baseline_annotations)+len(new_annotations),
    cumulative_visual_annotation_records=149,reference_decisions=len(decisions),
    accepted_development_references=sum(d['accepted_development_reference'] for d in decisions),
    production_gold_approved=0,blind_holdout_established=False)
catalog['previous_stats_2026_09_16']=catalog['stats'];catalog['stats']=stats
catalog['documents'].extend(new_docs);catalog['review_date']=DATE;catalog['schema_version']='1.2'
write('phase1-corpus-catalog.json',catalog)
write('phase1-annotations.json',dict(schema_version='1.2',review_date=DATE,
    counting_note='Baseline 141 records plus 29 new records; new records include 8 visual and 21 text-only annotations. Do not equate all records with visual review.',
    annotations=baseline_annotations+new_annotations))
write('phase1-reference-decisions.json',dict(review_date=DATE,review_complete=True,approval_authority_note='No additional user or independent approval is specified for Phase 1 exemplar selection. These are single-AI development-use decisions, not production certification.',decisions=decisions))
write('phase1-review-ledger.json',dict(review_date=DATE,page_numbering='All page references are PDF sequence numbers starting at 1. Web P0 is PDF page 1.',sources=[dict(document_id=d['document_id'],reviewed_pdf_pages_1based=d['reviewed_pdf_pages_1based'],visual_reviewed_pdf_pages=d['visual_reviewed_pdf_pages'],method=d['review_status'],evaluation_group=d['evaluation_group']) for d in new_docs]))
write('phase1-source-addendum.json',dict(review_date=DATE,sources=new_docs))

# A bounded arithmetic check, deliberately not a certification of the source model.
flows={'retention':[-2541,372,372,372,372,2210,3359,3540,4501,4405,5385], 'acquisition':[-259,99,215,263,391,703,795,605,923,1036,908]}
numeric=[]
for name,cf in flows.items():
    def npv(r): return sum(v/(1+r)**t for t,v in enumerate(cf))
    lo,hi=0.,10.
    for _ in range(100):
        mid=(lo+hi)/2
        if npv(mid)>0:lo=mid
        else:hi=mid
    numeric.append(dict(scenario=name,source_pdf_page_1based=129 if name=='retention' else 131,
        check='Illustrative equally spaced annual IRR from displayed rounded annual net positions; first column t0',
        result_pct=round(100*(lo+hi)/2,4),reported_investor_irr_pct=34.5 if name=='retention' else 62.7,
        cumulative_total_matches_printed=True,conclusion='NOT_RECONCILED; not proof source model is wrong. Need exact dates, unrounded values, debt/distribution timing and model definitions. Do not reuse as golden numeric expected output.'))
write('phase1-numeric-reconciliation.json',dict(source='D033',review_date=DATE,model_certified=False,checks=numeric))

qa=[
 ('Q38','D032',[22],'Action owner without a due date','Fail completeness when a required accountable action lacks its deadline.'),
 ('Q39','D032',[146,147],'Information paper recast as approval','Preserve declared decision purpose.'),
 ('Q40','D032',[164,165],'Unidentified mitigation treated as committed benefit','Separate committed, potential and unidentified impact.'),
 ('Q41','D033',[124,125,129,131],'Rounded PDF cashflows treated as reconciled model','Require exact timing and calculation lineage before numeric-gold approval.'),
 ('Q42','D033',[25,149],'Proposed approval milestone treated as historical approval','Track target/actual dates and evidence of authority.'),
 ('Q43','D034',[4,5],'Recommend closed treated as closed','Distinguish recommendation and actual decision.'),
 ('Q44','D034',[4,5],'Headline year inconsistent with meeting context','Flag date inconsistency for source review; do not silently repair the source.'),
 ('Q45','D034',[54],'Approved change treated as implemented change','Use separate approval and implementation states.'),
 ('Q46','D035',[10,13],'Reported/organic or prior-year/budget mixed','Keep metric basis and comparator type separate.'),
]
write('phase1-qa-addendum.json',dict(review_date=DATE,case_ids_note='P1C prefix identifies this batch; historical QA IDs are unchanged.',cases=[dict(case_id=f'P1C-Q{j+1:02}',document_id=d,pdf_pages_1based=p,risk=r,expected_check=c) for j,(i,d,p,r,c) in enumerate(qa)]))
write('phase1-checkpoint.json',dict(review_date=DATE,project='Productive AI / Consulting Deck OS',
    completed_work='Targeted evidence extension, selected reference decisions, source/coverage/QA consolidation',
    blueprint_inventory_gate='COMPLETE_WITH_RECORDED_PROVENANCE_LIMITS',
    extended_phase1_gate='IN_PROGRESS_THREE_SPECIFIC_WORKFLOW_VALIDATION_GAPS',
    residual_categories=['C02','C03','C04'],C05_workflow_reference_gap='CLOSED',
    reference_selection='COMPLETE_FOR_SELECTED_DEVELOPMENT_SET',production_gold_approved=0,
    phase2_started=False,blueprint_changed=False,phase0_changed=False,skill_or_compiler_created=False,
    next_step='Resolve or explicitly disposition three residual workflow requirements; then Phase 2 Consulting-Grade Standard. Handoff is analysis input, not completed Phase 2.',
    user_upload_required_now=False,icons_and_palette_phase=5,compiler_spike_phase=6,stats=stats))

with (OUT/'phase1-source-index.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['document_id','filename','pages','source_url','sha256','group','reuse_approved'])
    for d in catalog['documents']:
        w.writerow([d['document_id'],d['original_filename'],d['page_or_slide_count'],d.get('source_url'),d.get('sha256'),d.get('evaluation_group',d['document_id']),False])
with (OUT/'phase1-prohibited-redistribution.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['document_id','policy','reference_learning_allowed','production_asset_reuse'])
    for d in catalog['documents']:
        w.writerow([d['document_id'],'EXCLUDE_COMPETITOR_CONTENT' if d['document_id']=='D012' else 'EXCLUDE_RAW_SOURCE_AND_ASSETS',d['document_id']!='D012',False])

# Preserve prior work as an immutable historical snapshot within the consolidated package.
history=OUT/'history-2026-09-16'
shutil.copytree(BASE,history,dirs_exist_ok=True)
blueprint=history/'baseline/blueprint-produk-consulting-grade-ppt.md'
if not blueprint.exists():
    source=ROOT/'phase1_closure_2026_09_16/inputs/the productive ai/blueprint-produk-consulting-grade-ppt.md'
    shutil.copy2(source,history/'blueprint-produk-consulting-grade-ppt.md')

checks={}
checks['source_count_35']=len(docmap)==35
checks['pages_2979']=stats['source_pages_or_slides']==2979
checks['new_reviewed_pages_59']=stats['new_selected_pages_reviewed']==59
checks['annotation_ids_unique']=len({a['annotation_id'] for a in baseline_annotations+new_annotations})==len(baseline_annotations+new_annotations)
checks['pages_in_range']=all(1<=a['pdf_page_1based']<=docmap[a['document_id']]['page_or_slide_count'] for a in new_annotations)
checks['annotations_within_reviewed_pages']=all(a['pdf_page_1based'] in docmap[a['document_id']]['reviewed_pdf_pages_1based'] for a in new_annotations)
checks['new_local_hashes_match']=all(sha(WORK/'sources'/d['original_filename'])==d['sha256'] for d in new_docs if d['local_pdf_available'])
checks['text_only_sources_have_no_hash']=all(d['sha256'] is None for d in new_docs if not d['local_pdf_available'])
checks['competitor_not_selected']=all(d['document_id']!='D012' for d in decisions)
checks['zero_production_gold']=not any(d['production_gold_approved'] for d in decisions)
checks['five_mvp_preserved']=[c['category'] for c in coverage['categories']]==['C01','C02','C03','C04','C05']
checks['prior_snapshot_identical']=all(sha(p)==sha(history/p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file())
write('phase1-validation.json',dict(review_date=DATE,checks=checks,all_passed=all(checks.values()),stats=stats))
assert all(checks.values()),checks
print(json.dumps(dict(stats=stats,checks=checks),indent=2))
