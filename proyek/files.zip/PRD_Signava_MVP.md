# PRD — Signava MVP (Q1)

**Versi:** 0.1 (draft, living document)
**Status:** Hipotesis kerja — bertumpu pada riset Certifier + 1 wawancara. Perlu validasi lanjutan.
**Legenda gap:** 🔶 Asumsi (masuk akal, belum tervalidasi) · 🔵 Open Question (belum diketahui, perlu discovery)

---

## 1. Executive Summary

Kami membangun **platform penerbitan & verifikasi kredensial digital** untuk penyelenggara pelatihan, kampus, dan operator sertifikat bervolume tinggi di Indonesia, guna menggantikan alur manual (Canva + Google Sheets + cetak) yang menyita waktu, rawan salah, dan mahal (~Rp5.000/lembar cetak). MVP memungkinkan penerbit mengunggah daftar peserta, menghasilkan ratusan–ribuan sertifikat ber-branding sekaligus, membagikannya secara digital, dan menyediakan **halaman verifikasi publik ber-QR** yang membuktikan keaslian. Target dampak: ≥40% penerbit yang mendaftar menyelesaikan batch pertama, dan ≥25% menerbitkan batch kedua dalam 60 hari.

---

## 2. Problem Statement

### Siapa yang mengalami?
Operator/koordinator sertifikat bervolume tinggi di Indonesia — penyelenggara wisuda sekolah/kampus, LPK/lembaga kursus, penyelenggara webinar/pelatihan, kepanitiaan — yang bukan desainer maupun orang IT.

### Apa masalahnya?
Membuat, membagikan, dan memverifikasi sertifikat dalam jumlah banyak dilakukan manual: desain di Canva/PPT, isi nama dari spreadsheet, cek satu per satu, unduh ribuan file, cetak satu per satu. Revisi satu nama di antara ribuan file sangat menyulitkan. Sertifikat tampak tidak profesional (watermark Canva) dan tidak bisa dibuktikan keasliannya.

### Kenapa menyakitkan?
- **Dampak pengguna:** berjam-jam hingga seharian kerja per acara; cemas soal kesalahan; hasil terlihat tidak profesional.
- **Dampak biaya:** cetak ~Rp5.000/lembar → ~Rp5 juta per 1.000 sertifikat; sertifikat fisik hilang/rusak.
- **Dampak bisnis penyelenggara:** citra kurang kredibel; layanan revisi lambat memicu komplain peserta.

### Bukti (n=1 — perlu diperkuat)
- *"Membuat desain ini membutuhkan waktu yang sangat lama… pusing sekali."*
- *"Ribuan sertifikat kita scroll satu-satu… menyebalkan sekali."*
- *"Kalau di-share link Canva, tidak profesional karena ada keterangan Canva."*
- *"Kalau ada QR kan enak ya? Profesional."*
- Volume: TK ~30, SMP ~200, universitas **sampai 5.000 sekali generate**; workshop 50–100/bulan; kursus ribuan/tahun.
- 🔵 Bukti masih dari 1 narasumber. Butuh 4–6 wawancara untuk saturasi.

---

## 3. Target Users & Personas

### Persona primer — "Pandu, Sang Operator Sertifikat"
- **Peran:** mengelola penerbitan sertifikat untuk banyak institusi/klien (sekolah, kampus, LPK, EO, kepanitiaan).
- **Tech-savviness:** rendah–menengah; hidup di Canva + Google Sheets + printer; aktif WhatsApp.
- **Goals:** terbit massal cepat & benar; tampil profesional; berhenti lembur administratif; revisi cepat.
- **Pains:** desain lama, bulk tak dipercaya, revisi ribuan file, biaya cetak, hasil tak terverifikasi.
- 🔵 Apakah ia membeli untuk institusinya sendiri atau menjual jasa untuk banyak klien? (menentukan apakah ia pelanggan atau channel).

### Persona sekunder — "Kirana, Sang Kolektor Kredensial" (sisi penerima)
Penerima yang ingin satu halaman portofolio seumur hidup mengumpulkan semua kredensial lintas-penyelenggara, terverifikasi. 🔶 Aspirasional, baru muncul dari 1 orang — **di luar scope MVP**, divalidasi sebelum dibangun.

### Jobs-to-be-Done (inti)
"Ketika sebuah acara selesai dan saya harus menerbitkan lalu membagikan sertifikat ke semua peserta dalam waktu singkat, saya ingin prosesnya cepat, benar, profesional, dan terbukti asli — sehingga saya selesai tanpa lembur dan tanpa komplain."

---

## 4. Strategic Context

- **Tujuan bisnis (tahun-1):** menangkan beachhead pendidikan/wisuda + LPK; North Star = jumlah kredensial terverifikasi diterbitkan & dibagikan/bulan.
- **Peluang pasar:** TAM ~Rp750 miliar/tahun (~$47 jt) penerbit sertifikat Indonesia; SAM ~Rp260 miliar (~$16 jt); SOM tahun-3 ~Rp10 miliar ARR. Basis populasi: ~440.000 sekolah, ~53 juta siswa, ~2.937 perguruan tinggi, ~8,46 juta mahasiswa (BPS/Kemendikbud 2024). 🔶 ARPU & penetrasi asumsi.
- **Lanskap kompetitif:** Certifier.io (USD, Inggris, tanpa konteks legal lokal, tanpa solusi cetak); Credly/Accredible (per-penerima, mahal); substitusi lokal = Canva + Sheets + jasa freelance. Tidak ada SaaS lokal purpose-built dominan.
- **Diferensiasi:** kredensial terverifikasi diakui lokal + hemat biaya cetak, untuk penerbit bervolume tinggi Indonesia. Harga/bahasa lokal sebagai keunggulan struktural pendukung.
- **Why now:** ledakan webinar/pelatihan; ekspektasi "sertifikat ber-QR"; dorongan paperless; regulasi tanda tangan elektronik/e-Meterai membuka moat lokal.

---

## 5. Solution Overview

Aplikasi web (mobile-friendly) berbahasa Indonesia dengan alur inti:

1. **Buat/pilih desain** dari template lokal (drag-and-drop dasar) dengan field dinamis (nama, predikat, tanggal, penyelenggara).
2. **Unggah daftar peserta** dari spreadsheet (CSV/Excel/Google Sheets) → **preview & validasi** (deteksi baris kosong, duplikat, karakter aneh) sebelum generate.
3. **Generate batch** ratusan–ribuan kredensial sekaligus; tiap kredensial punya **ID unik + halaman verifikasi publik + QR**.
4. **Distribusi**: kirim via email/link (dan unduh massal rapi per-nama); ekspor **print-ready** untuk yang masih mencetak.
5. **Kelola batch**: daftar batch, cari nama, dan **terbitkan-ulang satu kredensial dalam hitungan detik** saat ada koreksi.

Fondasi: akun/auth, **free tier**, pembayaran **Rupiah + QRIS/e-wallet**, UI Bahasa Indonesia.

🔵 Wireframe/UX detail diserahkan ke desain (PRD tidak menentukan UI pixel-by-pixel).

---

## 6. Success Metrics

| Jenis | Metrik | Baseline | Target (6 bln pasca-MVP) |
|---|---|---|---|
| **Primary (activation)** | % penerbit daftar yang menyelesaikan batch pertama | 0 (baru) | ≥40% 🔶 |
| **Retention** | % penerbit yang menerbitkan batch kedua dalam 60 hari | 0 | ≥25% 🔶 |
| **Engagement (diferensiator)** | Rata-rata scan halaman verifikasi per kredensial | 0 | tren naik 🔵 |
| **Monetisasi** | Konversi free → berbayar | 0 | ≥3% 🔶 |
| **Kualitas** | Waktu median dari unggah spreadsheet → batch terkirim | manual (jam) | < 15 menit |

---

## 7. User Stories & Requirements

### MVP Epics (ringkas)
- **Epic A — Penerbitan massal (bulk issuance)** ← POC utama
- **Epic B — Verifikasi & halaman kredensial** ← diferensiator
- **Epic C — Distribusi & unduh**
- **Epic D — Manajemen batch & revisi**
- **Epic E — Fondasi** (akun, free tier, billing Rupiah/QRIS) — pendukung

---

### Epic A — Penerbitan massal

**Epic hypothesis:**
*Jika kami* memungkinkan penerbit mengunggah spreadsheet peserta dan menghasilkan batch sertifikat ber-branding yang ter-preview & tervalidasi, *untuk* operator sertifikat bervolume tinggi (Pandu), *maka kami akan* membuat mereka menyelesaikan batch pertama tanpa kerja manual — target ≥40% activation dalam 6 bulan.
**Uji sebelum bangun penuh:** prototipe klik + concierge 1 batch nyata untuk 3 penyelenggara.
**Valid jika (4 minggu):** ≥6 dari 10 penerbit uji menyelesaikan batch tanpa bantuan; median < 15 menit.

**Breakdown (Humanizing Work — Pattern 1 Workflow Steps + Pattern 5 Data Entry + Pattern 7 Simple/Complex):**

**A1. Generate batch jalur sederhana (core value)** — *Pattern 1, thin end-to-end*
- **Sebagai** Pandu, **saya ingin** mengunggah spreadsheet berisi nama peserta dan memilih satu template, **agar** semua sertifikat langsung ter-generate sekaligus.
- **Given** file berisi kolom nama, **When** saya unggah dan pilih template lalu klik "Generate", **Then** sistem membuat 1 kredensial per baris dengan nama terisi otomatis dan menampilkan hasilnya.
- *Kenapa duluan:* memberi nilai inti end-to-end paling sederhana. Estimasi: 3–5 hari.

**A2. Preview & validasi sebelum generate** — *Pattern 1, tambah langkah*
- **Sebagai** Pandu, **saya ingin** melihat pratinjau & peringatan (baris kosong, duplikat, karakter aneh) sebelum generate, **agar** tidak ada nama salah lolos.
- **Given** spreadsheet terunggah, **When** sistem memproses, **Then** ditampilkan tabel pratinjau + daftar peringatan, dan generate baru bisa dijalankan setelah saya konfirmasi.
- Estimasi: 2–3 hari.

**A3. Field dinamis tambahan** — *Pattern 4 Data Variations*
- **Sebagai** Pandu, **saya ingin** memetakan kolom tambahan (predikat, tanggal, nomor, penyelenggara) ke template, **agar** sertifikat memuat data lengkap.
- **Given** spreadsheet dengan beberapa kolom, **When** saya petakan kolom→field, **Then** tiap field terisi sesuai baris.
- Estimasi: 2 hari.

**A4. Editor template drag-and-drop dasar** — *Pattern 5 Data Entry (UI sederhana dulu)*
- **Sebagai** Pandu, **saya ingin** menyesuaikan teks/logo/warna pada template, **agar** sertifikat sesuai branding penyelenggara.
- **Given** sebuah template, **When** saya ubah elemen dan simpan, **Then** perubahan tampil di semua kredensial batch.
- 🔶 MVP: kustomisasi terbatas (logo, teks, warna, posisi field), bukan editor desain penuh. Estimasi: 5 hari.

*Split evaluation:* A1 memberi nilai inti; A4 paling berat dan bisa dimulai dari 2–3 template preset bila perlu dipangkas.

---

### Epic B — Verifikasi & halaman kredensial

**Epic hypothesis:**
*Jika kami* memberi tiap kredensial halaman verifikasi publik ber-QR dengan ID unik, *untuk* Pandu (dan penerima), *maka kami akan* membuat sertifikat tampak profesional & terbukti asli — mendorong retensi & kesediaan bayar.
**Valid jika (4–6 minggu):** ≥7 dari 10 penerbit menilai sertifikat "terlihat profesional/resmi"; scan verifikasi terjadi pada ≥X% kredensial. 🔵 tetapkan X setelah baseline.

**Breakdown (Pattern 2 CRUD-read + Pattern 3 Business Rule):**

**B1. Halaman verifikasi publik + ID unik**
- **Sebagai** verifikator (HR/panitia), **saya ingin** membuka halaman publik sebuah kredensial via ID/URL, **agar** bisa memastikan keasliannya.
- **Given** kredensial terbit, **When** URL/ID diakses, **Then** tampil detail terverifikasi (nama, penyelenggara, tanggal, status asli).
- Estimasi: 3 hari.

**B2. QR code pada kredensial**
- **Sebagai** Pandu, **saya ingin** tiap sertifikat memuat QR yang mengarah ke halaman verifikasi, **agar** verifikasi cepat dari dokumen fisik/digital.
- **Given** kredensial memiliki halaman verifikasi, **When** kredensial dibuat, **Then** QR tercetak dan mengarah ke URL verifikasi yang benar.
- Estimasi: 2 hari.

**B3. Status & pencabutan (revoke)** — *Pattern 3, aturan berbeda*
- **Sebagai** Pandu, **saya ingin** menandai kredensial sebagai dicabut/kedaluwarsa, **agar** halaman verifikasi menampilkan status yang akurat.
- **Given** kredensial terbit, **When** saya cabut, **Then** halaman verifikasi menampilkan "tidak berlaku".
- 🔶 Nice-to-have MVP; bisa ditunda bila kapasitas terbatas. Estimasi: 2 hari.

---

### Epic C — Distribusi & unduh (ringkas)
- **C1. Unduh massal rapi** (ZIP, tiap file dinamai per nama) — 2–3 hari.
- **C2. Kirim via email/link** ke penerima dari daftar — 3 hari.
- **C3. Ekspor print-ready** (PDF resolusi cetak) — 2 hari.
- 🔵 Kirim via WhatsApp: divalidasi (biaya/kompleksitas API) — kemungkinan pasca-MVP.

### Epic D — Manajemen batch & revisi (ringkas) — *Pattern 2 CRUD*
- **D1. Daftar & lihat batch** (Read) — 2 hari.
- **D2. Cari nama dalam batch** (Read/filter) — 2 hari.
- **D3. Terbitkan-ulang 1 kredensial** (Update/regenerate) — inti nyeri wawancara — 3 hari.
- **D4. Hapus batch/kredensial** (Delete) — 🔶 rendah prioritas — 1 hari.

### Epic E — Fondasi (ringkas)
- **E1. Akun & autentikasi** — 3 hari.
- **E2. Free tier + batas volume** — 2 hari.
- **E3. Billing Rupiah + QRIS/e-wallet** — 🔵 pilih PSP (mis. Midtrans/Xendit) — 5 hari.

---

## 8. Out of Scope (MVP)

- **Portofolio kredensial penerima lintas-penyelenggara** — visi v2, tunggu validasi.
- **Integrasi e-Meterai/PSrE/tanda tangan elektronik tersertifikasi** — Q3+, setelah validasi permintaan.
- **API & integrasi pihak ketiga** (Google Forms, Zoom, Zapier) — Q3.
- **Custom domain, verified issuer, analytics lanjutan** — tier Bisnis, pasca-MVP.
- **Editor desain tingkat lanjut** (setara Canva penuh) — MVP cukup kustomisasi terbatas.
- **Kirim via WhatsApp otomatis** — validasi dulu.

---

## 9. Dependencies & Risks

### Dependencies
- **Payment gateway** lokal (QRIS/e-wallet) — pilih & integrasi PSP.
- **Desain** — 2–3 template preset + pola editor sederhana.
- **Infra** — penyimpanan file & rendering batch bervolume besar (hingga ribuan kredensial sekali generate).

### Risks & Mitigations
- **Risiko:** WTP rendah / masalah dianggap kerepotan wajar tanpa nilai ekonomi. → **Mitigasi:** landing/fake-door + concierge sebelum bangun penuh; pesan ROI vs biaya cetak.
- **Risiko:** verifikasi/"profesional" ternyata bukan pendorong bayar. → **Mitigasi:** uji di wawancara & lihat scan verifikasi.
- **Risiko:** performa generate batch 5.000 sertifikat. → **Mitigasi:** proses asinkron + antrian; uji beban dini.
- **Risiko:** musiman (event-driven) → churn langganan. → **Mitigasi:** paket pay-per-batch + rencana tahunan.

---

## 10. Open Questions

- 🔵 Pandu = pelanggan langsung atau channel jasa multi-klien?
- 🔵 Seberapa luas kebutuhan portofolio penerima (Kirana)?
- 🔵 Apakah "hemat cetak" mengalahkan "gratisan manual" sebagai alasan bayar?
- 🔵 Bobot verifikasi "resmi" untuk penerbit umum vs khusus (kampus/nakes)?
- 🔵 PSP mana yang terbaik untuk QRIS/e-wallet (biaya, kemudahan integrasi)?
- 🔵 Batas volume free tier yang optimal (100? 250?) untuk memicu konversi tanpa mengorbankan PLG.

---

## Self-Assessment

- **Seksi terkuat:** Problem & Solution (bertumpu bukti wawancara langsung).
- **Seksi terlemah:** Success Metrics & Strategic Context (angka masih asumsi/n=1).
- **Asumsi teratas untuk divalidasi:** WTP; verifikasi sebagai pendorong bayar; hemat-cetak vs gratisan; persona pembeli.
- **Langkah berikut sebelum dibagikan luas:** jalankan 4–6 wawancara + fake-door/concierge (Lean UX Box 8), lalu perbarui Section 2, 4, 6.
