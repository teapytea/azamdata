# CLAUDE.md — Signava

Konteks proyek untuk Claude Code. Baca file ini sebelum mengerjakan tugas apa pun. Hormati juga `AGENTS.md` yang sudah ada di repo (aturan agen dari design system).

## Apa itu Signava
Platform SaaS penerbitan & verifikasi kredensial digital untuk pasar Indonesia. Penyelenggara (kampus, LPK, EO, komunitas) mengunggah daftar peserta lalu menerbitkan ratusan–ribuan sertifikat sekaligus, membagikannya, dan menyediakan halaman verifikasi publik ber-QR. Diferensiasi: terverifikasi & diakui lokal, hemat biaya cetak, harga & bahasa Indonesia.

Aplikasi ini dibangun DI ATAS design system **Faiz UI** (repo ini sudah ter-scaffold). Kita tidak membuat project baru — kita membangun fitur Signava di dalam repo ini.

Dokumen sumber (baca bila perlu): `PRD_Signava_MVP.md`, `Signava_Technical_Spec.md`, `Signava_Build_Plan.md`.

## Tech stack (SESUAI REPO — bukan Next.js)
- **Framework:** TanStack Start + TanStack Router (rute berbasis file di `src/routes/`)
- **Runtime/build:** React 19, TypeScript, **Vite**, **Bun**
- **UI:** shadcn/ui (style `base-luma`), primitives di `src/components/ui/` (~50 komponen), ikon **Hugeicons** (`@hugeicons/react`)
- **Styling:** Tailwind CSS v4 — design tokens di `src/styles.css`
- **Motion & tema:** Motion, next-themes
- **Font:** Geist Variable
- **Lint/format:** **Biome** (bukan ESLint/Prettier)

> Catatan: `Signava_Technical_Spec.md` menyebut "Next.js route handlers" — perlakukan itu sebagai arsitektur logis. Di repo ini, **logika server memakai TanStack Start server functions** (`createServerFn`) / server routes, dan **routing berbasis file TanStack Router**. Model data, Supabase, RLS, dan rendering sertifikat TETAP sama seperti di spec.

## Backend (rencana)
- **Supabase** — Postgres, Auth, Storage, RLS, (Edge Functions bila perlu worker).
- Panggil Supabase dari **server functions** untuk operasi sensitif; jangan pernah pakai service-role key di client.
- Multi-tenant: semua data milik `organization`, dibatasi RLS berbasis `memberships`.
- Verifikasi publik TIDAK membuka RLS — hanya lewat RPC `verify_credential(public_id)` (security definer) yang mengembalikan field non-sensitif.
- Rendering sertifikat: template SVG berplaceholder → substitusi → PNG (`sharp`) + PDF (`pdf-lib`) + QR (`qrcode`) → upload Supabase Storage → row `credentials` (public_id acak `nanoid`). Batch besar (>500) async via tabel `jobs`.

## Model data (ringkas)
`profiles`, `organizations`, `memberships`, `templates`, `batches`, `credentials`, `jobs`. DDL & RLS lengkap di `Signava_Technical_Spec.md` §3.

## Brand & tema (WAJIB diikuti)
Warna dari logo Signava:
- Navy: `#16204A` (dasar/ink aksen)
- Biru royal: `#2A5BEA` (primary)
- Teal/cyan: `#16C0AE` (accent/verified)

Aturan tema: **pertahankan palet netral bawaan Faiz UI** (nuansa "dashboard 1"), hanya arahkan token brand:
- `--primary` → biru `#2A5BEA`
- `--accent` / `--ring` → teal `#16C0AE`
- tambah `--brand-navy: #16204A`
Edit di `src/styles.css`, di `:root` DAN `.dark`, **ikuti format warna yang sudah dipakai file itu** (oklch/hsl). Jangan ubah token netral lain.
Konsep visual: "kredibilitas terverifikasi" — resmi, bersih, trust cue (QR, ID, penyelenggara) di mana-mana. Teal = warna verified/segel.

## Aturan kerja (WAJIB)
1. **Rencanakan dulu, tunggu konfirmasi, baru eksekusi.** Jangan menulis banyak kode sebelum rencana disetujui.
2. **Satu vertical slice kecil per waktu** sesuai `Signava_Build_Plan.md`. Jangan bangun semua sekaligus.
3. **Ikuti acceptance criteria (Given/When/Then)** tiap story di PRD.
4. **Jangan bangun di luar scope MVP** (PRD §8): portofolio penerima, e-Meterai, API pihak ketiga, editor desain penuh, WhatsApp, billing (Fase 2).
5. **Reuse komponen Faiz UI** dari `src/components/ui/` — jangan bikin komponen dari nol bila sudah ada. Tambah komponen shadcn baru dengan `bunx shadcn@latest add <nama>`.
6. **Uji tiap slice:** `bun run typecheck` + `bun run check` lolos, happy-path jalan (`bun run dev`).

## Keamanan (WAJIB)
- **RLS aktif di semua tabel tenant**; verifikasi publik hanya via RPC security-definer.
- `public_id` acak (`nanoid` ≥16 char); file Storage privat + signed URL; tidak ada PII di URL.
- **Rahasia lewat env vars saja**; JANGAN commit `.env`; JANGAN hardcode kunci.
- `SUPABASE_SERVICE_ROLE_KEY` hanya di server function, jangan diekspos ke client.
- Token registry Faiz UI (`fui_...`) rahasia — di `.npmrc`/env, jangan commit.
- **Manusia yang mengisi semua kunci/secret & setup PSP.** Jangan minta atau menaruh kunci asli.

## Konvensi
- TypeScript strict; validasi input server (zod).
- Rute di `src/routes/` (file-based TanStack Router). Server logic via `createServerFn`.
- Migrasi Supabase sebagai file SQL di `supabase/migrations/`.
- UI default **Bahasa Indonesia**, sentence case, kalimat aktif ("Simpan perubahan", bukan "Submit").
- Ikon: Hugeicons (bukan lucide, kecuali sudah dipakai repo).
- `.env.example` berisi nama env tanpa nilai asli.

## Perintah
```
bun run dev         # http://localhost:3000
bun run build
bun run typecheck   # tsc --noEmit
bun run check       # biome lint + format check
bun run fix         # biome auto-fix + format
bun run test
bunx shadcn@latest add <komponen>   # tambah primitive ke src/components/ui/
```

## Definition of Done per tugas
typecheck + biome check lolos; acceptance criteria terpenuhi; happy-path teruji manual; reuse komponen Faiz UI; tidak ada secret ter-commit; scope tidak melebar.
